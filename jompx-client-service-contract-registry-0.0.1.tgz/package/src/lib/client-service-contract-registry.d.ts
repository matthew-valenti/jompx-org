import { AwsCredentialIdentity } from '@smithy/types';
export interface ServiceContractRegistryClientProps {
    baseUrl: string;
    region: string;
    timeoutMs?: number;
    cache?: ServiceContractRegistryClientCacheProps;
    credentialsProvider?: CredentialsProvider;
}
export interface ServiceContractRegistryClientCacheProps {
    softTtlMs?: number;
    hardTtlMs?: number;
    maxEntries?: number;
}
export type AwsCredentials = AwsCredentialIdentity;
export type CredentialsProvider = () => AwsCredentials | Promise<AwsCredentials>;
export interface ContractPath {
    environmentName: string;
    contractName: string;
    schemaVersion: string;
}
export interface AccountRegionContractPath {
    accountId: string;
    region: string;
    contractName: string;
    schemaVersion: string;
}
export interface GetContractOptions {
    forceRefresh?: boolean;
}
export interface PutContractRequest<TValue extends Record<string, unknown> = Record<string, unknown>> extends ContractPath {
    accountId: string;
    region: string;
    value: TValue;
}
export interface ServiceContract<TValue extends Record<string, unknown> = Record<string, unknown>> {
    environmentName: string;
    accountId: string;
    region: string;
    contractName: string;
    schemaVersion: string;
    value: TValue;
    updatedAt: string;
}
export type ServiceContractRegistryClientErrorCode = 'Validation' | 'Unauthorized' | 'Forbidden' | 'NotFound' | 'Network' | 'Http';
export declare class ServiceContractRegistryClientError extends Error {
    readonly code: ServiceContractRegistryClientErrorCode;
    readonly statusCode?: number | undefined;
    readonly responseBody?: string | undefined;
    constructor(message: string, code?: ServiceContractRegistryClientErrorCode, statusCode?: number | undefined, responseBody?: string | undefined);
}
export declare class ServiceContractRegistryClient {
    private readonly baseUrl;
    private readonly region;
    private readonly timeoutMs;
    private readonly softTtlMs;
    private readonly hardTtlMs;
    private readonly maxEntries;
    private readonly credentialsProvider;
    private readonly signer;
    private readonly cache;
    private readonly inFlight;
    constructor(props: ServiceContractRegistryClientProps);
    get<TValue extends Record<string, unknown> = Record<string, unknown>>(request: ContractPath, options?: GetContractOptions): Promise<ServiceContract<TValue>>;
    getByAccountRegion<TValue extends Record<string, unknown> = Record<string, unknown>>(request: AccountRegionContractPath, options?: GetContractOptions): Promise<ServiceContract<TValue>>;
    listAll<TValue extends Record<string, unknown> = Record<string, unknown>>(): Promise<ServiceContract<TValue>[]>;
    put<TValue extends Record<string, unknown> = Record<string, unknown>>(request: PutContractRequest<TValue>): Promise<ServiceContract<TValue>>;
    clearCache(): void;
    private getCached;
    private refresh;
    private setCache;
    private request;
    private requestContracts;
    private signRequest;
}
