import { type ServiceContract, type ServiceContractRegistryClientProps } from './client-service-contract-registry';
export interface GetServiceContractCdkContextProps {
    registry: ServiceContractRegistryClientProps;
}
export interface LoadServiceContractCdkContextProps {
    contextFile: string;
}
export type ServiceContractCdkContextData = Record<string, readonly ServiceContract[]>;
export declare class ServiceContractCdkContext {
    static readonly contextKeyPrefix = "jompx:service-contract";
    static getContext(props: GetServiceContractCdkContextProps): Promise<ServiceContractCdkContextData>;
    static loadContext(props: LoadServiceContractCdkContextProps): ServiceContractCdkContextData;
}
