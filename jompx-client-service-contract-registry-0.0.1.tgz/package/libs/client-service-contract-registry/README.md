# @jompx/client-service-contract-registry

## Purpose

Node.js client for reading and publishing service contracts from the Jompx Service Contract Registry.

Use it for:

- runtime contract reads by environment name
- runtime contract reads by account and region
- deployment-time contract publishing
- CDK context bootstrap for `ServiceContractLookup`

## Install

```bash
npm install @jompx/client-service-contract-registry
```

## Usage

Runtime read by environment name:

```ts
import { ServiceContractRegistryClient } from '@jompx/client-service-contract-registry';

type DatabaseMigrationExecutorConfig = {
  projectArn: string;
};

const client = new ServiceContractRegistryClient({
  baseUrl: 'https://contracts.company.com',
  region: 'us-east-1',
});

const contract = await client.get<DatabaseMigrationExecutorConfig>({
  environmentName: 'prod',
  contractName: 'DatabaseMigrationExecutorConfig',
  schemaVersion: '1',
});
```

Runtime read by account and region:

```ts
const contract = await client.getByAccountRegion<DatabaseMigrationExecutorConfig>({
  accountId: '123456789012',
  region: 'us-east-1',
  contractName: 'DatabaseMigrationExecutorConfig',
  schemaVersion: '1',
});
```

List all contracts:

```ts
const contracts = await client.listAll();
```

Publish a contract:

```ts
await client.put({
  environmentName: 'prod',
  accountId: '123456789012',
  region: 'us-east-1',
  contractName: 'DatabaseMigrationExecutorConfig',
  schemaVersion: '1',
  value: {
    projectArn: 'arn:aws:codebuild:us-east-1:123456789012:project/migrations',
  },
});
```

CDK context bootstrap:

```ts
import * as cdk from 'aws-cdk-lib';
import { writeFileSync } from 'node:fs';
import { ServiceContractCdkContext } from '@jompx/client-service-contract-registry';

const contextData = await ServiceContractCdkContext.getContext({
  registry: {
    baseUrl: 'https://contracts.company.com',
    region: 'us-east-1',
  },
});

const contextFile = 'apps/infra/contracts.context.json';

writeFileSync(contextFile, `${JSON.stringify(contextData, null, 2)}\n`, 'utf-8');

const app = new cdk.App({
  context: ServiceContractCdkContext.loadContext({ contextFile }),
});
```

## Configuration

- `baseUrl`: required HTTPS registry endpoint
- `region`: required AWS region for SigV4 signing
- `credentialsProvider`: optional custom AWS credentials provider
- `timeoutMs`: request timeout, default `10000`
- `cache.softTtlMs`: in-memory soft TTL, default `60000`
- `cache.hardTtlMs`: in-memory hard TTL, default `300000`
- `cache.maxEntries`: in-memory cache size, default `100`

Authentication and behavior:

- requests are signed with AWS SigV4
- default credentials come from the AWS SDK default provider chain unless `credentialsProvider` is supplied
- callers need `execute-api:Invoke` permission on the registry API
- reads are cached in memory per client instance
