# @jompx/contracts-client

Node.js client for the Jompx Service Contract Registry.

Use it when a service needs another AWS CDK deployed service's public contract at runtime, for example an ECS task ARN, Step Function ARN, API endpoint, queue ARN, or table name.

## Install

```bash
npm install @jompx/contracts-client
```

## Usage

```ts
import { ContractsClient } from '@jompx/contracts-client';

const contracts = new ContractsClient({
  baseUrl: 'https://contracts.company.com',
  // Region where the registry API is deployed.
  region: 'us-east-1',
});

const migrationExecutor = await contracts.get({
  environmentName: 'prod',
  contractName: 'DatabaseMigrationExecutorConfig',
  schemaVersion: '1',
});
```

Use `forceRefresh` when a deploy just happened and the service needs the latest value immediately.

```ts
const freshMigrationExecutor = await contracts.get(
  {
    environmentName: 'prod',
    contractName: 'DatabaseMigrationExecutorConfig',
    schemaVersion: '1',
  },
  {
    forceRefresh: true,
  }
);
```

## Exact Lookup

Use account/region lookup when the friendly environment name is not the best identifier.

```ts
const migrationExecutor = await contracts.getByAccountRegion({
  accountId: '123456789012',
  region: 'us-east-1',
  contractName: 'DatabaseMigrationExecutorConfig',
  schemaVersion: '1',
});
```

## Publishing

Use `put` from deployment tooling, not normal business request handlers.

```ts
await contracts.put({
  environmentName: 'prod',
  accountId: '123456789012',
  region: 'us-east-1',
  contractName: 'DatabaseMigrationExecutorConfig',
  schemaVersion: '1',
  value: {
    clusterArn: 'arn:aws:ecs:us-east-1:123456789012:cluster/migrations',
    taskDefinitionArn: 'arn:aws:ecs:us-east-1:123456789012:task-definition/migrations:1',
  },
});
```

## Runtime Behavior

- Requires HTTPS.
- Signs requests with AWS SigV4 using the default AWS credential chain.
- Requires `execute-api:Invoke` permission on the registry API.
- Caches reads in memory: 60s soft TTL, 5m hard TTL, 100 entries.
- Coalesces duplicate in-flight reads.
- Falls back to the last-known-good value if refresh fails and a cached value exists.
- Supports lookup by friendly environment name or by account/region.

## Errors

```ts
try {
  await contracts.get({ environmentName, contractName, schemaVersion });
} catch (error) {
  // error.code can be Validation, Unauthorized, Forbidden, NotFound, Network, or Http.
  throw error;
}
```

## Building

Run `nx build contracts-client` to build the library.

## Running unit tests

Run `nx test contracts-client` to execute the unit tests via [Jest](https://jestjs.io).
