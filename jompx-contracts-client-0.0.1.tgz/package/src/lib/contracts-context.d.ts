import { type ServiceContract, type ContractsClientProps } from './contracts-client';
export interface GetContractsContextProps {
    registry: ContractsClientProps;
}
export interface LoadContractsContextProps {
    contextFile: string;
}
export type ContractsContextData = Record<string, readonly ServiceContract[]>;
export declare class ContractsContext {
    static readonly contextKeyPrefix = "jompx:service-contract";
    static getContext(props: GetContractsContextProps): Promise<ContractsContextData>;
    static loadContext(props: LoadContractsContextProps): ContractsContextData;
}
