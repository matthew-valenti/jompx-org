# @jompx/contracts-client

Node.js client for the Jompx Service Contract Registry.

Use it when a service needs another AWS CDK deployed service's public contract at runtime, for example an ECS task ARN, Step Function ARN, API endpoint, queue ARN, or table name.

## Install

```bash
npm install @jompx/contracts-client
```

## Runtime Get

```ts
import { ContractsClient } from '@jompx/contracts-client';

type T = {
  roleArn: string;
  clusterArn: string;
  taskDefinitionArn: string;
};

const contracts = new ContractsClient({
  baseUrl: 'https://contracts.company.com',
  region: 'us-east-1',
});

const migrationExecutor = await contracts.get<T>({
  environmentName: 'prod',
  contractName: 'DatabaseMigrationExecutorConfig',
  schemaVersion: '1',
});
```

Use account and region when the friendly environment name is not the best identifier.

```ts
type T = {
  roleArn: string;
  clusterArn: string;
  taskDefinitionArn: string;
};

const migrationExecutor = await contracts.getByAccountRegion<T>({
  accountId: '123456789012',
  region: 'us-east-1',
  contractName: 'DatabaseMigrationExecutorConfig',
  schemaVersion: '1',
});
```

Reuse the same client instance to reuse the in-process cache.

```ts
const first = await contracts.get({
  environmentName: 'prod',
  contractName: 'DatabaseMigrationExecutorConfig',
  schemaVersion: '1',
});

const second = await contracts.get({
  environmentName: 'prod',
  contractName: 'DatabaseMigrationStoreConfig',
  schemaVersion: '1',
});
```

## Deploy-Time Lookup

Use `ContractsClient` for runtime reads and `ContractsContext` for deploy-time context bootstrap.

Fetch contract context before creating the CDK app:

```ts
import { ContractsContext } from '@jompx/contracts-client';

const contextData = await ContractsContext.getContext({
  registry: {
    baseUrl: 'https://contracts.company.com',
    region: 'us-east-1',
  },
});
```

Write it to a file in your executor or pipeline step, then load it synchronously into the CDK app:

```ts
import * as cdk from 'aws-cdk-lib';
import { readFileSync, writeFileSync } from 'node:fs';
import { ContractsContext } from '@jompx/contracts-client';

const contextFile = 'apps/infra/contracts.context.json';

writeFileSync(contextFile, `${JSON.stringify(contextData, null, 2)}\n`, 'utf-8');

const appContext = ContractsContext.loadContext({ contextFile });

const app = new cdk.App({ context: appContext });
```

`ContractsContext.getContext()` returns plain contract context data. `ContractsContext.loadContext()` reads a written context file synchronously for the CDK app.
Each published contract appears once in that context payload. `lookup()` and `lookupByEnvironmentName()` both resolve from the same canonical entry.

Pass `contextFile` explicitly:

```ts
const contextData = await ContractsContext.getContext({
  registry: {
    baseUrl: 'https://contracts.company.com',
    region: 'us-east-1',
  },
});

const contextFile = 'apps/infra/custom-contracts.context.json';
writeFileSync(contextFile, `${JSON.stringify(contextData, null, 2)}\n`, 'utf-8');

const appContext = ContractsContext.loadContext({
  contextFile,
});
```

Pass `registry.credentialsProvider` when the bootstrap step should use a specific AWS profile or other custom credentials source:

```ts
import { fromIni } from '@aws-sdk/credential-providers';
import { ContractsContext } from '@jompx/contracts-client';

const contextData = await ContractsContext.getContext({
  registry: {
    baseUrl: 'https://contracts.company.com',
    region: 'us-east-1',
    credentialsProvider: fromIni({ profile: 'my-profile' }),
  },
});
```

This keeps synth inputs explicit and leaves room to merge in additional context later.

`ContractsContext` fetches the full registry snapshot during app bootstrap. CDK lookups remain exact and synchronous inside constructs.

Use `lookup()` when the producer account and region are known:

```ts
import { ServiceContractLookup } from '@jompx/constructs';

type T = {
  roleArn: string;
  clusterArn: string;
  taskDefinitionArn: string;
};

const executor = ServiceContractLookup.lookup<T>(this, {
  accountId: '123456789012',
  region: 'us-east-1',
  contractName: 'DatabaseMigrationExecutorConfig',
  schemaVersion: '1',
});
```

Use `lookupByEnvironmentName()` when the friendly environment name is the better identifier:

```ts
type T = {
  roleArn: string;
  clusterArn: string;
  taskDefinitionArn: string;
};

const executor = ServiceContractLookup.lookupByEnvironmentName<T>(this, {
  environmentName: 'prod',
  contractName: 'DatabaseMigrationExecutorConfig',
  schemaVersion: '1',
});
```

## Publishing

Use `put` from deployment tooling, not normal business request handlers.

```ts
const contracts = new ContractsClient({
  baseUrl: 'https://contracts.company.com',
  region: 'us-east-1',
});

await contracts.put({
  environmentName: 'prod',
  accountId: '123456789012',
  region: 'us-east-1',
  contractName: 'DatabaseMigrationExecutorConfig',
  schemaVersion: '1',
  value: {
    clusterArn: 'arn:aws:ecs:us-east-1:123456789012:cluster/migrations',
    taskDefinitionArn: 'arn:aws:ecs:us-east-1:123456789012:task-definition/migrations:1',
  },
});
```

## Runtime Behavior

- Requires HTTPS.
- Signs requests with AWS SigV4 using the default AWS credential chain.
- Requires `execute-api:Invoke` permission on the registry API.
- Caches reads in memory: 60s soft TTL, 5m hard TTL, 100 entries.
- Coalesces duplicate in-flight reads.
- Falls back to the last-known-good value if refresh fails and a cached value exists.
- Supports reads by friendly environment name or by account/region.

## Errors

```ts
try {
  await contracts.get({
    environmentName,
    contractName,
    schemaVersion,
  });
} catch (error) {
  // error.code can be Validation, Unauthorized, Forbidden, NotFound, Network, or Http.
  throw error;
}
```

## Building

Run `nx build contracts-client` to build the library.

## Running unit tests

Run `nx test contracts-client` to execute the unit tests via [Jest](https://jestjs.io).
