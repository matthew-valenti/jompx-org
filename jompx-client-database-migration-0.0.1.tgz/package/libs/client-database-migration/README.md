# @jompx/client-database-migration

## Purpose

Thin Node.js client that runs a Jompx database migration end-to-end: zips migration source, uploads it to the [Database Migration](../constructs/src/lib/database-migration/database-migration.md) Store, starts the Orchestrator, waits for completion, and returns the persisted result.

## Install

```bash
npm install @jompx/client-database-migration
```

## Usage

```ts
import { fromIni } from '@aws-sdk/credential-providers';
import { runDatabaseMigration } from '@jompx/client-database-migration';

const result = await runDatabaseMigration({
  credentialsProvider: fromIni({ profile: 'sandbox1' }),
  submission: {
    baseUrl: 'https://upload-url.lambda-url.us-west-2.on.aws',
    region: 'us-west-2',
  },
  registry: {
    baseUrl: 'https://contracts.example.com',
    region: 'us-west-2',
  },
  executorContract: {
    name: 'MyDatabaseMigrationExecutorStack',
    accountId: '123456789012',
    region: 'us-west-2',
  },
  orchestratorContract: {
    name: 'MyDatabaseMigrationOrchestratorStack',
    accountId: '123456789012',
    region: 'us-west-2',
  },
  databaseName: 'app_sandbox1',
  migrationFilesPath: 'libs/database-migration/src/lib/app',
  direction: 'up',
});
```

`runDatabaseMigration()`:

1. zips `migrationFilesPath` locally
2. reads the Executor and Orchestrator contracts from the Service Contract Registry
3. creates a multipart upload through the Store's submission endpoint and uploads directly to S3
4. starts the Orchestrator execution and polls Step Functions until it finishes
5. fetches and returns the persisted run result

It resolves with the run result on success and throws `DatabaseMigrationRunFailedError` (carrying `uploadId`, `executionArn`, `executionStatus`, and the persisted run when available) if the execution or the migration run itself did not succeed.

## Configuration

- `credentialsProvider`: optional AWS credentials provider; defaults to the AWS SDK default provider chain
- `submission.baseUrl` / `submission.region`: the Store's submission Function URL (its stack's `SubmissionBaseUrl` output) and the region it runs in
- `registry.baseUrl` / `registry.region`: the Service Contract Registry endpoint used to resolve `executorContract` and `orchestratorContract`
- `executorContract` / `orchestratorContract`: `{ name, accountId, region, schemaVersion? }` - `name` is the producer stack's published contract name; `schemaVersion` defaults to `'1'`
- `migrationFilesPath`: local directory zipped and uploaded as the migration artifact
- `databaseName`: logical database name passed through to the Executor
- `direction`: `'up' | 'down'` - both directions upload the full migration set, not just a delta
- `downSteps`: optional positive integer for `direction: 'down'`; passed straight through to Umzug's `down({ step })`
