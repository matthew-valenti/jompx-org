import { type CredentialsProvider } from '@jompx/client-service-contract-registry';
export declare const assetPath: string;
export interface DatabaseMigrationSubmissionProps {
    baseUrl: string;
    region: string;
}
export interface DatabaseMigrationRegistryProps {
    baseUrl: string;
    region: string;
}
export interface RunDatabaseMigrationOrchestratorContractProps {
    name: string;
    accountId: string;
    region: string;
    schemaVersion?: string;
}
export interface RunDatabaseMigrationExecutorContractProps {
    name: string;
    accountId: string;
    region: string;
    schemaVersion?: string;
}
export interface RunDatabaseMigrationProps {
    credentialsProvider?: CredentialsProvider;
    submission: DatabaseMigrationSubmissionProps;
    registry: DatabaseMigrationRegistryProps;
    orchestratorContract: RunDatabaseMigrationOrchestratorContractProps;
    executorContract: RunDatabaseMigrationExecutorContractProps;
    databaseName: string;
    migrationFilesPath: string;
    direction: 'up' | 'down';
    downSteps?: number;
}
export interface RunDatabaseMigrationResult {
    uploadId: string;
    stateMachineArn: string;
    executionArn: string;
    startDate: string;
    executionStatus: 'SUCCEEDED';
    run: DatabaseMigrationRunRecord;
}
export interface DatabaseMigrationRunRecord {
    uploadId: string;
    status: 'succeeded' | 'failed';
    targetId: string;
    databaseName: string;
    direction: 'up' | 'down';
    engine: string;
    startedAt: string;
    finishedAt: string;
    ownerId: string;
    migration: {
        direction: 'up' | 'down';
        requested: string[];
        executed: string[];
        pending: string[];
        failed?: {
            name: string;
            cause: string;
        };
        error?: {
            message: string;
            name?: string;
        };
    };
    build: {
        id?: string;
        arn?: string;
        region?: string;
        detailsUrl?: string;
    };
    error?: {
        message: string;
        name?: string;
    };
}
type DatabaseMigrationExecutionStatus = 'RUNNING' | 'SUCCEEDED' | 'FAILED' | 'TIMED_OUT' | 'ABORTED';
export declare class DatabaseMigrationRunFailedError extends Error {
    readonly uploadId: string;
    readonly executionArn: string;
    readonly executionStatus: Exclude<DatabaseMigrationExecutionStatus, 'RUNNING' | 'SUCCEEDED'>;
    readonly run?: DatabaseMigrationRunRecord;
    constructor(props: {
        uploadId: string;
        executionArn: string;
        executionStatus: Exclude<DatabaseMigrationExecutionStatus, 'RUNNING' | 'SUCCEEDED'>;
        run?: DatabaseMigrationRunRecord;
        cause?: string;
    });
}
export declare function runDatabaseMigration(props: RunDatabaseMigrationProps): Promise<RunDatabaseMigrationResult>;
export {};
