import * as mysql2 from 'mysql2/promise';
import { MysqlDatabaseClientProps } from './mysql-database-client.types';

export class MysqlDatabaseClient {
  private pool: mysql2.Pool | undefined;
  private connection: mysql2.Connection | undefined;

  constructor(private readonly props: MysqlDatabaseClientProps) {}

  public async getPool(): Promise<mysql2.Pool> {
    if (!this.pool) {
      this.pool = await this.createPool();
    }

    return this.pool;
  }

  public async getConnection(): Promise<mysql2.Connection> {
    if (!this.connection) {
      this.connection = await this.createConnection();
    }

    return this.connection;
  }

  public async createPool(): Promise<mysql2.Pool> {
    this.assertSecret();

    return mysql2.createPool({
      host: this.props.secret.host,
      port: this.props.secret.port,
      user: this.props.secret.username,
      password: this.props.secret.password,
      database: this.props.secret.database,
      connectionLimit: this.props.pool?.max,
      idleTimeout: this.props.pool?.idleTimeoutMs,
      connectTimeout: this.props.pool?.connectionTimeoutMs,
    } as any);
  }

  public async createConnection(): Promise<mysql2.Connection> {
    this.assertSecret();

    return mysql2.createConnection({
      host: this.props.secret.host,
      port: this.props.secret.port,
      user: this.props.secret.username,
      password: this.props.secret.password,
      database: this.props.secret.database,
    });
  }

  public async close(): Promise<void> {
    if (this.connection) {
      await this.connection.end();
      this.connection = undefined;
    }

    if (this.pool) {
      await this.pool.end();
      this.pool = undefined;
    }
  }

  private assertSecret(): void {
    const missing: string[] = [];

    if (!this.props.secret?.host) missing.push('host');
    if (!this.props.secret?.username) missing.push('username');
    if (!this.props.secret?.password) missing.push('password');
    if (!this.props.secret?.database) missing.push('database');
    if (!Number.isInteger(this.props.secret?.port) || (this.props.secret?.port ?? 0) <= 0) missing.push('port');

    if (missing.length) {
      throw new Error(`Jompx.MysqlDatabaseClient: Missing or invalid SQL secret properties: ${missing.join(', ')}.`);
    }
  }
}
