export interface PostgresConnectionSecretValue {
  host: string;
  port: number;
  username: string;
  password: string;
  database: string;
}

export interface PostgresDatabaseClientPoolOptions {
  max?: number;
  idleTimeoutMs?: number;
  connectionTimeoutMs?: number;
}

export interface PostgresDatabaseClientProps {
  secret: PostgresConnectionSecretValue;
  pool?: PostgresDatabaseClientPoolOptions;
}
