"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
//# sourceMappingURL=dynamodb-database-client.types.js.map