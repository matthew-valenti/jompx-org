import * as mysql2 from 'mysql2/promise';
import { MysqlDatabaseClientProps } from './mysql-database-client.types';
export declare class MysqlDatabaseClient {
    private readonly props;
    private pool;
    private connection;
    constructor(props: MysqlDatabaseClientProps);
    getPool(): Promise<mysql2.Pool>;
    getConnection(): Promise<mysql2.Connection>;
    createPool(): Promise<mysql2.Pool>;
    createConnection(): Promise<mysql2.Connection>;
    close(): Promise<void>;
    private assertSecret;
}
