"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PostgresDatabaseClient = void 0;
const pg = require("pg");
class PostgresDatabaseClient {
    constructor(props) {
        this.props = props;
    }
    async getPool() {
        if (!this.pool) {
            this.pool = await this.createPool();
        }
        return this.pool;
    }
    async query(sql, values) {
        await this.withTransportRetry(async () => {
            const pool = await this.getPool();
            await pool.query(sql, values);
        });
    }
    async createPool() {
        this.assertSecret();
        console.log(JSON.stringify({
            level: 'info',
            event: 'database-migration.postgres.pool-config',
            host: this.props.secret.host,
            port: this.props.secret.port,
            database: this.props.secret.database,
            user: this.props.secret.username,
            poolMax: this.props.pool?.max ?? 5,
            idleTimeoutMillis: this.props.pool?.idleTimeoutMs ?? 300000,
            connectionTimeoutMillis: this.props.pool?.connectionTimeoutMs ?? 10000,
            sslEnabled: true,
            rejectUnauthorized: false,
            hasDatabaseUrlEnv: Boolean(process.env['DATABASE_URL']),
            hasPgSslModeEnv: Boolean(process.env['PGSSLMODE']),
        }));
        return new pg.Pool({
            host: this.props.secret.host,
            port: this.props.secret.port,
            user: this.props.secret.username,
            password: this.props.secret.password,
            database: this.props.secret.database,
            max: this.props.pool?.max ?? 5,
            idleTimeoutMillis: this.props.pool?.idleTimeoutMs ?? 300000,
            connectionTimeoutMillis: this.props.pool?.connectionTimeoutMs ?? 10000,
            ssl: {
                rejectUnauthorized: false,
            },
        });
    }
    async close() {
        if (this.pool) {
            await this.pool.end();
            this.pool = undefined;
        }
    }
    async withTransportRetry(fn) {
        try {
            return await fn();
        }
        catch (error) {
            console.error(JSON.stringify({
                level: 'error',
                event: 'database-migration.postgres.query.failed',
                code: error?.code,
                message: error instanceof Error ? error.message : String(error),
            }));
            if (!this.isTransportError(error)) {
                throw error;
            }
            await this.close();
            await this.getPool();
            return await fn();
        }
    }
    isTransportError(error) {
        const code = error?.code;
        const message = (error?.message ?? '').toLowerCase();
        if (code &&
            new Set([
                'ECONNRESET',
                'ECONNREFUSED',
                'ETIMEDOUT',
                'EPIPE',
                'ENOTFOUND',
                'EAI_AGAIN',
                '57P01',
                '57P02',
                '57P03',
            ]).has(code)) {
            return true;
        }
        return [
            'connection terminated unexpectedly',
            'server closed the connection unexpectedly',
            'terminating connection due to administrator command',
            'connection not open',
            'socket hang up',
        ].some((fragment) => message.includes(fragment));
    }
    assertSecret() {
        const missing = [];
        if (!this.props.secret?.host)
            missing.push('host');
        if (!this.props.secret?.username)
            missing.push('username');
        if (!this.props.secret?.password)
            missing.push('password');
        if (!this.props.secret?.database)
            missing.push('database');
        if (!Number.isInteger(this.props.secret?.port) || (this.props.secret?.port ?? 0) <= 0)
            missing.push('port');
        if (missing.length) {
            throw new Error(`Jompx.PostgresDatabaseClient: Missing or invalid SQL secret properties: ${missing.join(', ')}.`);
        }
    }
}
exports.PostgresDatabaseClient = PostgresDatabaseClient;
//# sourceMappingURL=postgres-database-client.js.map