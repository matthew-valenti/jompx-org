export interface MysqlConnectionSecretValue {
  host: string;
  port: number;
  username: string;
  password: string;
  database: string;
}

export interface MysqlDatabaseClientPoolOptions {
  max?: number;
  idleTimeoutMs?: number;
  connectionTimeoutMs?: number;
}

export interface MysqlDatabaseClientProps {
  secret: MysqlConnectionSecretValue;
  pool?: MysqlDatabaseClientPoolOptions;
}
