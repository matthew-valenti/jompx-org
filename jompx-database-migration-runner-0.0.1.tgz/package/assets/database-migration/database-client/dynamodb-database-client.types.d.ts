import type { DynamoDBClientConfig } from '@aws-sdk/client-dynamodb';
export interface DynamoDbDatabaseClientProps {
    config?: DynamoDBClientConfig;
}
