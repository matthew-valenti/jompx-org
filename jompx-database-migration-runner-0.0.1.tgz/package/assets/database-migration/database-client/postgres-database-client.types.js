"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
//# sourceMappingURL=postgres-database-client.types.js.map