"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.MysqlDatabaseClient = void 0;
const mysql2 = require("mysql2/promise");
class MysqlDatabaseClient {
    constructor(props) {
        this.props = props;
    }
    async getPool() {
        if (!this.pool) {
            this.pool = await this.createPool();
        }
        return this.pool;
    }
    async getConnection() {
        if (!this.connection) {
            this.connection = await this.createConnection();
        }
        return this.connection;
    }
    async createPool() {
        this.assertSecret();
        return mysql2.createPool({
            host: this.props.secret.host,
            port: this.props.secret.port,
            user: this.props.secret.username,
            password: this.props.secret.password,
            database: this.props.secret.database,
            connectionLimit: this.props.pool?.max,
            idleTimeout: this.props.pool?.idleTimeoutMs,
            connectTimeout: this.props.pool?.connectionTimeoutMs,
        });
    }
    async createConnection() {
        this.assertSecret();
        return mysql2.createConnection({
            host: this.props.secret.host,
            port: this.props.secret.port,
            user: this.props.secret.username,
            password: this.props.secret.password,
            database: this.props.secret.database,
        });
    }
    async close() {
        if (this.connection) {
            await this.connection.end();
            this.connection = undefined;
        }
        if (this.pool) {
            await this.pool.end();
            this.pool = undefined;
        }
    }
    assertSecret() {
        const missing = [];
        if (!this.props.secret?.host)
            missing.push('host');
        if (!this.props.secret?.username)
            missing.push('username');
        if (!this.props.secret?.password)
            missing.push('password');
        if (!this.props.secret?.database)
            missing.push('database');
        if (!Number.isInteger(this.props.secret?.port) || (this.props.secret?.port ?? 0) <= 0)
            missing.push('port');
        if (missing.length) {
            throw new Error(`Jompx.MysqlDatabaseClient: Missing or invalid SQL secret properties: ${missing.join(', ')}.`);
        }
    }
}
exports.MysqlDatabaseClient = MysqlDatabaseClient;
//# sourceMappingURL=mysql-database-client.js.map