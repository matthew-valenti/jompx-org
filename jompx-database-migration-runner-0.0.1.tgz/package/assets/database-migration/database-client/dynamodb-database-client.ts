import { DynamoDBClient } from '@aws-sdk/client-dynamodb';
import { DynamoDBDocumentClient } from '@aws-sdk/lib-dynamodb';
import { DynamoDbDatabaseClientProps } from './dynamodb-database-client.types';

export class DynamoDbDatabaseClient {
  private client: DynamoDBDocumentClient | undefined;

  constructor(private readonly props: DynamoDbDatabaseClientProps = {}) {}

  public getClient(): DynamoDBDocumentClient {
    if (!this.client) {
      this.client = DynamoDBDocumentClient.from(new DynamoDBClient(this.props.config ?? {}));
    }

    return this.client;
  }
}
