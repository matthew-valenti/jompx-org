"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DynamoDbDatabaseClient = void 0;
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
class DynamoDbDatabaseClient {
    constructor(props = {}) {
        this.props = props;
    }
    getClient() {
        if (!this.client) {
            this.client = lib_dynamodb_1.DynamoDBDocumentClient.from(new client_dynamodb_1.DynamoDBClient(this.props.config ?? {}));
        }
        return this.client;
    }
}
exports.DynamoDbDatabaseClient = DynamoDbDatabaseClient;
//# sourceMappingURL=dynamodb-database-client.js.map