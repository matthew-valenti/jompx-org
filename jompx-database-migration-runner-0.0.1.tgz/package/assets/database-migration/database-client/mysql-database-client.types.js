"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
//# sourceMappingURL=mysql-database-client.types.js.map