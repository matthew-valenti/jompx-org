import { DynamoDBDocumentClient } from '@aws-sdk/lib-dynamodb';
import { DynamoDbDatabaseClientProps } from './dynamodb-database-client.types';
export declare class DynamoDbDatabaseClient {
    private readonly props;
    private client;
    constructor(props?: DynamoDbDatabaseClientProps);
    getClient(): DynamoDBDocumentClient;
}
