import * as pg from 'pg';
import { PostgresDatabaseClientProps } from './postgres-database-client.types';
export declare class PostgresDatabaseClient {
    private readonly props;
    private pool;
    constructor(props: PostgresDatabaseClientProps);
    getPool(): Promise<pg.Pool>;
    query(sql: string, values?: unknown[]): Promise<void>;
    private createPool;
    close(): Promise<void>;
    private withTransportRetry;
    private isTransportError;
    private assertSecret;
}
