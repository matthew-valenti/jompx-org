import { runDatabaseMigrationFromEnv } from './database-migration/database-migration-runner';

runDatabaseMigrationFromEnv().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
