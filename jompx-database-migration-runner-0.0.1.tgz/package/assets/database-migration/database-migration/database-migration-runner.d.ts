import { DatabaseMigrationDirection, DatabaseMigrationEngine, DatabaseMigrationRunnerConfig } from './database-migration-context-factory';
export interface DatabaseMigrationRuntimeEnvironment {
    [key: string]: string | undefined;
    AWS_REGION?: string;
    CODEBUILD_BUILD_ID?: string;
    DATABASE_MIGRATION_ARTIFACT_OBJECT_KEY?: string;
    DATABASE_MIGRATION_DATABASE_NAME?: string;
    DATABASE_MIGRATION_DIRECTION?: DatabaseMigrationDirection;
    DATABASE_MIGRATION_ENGINE?: DatabaseMigrationEngine;
    DATABASE_MIGRATION_LOCK_TTL_SECONDS?: string;
    DATABASE_MIGRATION_SECRET_NAME?: string;
    DATABASE_MIGRATION_STORE_BUCKET_NAME?: string;
    DATABASE_MIGRATION_STORE_GSI1_NAME?: string;
    DATABASE_MIGRATION_STORE_ROLE_ARN?: string;
    DATABASE_MIGRATION_STORE_TABLE_NAME?: string;
    DATABASE_MIGRATION_TARGET_ID?: string;
}
export declare class DatabaseMigrationRunner {
    private readonly config;
    constructor(config: DatabaseMigrationRunnerConfig);
    run(): Promise<void>;
    private createContext;
    private closeContext;
    private readConnectionSecret;
    private prepareMigrationDirectory;
    private downloadArtifact;
    private loadMigrations;
    private runSql;
    private toMigrationNames;
    private logInfo;
    private logError;
}
export declare function runDatabaseMigrationFromEnv(environment?: DatabaseMigrationRuntimeEnvironment): Promise<void>;
