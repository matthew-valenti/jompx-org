import type { MigrationParams, UmzugStorage } from 'umzug';
import { DatabaseMigrationStore } from './database-migration-store';
export declare class DatabaseMigrationUmzugStorage<Ctx = unknown> implements UmzugStorage<Ctx> {
    private readonly targetId;
    private readonly store;
    constructor(targetId: string, store: DatabaseMigrationStore);
    logMigration(params: MigrationParams<Ctx>): Promise<void>;
    unlogMigration(params: MigrationParams<Ctx>): Promise<void>;
    executed(_meta: Pick<MigrationParams<Ctx>, 'context'>): Promise<string[]>;
}
