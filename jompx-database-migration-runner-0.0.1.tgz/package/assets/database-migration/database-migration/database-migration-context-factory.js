"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DatabaseMigrationContextFactory = void 0;
const dynamodb_database_client_1 = require("../database-client/dynamodb-database-client");
const mysql_database_client_1 = require("../database-client/mysql-database-client");
const postgres_database_client_1 = require("../database-client/postgres-database-client");
class DatabaseMigrationContextFactory {
    constructor(config, readConnectionSecret) {
        this.config = config;
        this.readConnectionSecret = readConnectionSecret;
    }
    async create() {
        if (this.config.engine === 'dynamodb') {
            return new dynamodb_database_client_1.DynamoDbDatabaseClient({
                config: {
                    ...(this.config.region && { region: this.config.region }),
                },
            }).getClient();
        }
        if (!this.config.secretName) {
            throw new Error(`DATABASE_MIGRATION_SECRET_NAME is required for engine ${this.config.engine}.`);
        }
        const secret = await this.readConnectionSecret(this.config.secretName);
        if (this.config.engine.startsWith('mysql')) {
            const client = new mysql_database_client_1.MysqlDatabaseClient({
                secret,
            });
            const connection = await client.getConnection();
            return {
                query: async (sql, values) => {
                    await connection.query(sql, values);
                },
                close: async () => {
                    await client.close();
                },
            };
        }
        if (this.config.engine === 'postgres_17.x') {
            const client = new postgres_database_client_1.PostgresDatabaseClient({
                secret,
            });
            return {
                query: async (sql, values) => {
                    await client.query(sql, values);
                },
                close: async () => {
                    await client.close();
                },
            };
        }
        throw new Error(`Engine ${this.config.engine} is not yet supported by the migration runner.`);
    }
}
exports.DatabaseMigrationContextFactory = DatabaseMigrationContextFactory;
//# sourceMappingURL=database-migration-context-factory.js.map