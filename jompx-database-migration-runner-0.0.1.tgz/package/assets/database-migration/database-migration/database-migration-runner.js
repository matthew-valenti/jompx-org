"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.runDatabaseMigrationFromEnv = exports.DatabaseMigrationRunner = void 0;
const client_s3_1 = require("@aws-sdk/client-s3");
const client_secrets_manager_1 = require("@aws-sdk/client-secrets-manager");
const child_process_1 = require("child_process");
const fg = require("fast-glob");
const fs_1 = require("fs");
const path = require("path");
const promises_1 = require("stream/promises");
const util_1 = require("util");
const url_1 = require("url");
const assume_role_credentials_1 = require("./assume-role-credentials");
const umzug_1 = require("umzug");
const database_migration_context_factory_1 = require("./database-migration-context-factory");
const database_migration_store_1 = require("./database-migration-store");
const database_migration_umzug_storage_1 = require("./database-migration-umzug-storage");
const execFileAsync = (0, util_1.promisify)(child_process_1.execFile);
class DatabaseMigrationRunner {
    constructor(config) {
        this.config = config;
    }
    async run() {
        const ownerId = `codebuild-${process.env['CODEBUILD_BUILD_ID'] ?? Date.now()}`;
        const startedAt = new Date().toISOString();
        const expiresAt = new Date(Date.now() + this.config.lockTtlSeconds * 1000).toISOString();
        let context;
        let migrationDirectory;
        const store = new database_migration_store_1.DatabaseMigrationStore({
            tableName: this.config.metadataStore.tableName,
            gsi1Name: this.config.metadataStore.gsi1Name,
            storeRoleArn: this.config.metadataStore.storeRoleArn,
            region: this.config.region,
        });
        this.logInfo('database-migration.started', {
            targetId: this.config.targetId,
            engine: this.config.engine,
            direction: this.config.direction,
        });
        this.logInfo('database-migration.lock.acquire.started', {
            targetId: this.config.targetId,
            ownerId,
        });
        await store.acquireLock({
            targetId: this.config.targetId,
            ownerId,
            acquiredAt: startedAt,
            expiresAt,
        });
        this.logInfo('database-migration.lock.acquire.succeeded', {
            targetId: this.config.targetId,
            ownerId,
        });
        try {
            this.logInfo('database-migration.artifact.prepare.started', {
                targetId: this.config.targetId,
                artifactBucketName: this.config.artifactBucketName,
                artifactObjectKey: this.config.artifactObjectKey,
            });
            migrationDirectory = await this.prepareMigrationDirectory();
            this.logInfo('database-migration.artifact.prepare.succeeded', {
                targetId: this.config.targetId,
                migrationDirectory,
            });
            this.logInfo('database-migration.context.create.started', {
                targetId: this.config.targetId,
                engine: this.config.engine,
                secretName: this.config.secretName,
            });
            context = await this.createContext();
            this.logInfo('database-migration.context.create.succeeded', {
                targetId: this.config.targetId,
                engine: this.config.engine,
            });
            this.logInfo('database-migration.migrations.load.started', {
                targetId: this.config.targetId,
                migrationDirectory,
            });
            const migrations = await this.loadMigrations(migrationDirectory, context);
            this.logInfo('database-migration.migrations.load.succeeded', {
                targetId: this.config.targetId,
                migrationCount: migrations.length,
                migrations: migrations.map((migration) => migration.name),
            });
            const umzug = new umzug_1.Umzug({
                migrations,
                context: context,
                storage: new database_migration_umzug_storage_1.DatabaseMigrationUmzugStorage(this.config.targetId, store),
                logger: console,
            });
            this.logInfo('database-migration.execute.started', {
                targetId: this.config.targetId,
                direction: this.config.direction,
            });
            const executed = this.config.direction === 'down' ? await umzug.down() : await umzug.up();
            this.logInfo('database-migration.succeeded', {
                targetId: this.config.targetId,
                engine: this.config.engine,
                direction: this.config.direction,
                migrations: this.toMigrationNames(executed),
            });
        }
        catch (error) {
            this.logError('database-migration.failed', error, {
                targetId: this.config.targetId,
                engine: this.config.engine,
                direction: this.config.direction,
            });
            throw error;
        }
        finally {
            if (context) {
                try {
                    this.logInfo('database-migration.context.close.started', {
                        targetId: this.config.targetId,
                    });
                    await this.closeContext(context);
                    this.logInfo('database-migration.context.close.succeeded', {
                        targetId: this.config.targetId,
                    });
                }
                catch (error) {
                    this.logError('database-migration.close-context.failed', error, {
                        targetId: this.config.targetId,
                        engine: this.config.engine,
                        direction: this.config.direction,
                    });
                }
            }
            if (migrationDirectory) {
                this.logInfo('database-migration.artifact.cleanup.started', {
                    targetId: this.config.targetId,
                    migrationDirectory,
                });
                await fs_1.promises.rm(migrationDirectory, { recursive: true, force: true });
                this.logInfo('database-migration.artifact.cleanup.succeeded', {
                    targetId: this.config.targetId,
                    migrationDirectory,
                });
            }
            this.logInfo('database-migration.lock.release.started', {
                targetId: this.config.targetId,
                ownerId,
            });
            await store.releaseLock({
                targetId: this.config.targetId,
                ownerId,
            });
            this.logInfo('database-migration.lock.release.succeeded', {
                targetId: this.config.targetId,
                ownerId,
            });
        }
    }
    async createContext() {
        return new database_migration_context_factory_1.DatabaseMigrationContextFactory(this.config, async (secretName) => this.readConnectionSecret(secretName)).create();
    }
    async closeContext(context) {
        if (typeof context === 'object' && context && 'close' in context && typeof context.close === 'function') {
            await context.close();
        }
    }
    async readConnectionSecret(secretName) {
        this.logInfo('database-migration.secret.read.started', {
            targetId: this.config.targetId,
            secretName,
        });
        const client = new client_secrets_manager_1.SecretsManagerClient({
            ...(this.config.region && { region: this.config.region }),
        });
        const response = await client.send(new client_secrets_manager_1.GetSecretValueCommand({
            SecretId: secretName,
        }));
        if (!response.SecretString) {
            throw new Error(`Secret ${secretName} did not include SecretString.`);
        }
        this.logInfo('database-migration.secret.read.succeeded', {
            targetId: this.config.targetId,
            secretName,
        });
        return {
            ...JSON.parse(response.SecretString),
            database: this.config.databaseName,
        };
    }
    async prepareMigrationDirectory() {
        const extractionDirectory = path.join('/tmp', 'database-migration', this.config.targetId, `${Date.now()}`);
        const archivePath = path.join(extractionDirectory, 'bundle.zip');
        this.logInfo('database-migration.artifact.directory.create.started', {
            targetId: this.config.targetId,
            extractionDirectory,
        });
        await fs_1.promises.mkdir(extractionDirectory, { recursive: true });
        this.logInfo('database-migration.artifact.directory.create.succeeded', {
            targetId: this.config.targetId,
            extractionDirectory,
        });
        await this.downloadArtifact(archivePath);
        this.logInfo('database-migration.artifact.unzip.started', {
            targetId: this.config.targetId,
            archivePath,
            extractionDirectory,
        });
        await execFileAsync('unzip', ['-q', archivePath, '-d', extractionDirectory]);
        this.logInfo('database-migration.artifact.unzip.succeeded', {
            targetId: this.config.targetId,
            extractionDirectory,
        });
        await fs_1.promises.rm(archivePath, { force: true });
        return extractionDirectory;
    }
    async downloadArtifact(destinationPath) {
        this.logInfo('database-migration.artifact.download.started', {
            targetId: this.config.targetId,
            artifactBucketName: this.config.artifactBucketName,
            artifactObjectKey: this.config.artifactObjectKey,
            assumeStoreRole: Boolean(this.config.metadataStore.storeRoleArn),
        });
        const credentials = this.config.metadataStore.storeRoleArn
            ? await (0, assume_role_credentials_1.assumeRoleCredentials)({
                roleArn: this.config.metadataStore.storeRoleArn,
                roleSessionName: `database-migration-artifact-${Date.now()}`,
                region: this.config.region,
            })
            : undefined;
        if (credentials) {
            this.logInfo('database-migration.artifact.download.assume-store-role.succeeded', {
                targetId: this.config.targetId,
                storeRoleArn: this.config.metadataStore.storeRoleArn,
            });
        }
        const client = new client_s3_1.S3Client({
            ...(this.config.region && { region: this.config.region }),
            ...(credentials && { credentials }),
        });
        const response = await client.send(new client_s3_1.GetObjectCommand({
            Bucket: this.config.artifactBucketName,
            Key: this.config.artifactObjectKey,
        }));
        if (!response.Body) {
            throw new Error(`Migration artifact s3://${this.config.artifactBucketName}/${this.config.artifactObjectKey} did not include a body.`);
        }
        await (0, promises_1.pipeline)(response.Body, (0, fs_1.createWriteStream)(destinationPath));
        this.logInfo('database-migration.artifact.download.succeeded', {
            targetId: this.config.targetId,
            destinationPath,
        });
    }
    async loadMigrations(migrationPath, context) {
        // The runner executes runtime-ready migration artifacts only. Teams can author in TypeScript,
        // but those migrations should be compiled to JavaScript before being packaged for execution.
        const migrationFiles = await fg(['**/*.{js,cjs,mjs}', '**/*.up.sql'], {
            cwd: migrationPath,
            absolute: true,
            onlyFiles: true,
            ignore: ['**/*.d.ts'],
        });
        return migrationFiles.sort().map((filePath) => {
            if (filePath.endsWith('.up.sql')) {
                const name = path.basename(filePath, '.up.sql');
                const downPath = filePath.replace(/\.up\.sql$/, '.down.sql');
                return {
                    name,
                    path: filePath,
                    up: async () => {
                        const sql = await fs_1.promises.readFile(filePath, 'utf8');
                        await this.runSql(context, sql);
                    },
                    down: async () => {
                        const sql = await fs_1.promises.readFile(downPath, 'utf8');
                        await this.runSql(context, sql);
                    },
                };
            }
            return {
                name: path.basename(filePath, path.extname(filePath)),
                path: filePath,
                up: async () => {
                    const migration = await Promise.resolve(`${(0, url_1.pathToFileURL)(filePath).href}`).then(s => require(s));
                    await migration.up({ context });
                },
                down: async () => {
                    const migration = await Promise.resolve(`${(0, url_1.pathToFileURL)(filePath).href}`).then(s => require(s));
                    if (typeof migration.down !== 'function') {
                        throw new Error(`Migration ${filePath} does not export down().`);
                    }
                    await migration.down({ context });
                },
            };
        });
    }
    async runSql(context, sql) {
        if (typeof context === 'object' && context && 'query' in context && typeof context.query === 'function') {
            await context.query(sql);
            return;
        }
        throw new Error(`SQL migrations require a SQL query-capable context.`);
    }
    toMigrationNames(executed) {
        if (Array.isArray(executed)) {
            return executed.map((migration) => migration.name);
        }
        if (executed && typeof executed === 'object' && 'name' in executed) {
            return [executed.name];
        }
        return [];
    }
    logInfo(event, details) {
        console.log(JSON.stringify({
            level: 'info',
            event,
            ...details,
        }));
    }
    logError(event, error, details) {
        console.error(JSON.stringify({
            level: 'error',
            event,
            ...details,
            message: error instanceof Error ? error.message : String(error),
        }));
    }
}
exports.DatabaseMigrationRunner = DatabaseMigrationRunner;
async function runDatabaseMigrationFromEnv(environment = process.env) {
    const runner = new DatabaseMigrationRunner({
        metadataStore: {
            tableName: readEnv(environment, 'DATABASE_MIGRATION_STORE_TABLE_NAME'),
            gsi1Name: readEnv(environment, 'DATABASE_MIGRATION_STORE_GSI1_NAME'),
            storeRoleArn: readEnv(environment, 'DATABASE_MIGRATION_STORE_ROLE_ARN'),
        },
        targetId: readEnv(environment, 'DATABASE_MIGRATION_TARGET_ID'),
        engine: readEnv(environment, 'DATABASE_MIGRATION_ENGINE'),
        direction: readEnv(environment, 'DATABASE_MIGRATION_DIRECTION'),
        databaseName: readEnv(environment, 'DATABASE_MIGRATION_DATABASE_NAME'),
        artifactBucketName: readEnv(environment, 'DATABASE_MIGRATION_STORE_BUCKET_NAME'),
        artifactObjectKey: readEnv(environment, 'DATABASE_MIGRATION_ARTIFACT_OBJECT_KEY'),
        lockTtlSeconds: readPositiveIntegerEnv(environment, 'DATABASE_MIGRATION_LOCK_TTL_SECONDS'),
        secretName: environment['DATABASE_MIGRATION_SECRET_NAME'],
        region: environment['AWS_REGION'],
    });
    await runner.run();
}
exports.runDatabaseMigrationFromEnv = runDatabaseMigrationFromEnv;
function readEnv(environment, name) {
    const value = environment[name];
    if (!value) {
        throw new Error(`${name} is required.`);
    }
    return value;
}
function readPositiveIntegerEnv(environment, name) {
    const value = Number.parseInt(readEnv(environment, name), 10);
    if (!Number.isInteger(value) || value <= 0) {
        throw new Error(`${name} must be a positive integer.`);
    }
    return value;
}
//# sourceMappingURL=database-migration-runner.js.map