import { DynamoDBClient } from '@aws-sdk/client-dynamodb';
import {
  DeleteCommand,
  DynamoDBDocumentClient,
  GetCommand,
  PutCommand,
  QueryCommand,
  UpdateCommand,
} from '@aws-sdk/lib-dynamodb';
import { assumeRoleCredentials } from './assume-role-credentials';

export interface DatabaseMigrationStoreProps {
  tableName: string;
  gsi1Name?: string;
  storeRoleArn?: string;
  region?: string;
}

export interface AcquireLockInput {
  targetId: string;
  ownerId: string;
  acquiredAt: string;
  expiresAt: string;
  now?: string;
}

export interface ReleaseLockInput {
  targetId: string;
  ownerId?: string;
}

export interface ApplyMigrationRecordInput {
  targetId: string;
  migrationName: string;
  startedAt: string;
}

export interface DatabaseMigrationRecord {
  migration_name: string;
  started_at: string;
}

export class DatabaseMigrationStore {
  private readonly storeRoleArn: string | undefined;
  private readonly tableName: string;
  private readonly gsi1Name: string;
  private readonly region: string | undefined;
  private client: DynamoDBDocumentClient | undefined;

  constructor(props: DatabaseMigrationStoreProps) {
    this.tableName = props.tableName;
    this.gsi1Name = props.gsi1Name ?? 'gsi1';
    this.storeRoleArn = props.storeRoleArn;
    this.region = props.region;
  }

  async acquireLock(input: AcquireLockInput): Promise<void> {
    const key = this.lockKey(input.targetId);
    const client = await this.getClient();

    await client.send(
      new UpdateCommand({
        TableName: this.tableName,
        Key: key,
        UpdateExpression:
          'SET #targetId = :targetId, #status = :active, #ownerId = :ownerId, #acquiredAt = :acquiredAt, #expiresAt = :expiresAt',
        ConditionExpression:
          'attribute_not_exists(#pk) OR #status = :released OR (#expiresAt <= :now AND #status = :active)',
        ExpressionAttributeNames: {
          '#pk': 'pk',
          '#targetId': 'target_id',
          '#status': 'status',
          '#ownerId': 'owner_id',
          '#acquiredAt': 'acquired_at',
          '#expiresAt': 'expires_at',
        },
        ExpressionAttributeValues: {
          ':targetId': input.targetId,
          ':active': 'active',
          ':released': 'released',
          ':ownerId': input.ownerId,
          ':acquiredAt': input.acquiredAt,
          ':expiresAt': input.expiresAt,
          ':now': input.now ?? input.acquiredAt,
        },
      })
    );
  }

  async releaseLock(input: ReleaseLockInput): Promise<void> {
    const ownerCheck = input.ownerId ? ' AND #ownerId = :ownerId' : '';
    const client = await this.getClient();

    await client.send(
      new UpdateCommand({
        TableName: this.tableName,
        Key: this.lockKey(input.targetId),
        UpdateExpression: 'SET #status = :released',
        ConditionExpression: `attribute_exists(#pk)${ownerCheck}`,
        ExpressionAttributeNames: {
          '#pk': 'pk',
          '#status': 'status',
          '#ownerId': 'owner_id',
        },
        ExpressionAttributeValues: {
          ':released': 'released',
          ...(input.ownerId && { ':ownerId': input.ownerId }),
        },
      })
    );
  }

  async listMigrations(targetId: string): Promise<DatabaseMigrationRecord[]> {
    const client = await this.getClient();
    const response = await client.send(
      new QueryCommand({
        TableName: this.tableName,
        IndexName: this.gsi1Name,
        KeyConditionExpression: '#gsi1pk = :gsi1pk AND begins_with(#gsi1sk, :executedAtPrefix)',
        ExpressionAttributeNames: {
          '#gsi1pk': 'gsi1pk',
          '#gsi1sk': 'gsi1sk',
        },
        ExpressionAttributeValues: {
          ':gsi1pk': this.targetPk(targetId),
          ':executedAtPrefix': 'EXECUTED_AT#',
        },
        ScanIndexForward: true,
      })
    );

    return (response.Items ?? []) as DatabaseMigrationRecord[];
  }

  async getMigration(targetId: string, migrationName: string): Promise<DatabaseMigrationRecord | undefined> {
    const client = await this.getClient();
    const response = await client.send(
      new GetCommand({
        TableName: this.tableName,
        Key: this.migrationKey(targetId, migrationName),
      })
    );

    return response.Item as DatabaseMigrationRecord | undefined;
  }

  async applyMigrationRecord(input: ApplyMigrationRecordInput): Promise<void> {
    const client = await this.getClient();
    await client.send(
      new PutCommand({
        TableName: this.tableName,
        Item: {
          ...this.migrationKey(input.targetId, input.migrationName),
          target_id: input.targetId,
          migration_name: input.migrationName,
          started_at: input.startedAt,
          gsi1pk: this.targetPk(input.targetId),
          gsi1sk: `EXECUTED_AT#${input.startedAt}`,
        },
      })
    );
  }

  async removeMigrationRecord(targetId: string, migrationName: string): Promise<void> {
    const client = await this.getClient();
    await client.send(
      new DeleteCommand({
        TableName: this.tableName,
        Key: this.migrationKey(targetId, migrationName),
      })
    );
  }

  private targetPk(targetId: string): string {
    return `TARGET_ID#${targetId}`;
  }

  private migrationKey(targetId: string, migrationName: string): { pk: string; sk: string } {
    return {
      pk: this.targetPk(targetId),
      sk: `MIGRATION_NAME#${migrationName}`,
    };
  }

  private lockKey(targetId: string): { pk: string; sk: string } {
    const key = `LOCK#${targetId}`;

    return {
      pk: key,
      sk: key,
    };
  }

  private async getClient(): Promise<DynamoDBDocumentClient> {
    if (this.client) {
      return this.client;
    }

    const credentials = this.storeRoleArn
      ? await assumeRoleCredentials({
          roleArn: this.storeRoleArn,
          roleSessionName: `database-migration-store-${Date.now()}`,
          region: this.region,
        })
      : undefined;

    this.client = DynamoDBDocumentClient.from(
      new DynamoDBClient({
        ...(this.region && { region: this.region }),
        ...(credentials && { credentials }),
      })
    );

    return this.client;
  }
}
