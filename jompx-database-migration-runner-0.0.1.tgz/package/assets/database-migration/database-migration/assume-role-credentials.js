"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.assumeRoleCredentials = void 0;
const client_sts_1 = require("@aws-sdk/client-sts");
async function assumeRoleCredentials(props) {
    const client = new client_sts_1.STSClient({
        ...(props.region && { region: props.region }),
    });
    const response = await client.send(new client_sts_1.AssumeRoleCommand({
        RoleArn: props.roleArn,
        RoleSessionName: props.roleSessionName,
    }));
    if (!response.Credentials?.AccessKeyId || !response.Credentials.SecretAccessKey) {
        throw new Error(`AssumeRole ${props.roleArn} did not return credentials.`);
    }
    return {
        accessKeyId: response.Credentials.AccessKeyId,
        secretAccessKey: response.Credentials.SecretAccessKey,
        sessionToken: response.Credentials.SessionToken,
        expiration: response.Credentials.Expiration,
    };
}
exports.assumeRoleCredentials = assumeRoleCredentials;
//# sourceMappingURL=assume-role-credentials.js.map