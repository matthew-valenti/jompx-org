import { AssumeRoleCommand, STSClient } from '@aws-sdk/client-sts';

export async function assumeRoleCredentials(props: {
  roleArn: string;
  roleSessionName: string;
  region?: string;
}) {
  const client = new STSClient({
    ...(props.region && { region: props.region }),
  });
  const response = await client.send(
    new AssumeRoleCommand({
      RoleArn: props.roleArn,
      RoleSessionName: props.roleSessionName,
    })
  );

  if (!response.Credentials?.AccessKeyId || !response.Credentials.SecretAccessKey) {
    throw new Error(`AssumeRole ${props.roleArn} did not return credentials.`);
  }

  return {
    accessKeyId: response.Credentials.AccessKeyId,
    secretAccessKey: response.Credentials.SecretAccessKey,
    sessionToken: response.Credentials.SessionToken,
    expiration: response.Credentials.Expiration,
  };
}
