import { GetObjectCommand, S3Client } from '@aws-sdk/client-s3';
import { GetSecretValueCommand, SecretsManagerClient } from '@aws-sdk/client-secrets-manager';
import { execFile } from 'child_process';
import fg = require('fast-glob');
import { createWriteStream, promises as fs } from 'fs';
import * as path from 'path';
import { pipeline } from 'stream/promises';
import { promisify } from 'util';
import { pathToFileURL } from 'url';
import { assumeRoleCredentials } from './assume-role-credentials';
import { Umzug } from 'umzug';
import {
  DatabaseMigrationContextFactory,
  DatabaseMigrationDirection,
  DatabaseMigrationEngine,
  DatabaseMigrationRunnerConfig,
} from './database-migration-context-factory';
import { DatabaseMigrationStore } from './database-migration-store';
import { DatabaseMigrationUmzugStorage } from './database-migration-umzug-storage';

interface ConnectionSecretValue {
  host: string;
  port: number;
  username: string;
  password: string;
  database: string;
}

export interface DatabaseMigrationRuntimeEnvironment {
  [key: string]: string | undefined;
  AWS_REGION?: string;
  CODEBUILD_BUILD_ID?: string;
  DATABASE_MIGRATION_ARTIFACT_OBJECT_KEY?: string;
  DATABASE_MIGRATION_DATABASE_NAME?: string;
  DATABASE_MIGRATION_DIRECTION?: DatabaseMigrationDirection;
  DATABASE_MIGRATION_ENGINE?: DatabaseMigrationEngine;
  DATABASE_MIGRATION_LOCK_TTL_SECONDS?: string;
  DATABASE_MIGRATION_SECRET_NAME?: string;
  DATABASE_MIGRATION_STORE_BUCKET_NAME?: string;
  DATABASE_MIGRATION_STORE_GSI1_NAME?: string;
  DATABASE_MIGRATION_STORE_ROLE_ARN?: string;
  DATABASE_MIGRATION_STORE_TABLE_NAME?: string;
  DATABASE_MIGRATION_TARGET_ID?: string;
}

const execFileAsync = promisify(execFile);

export class DatabaseMigrationRunner {
  constructor(private readonly config: DatabaseMigrationRunnerConfig) {}

  async run(): Promise<void> {
    const ownerId = `codebuild-${process.env['CODEBUILD_BUILD_ID'] ?? Date.now()}`;
    const startedAt = new Date().toISOString();
    const expiresAt = new Date(Date.now() + this.config.lockTtlSeconds * 1000).toISOString();
    let context: unknown;
    let migrationDirectory: string | undefined;
    const store = new DatabaseMigrationStore({
      tableName: this.config.metadataStore.tableName,
      gsi1Name: this.config.metadataStore.gsi1Name,
      storeRoleArn: this.config.metadataStore.storeRoleArn,
      region: this.config.region,
    });

    this.logInfo('database-migration.started', {
      targetId: this.config.targetId,
      engine: this.config.engine,
      direction: this.config.direction,
    });
    this.logInfo('database-migration.lock.acquire.started', {
      targetId: this.config.targetId,
      ownerId,
    });
    await store.acquireLock({
      targetId: this.config.targetId,
      ownerId,
      acquiredAt: startedAt,
      expiresAt,
    });
    this.logInfo('database-migration.lock.acquire.succeeded', {
      targetId: this.config.targetId,
      ownerId,
    });

    try {
      this.logInfo('database-migration.artifact.prepare.started', {
        targetId: this.config.targetId,
        artifactBucketName: this.config.artifactBucketName,
        artifactObjectKey: this.config.artifactObjectKey,
      });
      migrationDirectory = await this.prepareMigrationDirectory();
      this.logInfo('database-migration.artifact.prepare.succeeded', {
        targetId: this.config.targetId,
        migrationDirectory,
      });

      this.logInfo('database-migration.context.create.started', {
        targetId: this.config.targetId,
        engine: this.config.engine,
        secretName: this.config.secretName,
      });
      context = await this.createContext();
      this.logInfo('database-migration.context.create.succeeded', {
        targetId: this.config.targetId,
        engine: this.config.engine,
      });

      this.logInfo('database-migration.migrations.load.started', {
        targetId: this.config.targetId,
        migrationDirectory,
      });
      const migrations = await this.loadMigrations(migrationDirectory, context);
      this.logInfo('database-migration.migrations.load.succeeded', {
        targetId: this.config.targetId,
        migrationCount: migrations.length,
        migrations: migrations.map((migration) => migration.name),
      });

      const umzug = new Umzug({
        migrations,
        context: context as object,
        storage: new DatabaseMigrationUmzugStorage(this.config.targetId, store),
        logger: console,
      });

      this.logInfo('database-migration.execute.started', {
        targetId: this.config.targetId,
        direction: this.config.direction,
      });
      const executed = this.config.direction === 'down' ? await umzug.down() : await umzug.up();
      this.logInfo('database-migration.succeeded', {
        targetId: this.config.targetId,
        engine: this.config.engine,
        direction: this.config.direction,
        migrations: this.toMigrationNames(executed),
      });
    } catch (error) {
      this.logError('database-migration.failed', error, {
        targetId: this.config.targetId,
        engine: this.config.engine,
        direction: this.config.direction,
      });
      throw error;
    } finally {
      if (context) {
        try {
          this.logInfo('database-migration.context.close.started', {
            targetId: this.config.targetId,
          });
          await this.closeContext(context);
          this.logInfo('database-migration.context.close.succeeded', {
            targetId: this.config.targetId,
          });
        } catch (error) {
          this.logError('database-migration.close-context.failed', error, {
            targetId: this.config.targetId,
            engine: this.config.engine,
            direction: this.config.direction,
          });
        }
      }

      if (migrationDirectory) {
        this.logInfo('database-migration.artifact.cleanup.started', {
          targetId: this.config.targetId,
          migrationDirectory,
        });
        await fs.rm(migrationDirectory, { recursive: true, force: true });
        this.logInfo('database-migration.artifact.cleanup.succeeded', {
          targetId: this.config.targetId,
          migrationDirectory,
        });
      }

      this.logInfo('database-migration.lock.release.started', {
        targetId: this.config.targetId,
        ownerId,
      });
      await store.releaseLock({
        targetId: this.config.targetId,
        ownerId,
      });
      this.logInfo('database-migration.lock.release.succeeded', {
        targetId: this.config.targetId,
        ownerId,
      });
    }
  }

  private async createContext(): Promise<unknown> {
    return new DatabaseMigrationContextFactory(this.config, async (secretName) => this.readConnectionSecret(secretName)).create();
  }

  private async closeContext(context: unknown): Promise<void> {
    if (typeof context === 'object' && context && 'close' in context && typeof (context as any).close === 'function') {
      await (context as any).close();
    }
  }

  private async readConnectionSecret(secretName: string): Promise<ConnectionSecretValue> {
    this.logInfo('database-migration.secret.read.started', {
      targetId: this.config.targetId,
      secretName,
    });
    const client = new SecretsManagerClient({
      ...(this.config.region && { region: this.config.region }),
    });
    const response = await client.send(
      new GetSecretValueCommand({
        SecretId: secretName,
      })
    );

    if (!response.SecretString) {
      throw new Error(`Secret ${secretName} did not include SecretString.`);
    }

    this.logInfo('database-migration.secret.read.succeeded', {
      targetId: this.config.targetId,
      secretName,
    });
    return {
      ...(JSON.parse(response.SecretString) as ConnectionSecretValue),
      database: this.config.databaseName,
    };
  }

  private async prepareMigrationDirectory(): Promise<string> {
    const extractionDirectory = path.join('/tmp', 'database-migration', this.config.targetId, `${Date.now()}`);
    const archivePath = path.join(extractionDirectory, 'bundle.zip');

    this.logInfo('database-migration.artifact.directory.create.started', {
      targetId: this.config.targetId,
      extractionDirectory,
    });
    await fs.mkdir(extractionDirectory, { recursive: true });
    this.logInfo('database-migration.artifact.directory.create.succeeded', {
      targetId: this.config.targetId,
      extractionDirectory,
    });
    await this.downloadArtifact(archivePath);
    this.logInfo('database-migration.artifact.unzip.started', {
      targetId: this.config.targetId,
      archivePath,
      extractionDirectory,
    });
    await execFileAsync('unzip', ['-q', archivePath, '-d', extractionDirectory]);
    this.logInfo('database-migration.artifact.unzip.succeeded', {
      targetId: this.config.targetId,
      extractionDirectory,
    });
    await fs.rm(archivePath, { force: true });

    return extractionDirectory;
  }

  private async downloadArtifact(destinationPath: string): Promise<void> {
    this.logInfo('database-migration.artifact.download.started', {
      targetId: this.config.targetId,
      artifactBucketName: this.config.artifactBucketName,
      artifactObjectKey: this.config.artifactObjectKey,
      assumeStoreRole: Boolean(this.config.metadataStore.storeRoleArn),
    });
    const credentials = this.config.metadataStore.storeRoleArn
      ? await assumeRoleCredentials({
          roleArn: this.config.metadataStore.storeRoleArn,
          roleSessionName: `database-migration-artifact-${Date.now()}`,
          region: this.config.region,
        })
      : undefined;
    if (credentials) {
      this.logInfo('database-migration.artifact.download.assume-store-role.succeeded', {
        targetId: this.config.targetId,
        storeRoleArn: this.config.metadataStore.storeRoleArn,
      });
    }
    const client = new S3Client({
      ...(this.config.region && { region: this.config.region }),
      ...(credentials && { credentials }),
    });
    const response = await client.send(
      new GetObjectCommand({
        Bucket: this.config.artifactBucketName,
        Key: this.config.artifactObjectKey,
      })
    );

    if (!response.Body) {
      throw new Error(
        `Migration artifact s3://${this.config.artifactBucketName}/${this.config.artifactObjectKey} did not include a body.`
      );
    }

    await pipeline(response.Body as NodeJS.ReadableStream, createWriteStream(destinationPath));
    this.logInfo('database-migration.artifact.download.succeeded', {
      targetId: this.config.targetId,
      destinationPath,
    });
  }

  private async loadMigrations(migrationPath: string, context: unknown) {
    // The runner executes runtime-ready migration artifacts only. Teams can author in TypeScript,
    // but those migrations should be compiled to JavaScript before being packaged for execution.
    const migrationFiles = await fg(['**/*.{js,cjs,mjs}', '**/*.up.sql'], {
      cwd: migrationPath,
      absolute: true,
      onlyFiles: true,
      ignore: ['**/*.d.ts'],
    });

    return migrationFiles.sort().map((filePath: string) => {
      if (filePath.endsWith('.up.sql')) {
        const name = path.basename(filePath, '.up.sql');
        const downPath = filePath.replace(/\.up\.sql$/, '.down.sql');

        return {
          name,
          path: filePath,
          up: async () => {
            const sql = await fs.readFile(filePath, 'utf8');
            await this.runSql(context, sql);
          },
          down: async () => {
            const sql = await fs.readFile(downPath, 'utf8');
            await this.runSql(context, sql);
          },
        };
      }

      return {
        name: path.basename(filePath, path.extname(filePath)),
        path: filePath,
        up: async () => {
          const migration = await import(pathToFileURL(filePath).href);
          await migration.up({ context });
        },
        down: async () => {
          const migration = await import(pathToFileURL(filePath).href);
          if (typeof migration.down !== 'function') {
            throw new Error(`Migration ${filePath} does not export down().`);
          }
          await migration.down({ context });
        },
      };
    });
  }

  private async runSql(context: unknown, sql: string): Promise<void> {
    if (typeof context === 'object' && context && 'query' in context && typeof (context as any).query === 'function') {
      await (context as any).query(sql);
      return;
    }

    throw new Error(`SQL migrations require a SQL query-capable context.`);
  }

  private toMigrationNames(executed: unknown): string[] {
    if (Array.isArray(executed)) {
      return executed.map((migration: any) => migration.name);
    }

    if (executed && typeof executed === 'object' && 'name' in executed) {
      return [(executed as any).name];
    }

    return [];
  }

  private logInfo(event: string, details: Record<string, unknown>): void {
    console.log(
      JSON.stringify({
        level: 'info',
        event,
        ...details,
      })
    );
  }

  private logError(event: string, error: unknown, details: Record<string, unknown>): void {
    console.error(
      JSON.stringify({
        level: 'error',
        event,
        ...details,
        message: error instanceof Error ? error.message : String(error),
      })
    );
  }
}

export async function runDatabaseMigrationFromEnv(
  environment: DatabaseMigrationRuntimeEnvironment = process.env
): Promise<void> {
  const runner = new DatabaseMigrationRunner({
    metadataStore: {
      tableName: readEnv(environment, 'DATABASE_MIGRATION_STORE_TABLE_NAME'),
      gsi1Name: readEnv(environment, 'DATABASE_MIGRATION_STORE_GSI1_NAME'),
      storeRoleArn: readEnv(environment, 'DATABASE_MIGRATION_STORE_ROLE_ARN'),
    },
    targetId: readEnv(environment, 'DATABASE_MIGRATION_TARGET_ID'),
    engine: readEnv(environment, 'DATABASE_MIGRATION_ENGINE') as DatabaseMigrationEngine,
    direction: readEnv(environment, 'DATABASE_MIGRATION_DIRECTION') as DatabaseMigrationDirection,
    databaseName: readEnv(environment, 'DATABASE_MIGRATION_DATABASE_NAME'),
    artifactBucketName: readEnv(environment, 'DATABASE_MIGRATION_STORE_BUCKET_NAME'),
    artifactObjectKey: readEnv(environment, 'DATABASE_MIGRATION_ARTIFACT_OBJECT_KEY'),
    lockTtlSeconds: readPositiveIntegerEnv(environment, 'DATABASE_MIGRATION_LOCK_TTL_SECONDS'),
    secretName: environment['DATABASE_MIGRATION_SECRET_NAME'],
    region: environment['AWS_REGION'],
  });

  await runner.run();
}

function readEnv(environment: DatabaseMigrationRuntimeEnvironment, name: string): string {
  const value = environment[name];
  if (!value) {
    throw new Error(`${name} is required.`);
  }

  return value;
}

function readPositiveIntegerEnv(environment: DatabaseMigrationRuntimeEnvironment, name: string): number {
  const value = Number.parseInt(readEnv(environment, name), 10);
  if (!Number.isInteger(value) || value <= 0) {
    throw new Error(`${name} must be a positive integer.`);
  }

  return value;
}
