import { DynamoDbDatabaseClient } from '../database-client/dynamodb-database-client';
import { MysqlDatabaseClient } from '../database-client/mysql-database-client';
import { MysqlConnectionSecretValue } from '../database-client/mysql-database-client.types';
import { PostgresDatabaseClient } from '../database-client/postgres-database-client';
import { PostgresConnectionSecretValue } from '../database-client/postgres-database-client.types';

export type DatabaseMigrationEngine = 'dynamodb' | 'mysql_5.7.x' | 'mysql_8.0.x' | 'postgres_17.x' | 'sqlite_3.x';
export type DatabaseMigrationDirection = 'up' | 'down';

export interface DatabaseMigrationMetadataStoreConfig {
  tableName: string;
  gsi1Name: string;
  storeRoleArn?: string;
}

export interface DatabaseMigrationRunnerConfig {
  metadataStore: DatabaseMigrationMetadataStoreConfig;
  targetId: string;
  engine: DatabaseMigrationEngine;
  direction: DatabaseMigrationDirection;
  databaseName: string;
  artifactBucketName: string;
  artifactObjectKey: string;
  lockTtlSeconds: number;
  secretName?: string;
  region?: string;
}

export interface SqlMigrationContext {
  query: (sql: string, values?: unknown[]) => Promise<void>;
  close: () => Promise<void>;
}

export type DatabaseMigrationContext = object;

export class DatabaseMigrationContextFactory {
  constructor(
    private readonly config: DatabaseMigrationRunnerConfig,
    private readonly readConnectionSecret: (
      secretName: string
    ) => Promise<MysqlConnectionSecretValue | PostgresConnectionSecretValue>
  ) {}

  public async create(): Promise<DatabaseMigrationContext> {
    if (this.config.engine === 'dynamodb') {
      return new DynamoDbDatabaseClient({
        config: {
          ...(this.config.region && { region: this.config.region }),
        },
      }).getClient();
    }

    if (!this.config.secretName) {
      throw new Error(`DATABASE_MIGRATION_SECRET_NAME is required for engine ${this.config.engine}.`);
    }

    const secret = await this.readConnectionSecret(this.config.secretName);

    if (this.config.engine.startsWith('mysql')) {
      const client = new MysqlDatabaseClient({
        secret,
      });
      const connection = await client.getConnection();

      return {
        query: async (sql: string, values?: unknown[]) => {
          await connection.query(sql, values as any);
        },
        close: async () => {
          await client.close();
        },
      } satisfies SqlMigrationContext;
    }

    if (this.config.engine === 'postgres_17.x') {
      const client = new PostgresDatabaseClient({
        secret,
      });

      return {
        query: async (sql: string, values?: unknown[]) => {
          await client.query(sql, values as any[]);
        },
        close: async () => {
          await client.close();
        },
      } satisfies SqlMigrationContext;
    }

    throw new Error(`Engine ${this.config.engine} is not yet supported by the migration runner.`);
  }
}
