import type { MigrationParams, UmzugStorage } from 'umzug';
import { DatabaseMigrationStore } from './database-migration-store';

export class DatabaseMigrationUmzugStorage<Ctx = unknown> implements UmzugStorage<Ctx> {
  constructor(
    private readonly targetId: string,
    private readonly store: DatabaseMigrationStore
  ) {}

  async logMigration(params: MigrationParams<Ctx>): Promise<void> {
    await this.store.applyMigrationRecord({
      targetId: this.targetId,
      migrationName: params.name,
      startedAt: new Date().toISOString(),
    });
  }

  async unlogMigration(params: MigrationParams<Ctx>): Promise<void> {
    await this.store.removeMigrationRecord(this.targetId, params.name);
  }

  async executed(_meta: Pick<MigrationParams<Ctx>, 'context'>): Promise<string[]> {
    const migrations = await this.store.listMigrations(this.targetId);
    return migrations.map((migration) => migration.migration_name).sort();
  }
}
