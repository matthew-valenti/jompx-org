export declare function assumeRoleCredentials(props: {
    roleArn: string;
    roleSessionName: string;
    region?: string;
}): Promise<{
    accessKeyId: string;
    secretAccessKey: string;
    sessionToken: string | undefined;
    expiration: Date | undefined;
}>;
