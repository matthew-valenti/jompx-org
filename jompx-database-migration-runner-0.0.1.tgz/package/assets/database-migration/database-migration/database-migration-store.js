"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DatabaseMigrationStore = void 0;
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
const assume_role_credentials_1 = require("./assume-role-credentials");
class DatabaseMigrationStore {
    constructor(props) {
        this.tableName = props.tableName;
        this.gsi1Name = props.gsi1Name ?? 'gsi1';
        this.storeRoleArn = props.storeRoleArn;
        this.region = props.region;
    }
    async acquireLock(input) {
        const key = this.lockKey(input.targetId);
        const client = await this.getClient();
        await client.send(new lib_dynamodb_1.UpdateCommand({
            TableName: this.tableName,
            Key: key,
            UpdateExpression: 'SET #targetId = :targetId, #status = :active, #ownerId = :ownerId, #acquiredAt = :acquiredAt, #expiresAt = :expiresAt',
            ConditionExpression: 'attribute_not_exists(#pk) OR #status = :released OR (#expiresAt <= :now AND #status = :active)',
            ExpressionAttributeNames: {
                '#pk': 'pk',
                '#targetId': 'target_id',
                '#status': 'status',
                '#ownerId': 'owner_id',
                '#acquiredAt': 'acquired_at',
                '#expiresAt': 'expires_at',
            },
            ExpressionAttributeValues: {
                ':targetId': input.targetId,
                ':active': 'active',
                ':released': 'released',
                ':ownerId': input.ownerId,
                ':acquiredAt': input.acquiredAt,
                ':expiresAt': input.expiresAt,
                ':now': input.now ?? input.acquiredAt,
            },
        }));
    }
    async releaseLock(input) {
        const ownerCheck = input.ownerId ? ' AND #ownerId = :ownerId' : '';
        const client = await this.getClient();
        await client.send(new lib_dynamodb_1.UpdateCommand({
            TableName: this.tableName,
            Key: this.lockKey(input.targetId),
            UpdateExpression: 'SET #status = :released',
            ConditionExpression: `attribute_exists(#pk)${ownerCheck}`,
            ExpressionAttributeNames: {
                '#pk': 'pk',
                '#status': 'status',
                '#ownerId': 'owner_id',
            },
            ExpressionAttributeValues: {
                ':released': 'released',
                ...(input.ownerId && { ':ownerId': input.ownerId }),
            },
        }));
    }
    async listMigrations(targetId) {
        const client = await this.getClient();
        const response = await client.send(new lib_dynamodb_1.QueryCommand({
            TableName: this.tableName,
            IndexName: this.gsi1Name,
            KeyConditionExpression: '#gsi1pk = :gsi1pk AND begins_with(#gsi1sk, :executedAtPrefix)',
            ExpressionAttributeNames: {
                '#gsi1pk': 'gsi1pk',
                '#gsi1sk': 'gsi1sk',
            },
            ExpressionAttributeValues: {
                ':gsi1pk': this.targetPk(targetId),
                ':executedAtPrefix': 'EXECUTED_AT#',
            },
            ScanIndexForward: true,
        }));
        return (response.Items ?? []);
    }
    async getMigration(targetId, migrationName) {
        const client = await this.getClient();
        const response = await client.send(new lib_dynamodb_1.GetCommand({
            TableName: this.tableName,
            Key: this.migrationKey(targetId, migrationName),
        }));
        return response.Item;
    }
    async applyMigrationRecord(input) {
        const client = await this.getClient();
        await client.send(new lib_dynamodb_1.PutCommand({
            TableName: this.tableName,
            Item: {
                ...this.migrationKey(input.targetId, input.migrationName),
                target_id: input.targetId,
                migration_name: input.migrationName,
                started_at: input.startedAt,
                gsi1pk: this.targetPk(input.targetId),
                gsi1sk: `EXECUTED_AT#${input.startedAt}`,
            },
        }));
    }
    async removeMigrationRecord(targetId, migrationName) {
        const client = await this.getClient();
        await client.send(new lib_dynamodb_1.DeleteCommand({
            TableName: this.tableName,
            Key: this.migrationKey(targetId, migrationName),
        }));
    }
    targetPk(targetId) {
        return `TARGET_ID#${targetId}`;
    }
    migrationKey(targetId, migrationName) {
        return {
            pk: this.targetPk(targetId),
            sk: `MIGRATION_NAME#${migrationName}`,
        };
    }
    lockKey(targetId) {
        const key = `LOCK#${targetId}`;
        return {
            pk: key,
            sk: key,
        };
    }
    async getClient() {
        if (this.client) {
            return this.client;
        }
        const credentials = this.storeRoleArn
            ? await (0, assume_role_credentials_1.assumeRoleCredentials)({
                roleArn: this.storeRoleArn,
                roleSessionName: `database-migration-store-${Date.now()}`,
                region: this.region,
            })
            : undefined;
        this.client = lib_dynamodb_1.DynamoDBDocumentClient.from(new client_dynamodb_1.DynamoDBClient({
            ...(this.region && { region: this.region }),
            ...(credentials && { credentials }),
        }));
        return this.client;
    }
}
exports.DatabaseMigrationStore = DatabaseMigrationStore;
//# sourceMappingURL=database-migration-store.js.map