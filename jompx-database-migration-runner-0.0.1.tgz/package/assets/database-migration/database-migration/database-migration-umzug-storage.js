"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DatabaseMigrationUmzugStorage = void 0;
class DatabaseMigrationUmzugStorage {
    constructor(targetId, store) {
        this.targetId = targetId;
        this.store = store;
    }
    async logMigration(params) {
        await this.store.applyMigrationRecord({
            targetId: this.targetId,
            migrationName: params.name,
            startedAt: new Date().toISOString(),
        });
    }
    async unlogMigration(params) {
        await this.store.removeMigrationRecord(this.targetId, params.name);
    }
    async executed(_meta) {
        const migrations = await this.store.listMigrations(this.targetId);
        return migrations.map((migration) => migration.migration_name).sort();
    }
}
exports.DatabaseMigrationUmzugStorage = DatabaseMigrationUmzugStorage;
//# sourceMappingURL=database-migration-umzug-storage.js.map