"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const database_migration_runner_1 = require("./database-migration/database-migration-runner");
(0, database_migration_runner_1.runDatabaseMigrationFromEnv)().catch((error) => {
    console.error(error);
    process.exitCode = 1;
});
//# sourceMappingURL=main.js.map