import { type CredentialsProvider } from '@jompx/contracts-client';
export interface DatabaseMigrationSubmissionProps {
    baseUrl: string;
    region: string;
}
export interface RunDatabaseMigrationOrchestratorContractProps {
    name: string;
    accountId: string;
    region: string;
    schemaVersion?: string;
}
export interface RunDatabaseMigrationExecutorContractProps {
    name: string;
    accountId: string;
    region: string;
    schemaVersion?: string;
}
export interface RunDatabaseMigrationProps {
    credentialsProvider?: CredentialsProvider;
    submission: DatabaseMigrationSubmissionProps;
    orchestratorContract: RunDatabaseMigrationOrchestratorContractProps;
    executorContract: RunDatabaseMigrationExecutorContractProps;
    databaseName: string;
    migrationFilesPath: string;
    direction: 'up' | 'down';
}
export interface RunDatabaseMigrationResult {
    artifactBucketName: string;
    artifactObjectKey: string;
    stateMachineArn: string;
    executionArn: string;
    startDate: string;
}
export declare function runDatabaseMigration(props: RunDatabaseMigrationProps): Promise<RunDatabaseMigrationResult>;
