# @jompx/database-migration-runner

Thin client helper for Jompx database migrations.

## Thin Usage

```ts
import { runDatabaseMigration } from '@jompx/database-migration-runner';

await runDatabaseMigration({
  credentialsProvider: fromIni({ profile: 'sandbox1' }),
  submission: {
    baseUrl: 'https://submission-url.lambda-url.us-west-2.on.aws',
    region: 'us-west-2',
  },
  executorContract: {
    name: 'MyDatabaseMigrationExecutorStack',
    accountId: '123456789012',
    region: 'us-west-2',
    schemaVersion: '1',
  },
  orchestratorContract: {
    name: 'MyDatabaseMigrationOrchestratorStack',
    accountId: '123456789012',
    region: 'us-west-2',
    schemaVersion: '1',
  },
  migrationFilesPath: 'libs/database-migration/src/lib/app',
  direction: 'up',
});
```

## What It Does

- creates the migration zip locally
- uploads parts directly to S3
- completes the multipart upload
- starts the orchestrator run

## Notes

- use the Store stack `SubmissionBaseUrl` output for `submission.baseUrl`
- both `up` and `down` upload the full migration set
- the package returns artifact and execution details
