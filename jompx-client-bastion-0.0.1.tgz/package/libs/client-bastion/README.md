# client-bastion

## Purpose

Runtime client for starting, stopping, patching, and connecting to an SSM-only bastion.

## Usage

Registry-backed lookup:

```ts
import { ClientBastion } from '@jompx/client-bastion';

const bastion = new ClientBastion({
  profile: 'dev-admin',
  registry: {
    baseUrl: config.common.serviceContractRegistries[0].baseUrl,
    region: config.common.serviceContractRegistries[0].region,
  },
});
```

Direct target:

```ts
const bastion = new ClientBastion({
  profile: 'dev-admin',
});

const target = await bastion.resolve({
  instanceId: 'i-1234567890abcdef0',
  region: 'us-east-1',
});
```

Start:

```ts
await bastion.start('prod');
```

Stop:

```ts
await bastion.stop('prod');
```

Patch:

```ts
await bastion.patch('prod');
```

Shell:

```ts
await bastion.connect('prod', {
  mode: 'shell',
});
```

Port forward:

```ts
await bastion.connect('prod', {
  mode: 'port-forward',
  host: 'db.internal',
  remotePort: 5432,
  localPort: 15432,
});
```

`remotePort` and `localPort` are both explicit. `localPort` does not default to `remotePort`.

Direct connect:

```ts
await bastion.connect(
  {
    instanceId: 'i-1234567890abcdef0',
    region: 'us-east-1',
  },
  {
    mode: 'shell',
  }
);
```

## Configuration

- `profile` is required and is used for registry lookup, AWS SDK calls, and AWS CLI SSM sessions.
- `registry` uses `baseUrl` and `region` only.
- `connect()` requires an explicit mode.
- `port-forward` requires explicit `host`, `remotePort`, and `localPort`.
- `connect()` prints bastion key, mode, state, SSM readiness, and `last patch by SSM` from SSM command history before opening the session.
- Interactive sessions use the local AWS CLI.
- Start, stop, patch, and polling use the AWS SDK.
