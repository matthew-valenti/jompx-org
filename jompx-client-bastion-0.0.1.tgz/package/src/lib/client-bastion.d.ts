/// <reference types="node" />
import { ChildProcess, SpawnOptions } from 'child_process';
import { EC2Client } from '@aws-sdk/client-ec2';
import { defaultProvider } from '@aws-sdk/credential-provider-node';
import { SSMClient } from '@aws-sdk/client-ssm';
import { ServiceContractRegistryClient, ServiceContract } from '@jompx/client-service-contract-registry';
export type BastionConnectMode = 'shell' | 'port-forward';
export interface BastionContractValue extends Record<string, unknown> {
    bastionKey: string;
    instanceId: string;
    region: string;
}
export interface ClientBastionProps {
    profile: string;
    registry?: ClientBastionRegistryProps;
    awsCliCommand?: string;
    pollIntervalMs?: number;
    instanceReadyTimeoutMs?: number;
    ssmReadyTimeoutMs?: number;
    patchTimeoutMs?: number;
}
export interface ClientBastionRegistryProps {
    baseUrl: string;
    region: string;
}
export interface BastionTarget {
    instanceId: string;
    region: string;
}
export type BastionReference = string | BastionTarget;
export interface BastionShellConnectOptions {
    mode: 'shell';
}
export interface BastionPortForwardConnectOptions {
    mode: 'port-forward';
    host: string;
    remotePort: number;
    localPort: number;
}
export type BastionConnectOptions = BastionShellConnectOptions | BastionPortForwardConnectOptions;
export interface ResolvedBastion {
    bastionKey?: string;
    instanceId: string;
    region: string;
    contract?: ServiceContract<BastionContractValue>;
}
interface ClientBastionDependencies {
    serviceContractRegistryClientFactory?: (props: ServiceContractRegistryClientFactoryProps) => ServiceContractRegistryClientLike;
    ec2ClientFactory?: (props: AwsClientFactoryProps) => Ec2ClientLike;
    ssmClientFactory?: (props: AwsClientFactoryProps) => SsmClientLike;
    sleep?: (ms: number) => Promise<void>;
    spawnProcess?: SpawnProcess;
    writeLine?: (line: string) => void;
}
type ServiceContractRegistryClientLike = Pick<ServiceContractRegistryClient, 'listAll'>;
type Ec2ClientLike = Pick<EC2Client, 'send'>;
type SsmClientLike = Pick<SSMClient, 'send'>;
type CredentialProvider = ReturnType<typeof defaultProvider>;
type ServiceContractRegistryClientFactoryProps = ClientBastionRegistryProps & {
    credentialsProvider?: CredentialProvider;
};
type AwsClientFactoryProps = {
    region: string;
    credentials?: CredentialProvider;
};
type SpawnProcess = (command: string, args: string[], options: SpawnOptions) => ChildProcess;
export declare class ClientBastion {
    private readonly serviceContractRegistryClient?;
    private readonly profile;
    private readonly credentialsProvider;
    private readonly awsCliCommand;
    private readonly pollIntervalMs;
    private readonly instanceReadyTimeoutMs;
    private readonly ssmReadyTimeoutMs;
    private readonly patchTimeoutMs;
    private readonly ec2ClientFactory;
    private readonly ssmClientFactory;
    private readonly sleep;
    private readonly spawnProcess;
    private readonly writeLine;
    constructor(props: ClientBastionProps, dependencies?: ClientBastionDependencies);
    resolve(target: BastionReference): Promise<ResolvedBastion>;
    start(target: BastionReference): Promise<ResolvedBastion>;
    stop(target: BastionReference): Promise<ResolvedBastion>;
    patch(target: BastionReference): Promise<ResolvedBastion>;
    connect(target: BastionReference, options: BastionConnectOptions): Promise<ResolvedBastion>;
    private ensureRunning;
    private ensureStopped;
    private getInstanceState;
    private waitForInstanceState;
    private waitForSsmOnline;
    private runPatchCommand;
    private writeConnectBanner;
    private tryGetLastPatchedAt;
    private getLastPatchedAt;
    private poll;
    private buildConnectArgs;
    private runAwsCli;
}
export {};
