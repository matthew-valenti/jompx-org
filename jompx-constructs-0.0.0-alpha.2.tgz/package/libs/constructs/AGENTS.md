# Constructs Agent Guide

This package is an open-source AWS CDK construct library published as an npm module. Code here is framework-facing: keep APIs stable, explicit, documented, and secure by default.

## Construct Basics

- Use AWS CDK constructs and follow existing repo patterns before introducing new abstractions.
- Name construct files as `feature-name.construct.ts`.
- Name runtime/helper files by responsibility, for example `contract-registry-store.ts`.
- Export public constructs and public prop/types from `libs/constructs/src/index.ts`.
- Prefer one cohesive construct per file unless the service is clearly large enough to split.
- Keep props focused on developer intent, not low-level implementation escape hatches.
- Use CDK-generated physical names unless a stable name is part of the contract.
- Tag new AWS resources with `Vendor = jompx`.

## Naming

- Construct classes use PascalCase: `ServiceContractRegistry`.
- Props interfaces use the construct name plus `Props`: `ServiceContractRegistryProps`.
- Resource IDs are concise and stable: `Table`, `Handler`, `RestApi`, `Dashboard`.
- Keep example IDs aligned with the construct name: `new ServiceContractRegistry(this, 'ServiceContractRegistry')`.
- Public API fields use camelCase.
- Single-table DynamoDB key values may use uppercase labels for readability, for example `ACCOUNT_ID#...`.
- Prefer precise terms over vague ones: `schemaVersion` beats `version` when the version is for schema shape.
- Custom IAM roles that you're naming explicitly use kebab-case.

## Documentation

Each framework-facing construct should have nearby documentation when behavior is non-trivial.

Required README sections:

- `Status`
- `Usage`
- `Why It Exists`
- `Mental Model`
- `Security Model`

Docs should explain sequencing and mental model, not duplicate every prop.

## Security

- Assume all source code is public.
- Security must come from IAM, resource policies, validation, and correct deployment configuration.
- Never rely on obscurity or generated names as a control.
- Do not store secrets in construct-generated service contracts, docs examples, or outputs.
- Prefer IAM/SigV4 for AWS service-to-service APIs.
- Cross-account write paths should use explicit role ARNs.
- Broad permissions require a clear reason and should be tightened before framework-ready status.

## Runtime Code

- Do not inline non-trivial Lambda code in constructs.
- Put Lambda/runtime code in a `runtime/` folder near the construct.
- Keep runtime split into adapter, API/router, store/client, and types when useful.
- Validate input at runtime even if construct props validate at synth time.
- Map validation errors to `400`; unexpected service failures should be `500`.

## Testing

- Add focused tests for new constructs and runtime helpers.
- CDK constructs should have synth/assertion tests for important resources, IAM, and routes.
- Runtime helpers should test command/key shapes and validation behavior.
- Run targeted tests first, then TypeScript:

```bash
npx.cmd jest libs/constructs/src/lib/<feature> --config libs/constructs/jest.config.ts --runInBand
npx.cmd tsc -p libs/constructs/tsconfig.lib.json --noEmit
```

Full package tests may fail from unrelated legacy areas; report that clearly instead of hiding it.
