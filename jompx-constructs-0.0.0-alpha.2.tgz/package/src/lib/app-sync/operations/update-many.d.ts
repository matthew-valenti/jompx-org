export declare class UpdateManyOperation {
    schema(objectTypeName: string, datasourceId: string): string;
    static addArgsSdl(): string[];
}
