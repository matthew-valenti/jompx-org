export declare class FindOperation {
    schema(objectTypeName: string, datasourceId: string, paginationType: string): string;
    static addArgsSdl(paginationType: string): string[];
}
