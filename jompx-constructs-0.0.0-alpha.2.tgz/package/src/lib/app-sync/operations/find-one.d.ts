export declare class FindOneOperation {
    schema(objectTypeName: string, datasourceId: string): string;
    static addArgsSdl(): string[];
}
