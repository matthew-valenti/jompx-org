export declare class DeleteManyOperation {
    schema(objectTypeName: string, datasourceId: string): string;
    static addArgsSdl(): string[];
}
