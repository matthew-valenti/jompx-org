export declare class UpdateOneOperation {
    schema(objectTypeName: string, datasourceId: string): string;
    static addArgsSdl(): string[];
}
