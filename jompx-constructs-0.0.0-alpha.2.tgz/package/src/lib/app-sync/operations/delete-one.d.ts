export declare class DeleteOneOperation {
    schema(objectTypeName: string, datasourceId: string): string;
    static addArgsSdl(): string[];
}
