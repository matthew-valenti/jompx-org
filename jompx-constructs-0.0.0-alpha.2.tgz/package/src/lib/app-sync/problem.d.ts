/**
 * Use RFC 7807 "Problem Details for HTTP APIs" i.e. how should an API communicate errors to the client.
 * https://www.rfc-editor.org/rfc/rfc7807#section-3
 * https://ietf-wg-httpapi.github.io/rfc7807bis/draft-ietf-httpapi-rfc7807bis.html
 * https://artsy.github.io/blog/2018/10/19/where-art-thou-my-error/
 *
 * See Twitter implementation as an example: https://developer.twitter.com/en/support/twitter-api/error-troubleshooting
 *
 * There are two basic GraphQL error approaches:
 * 1. Top level errors property.
 * 2. Typed errors field in GraphQL schema.
 *
 * Option1: Use this approach!
 * This is a common and simple approach.
 * If there is an error, simply return it together with any data. This supports GraphQL partial returned data paradigm.
 * Apollo has good support for this type of error including custom properties.
 * AppSync has limited support but at least allows some customization via VTL.
 *
 * Return error detail using VTL: https://docs.aws.amazon.com/appsync/latest/devguide/tutorial-lambda-resolvers.html
 * Return error detail from Lambda using VTL: https://github.com/aws-amplify/amplify-cli/issues/5485
 *
 * Use standard http status codes where possible:
 * 4xx: Client issue. Client has to fix the problem on their side before trying again.
 * 5xx: Server issue. The request can be resent as is at a later time, when the server overcomes its current problems.
 *
 * Option2:
 * This approach sounds good in theory. However, an implementation starts to get overly complicated.
 * How should we namespace data vs errors. Should an error property be nested in each connection return type. Is additional nesting of data overly complicated.
 * If we namespace then our connection return type is non-standard. If we don't then connection return types will be inconsistent with mutation return types.
 *
 * GraphQL error implementations = "Stage 6a" https://productionreadygraphql.com/2020-08-01-guide-to-graphql-errors
 * GraphQL error best practices: https://graphql-rules.com/rules/mutation-payload-errors
 */
export interface ProblemProperty {
    problem?: Problem;
}
export interface ProblemDetail {
    type?: string;
    status?: number;
    title?: string;
    detail?: string;
    instance?: string;
}
declare class Problem {
    type?: string;
    status?: number;
    title?: string;
    detail?: string;
    instance?: string;
    set(problem: ProblemDetail): void;
    clear(): void;
    get exists(): boolean;
}
export declare const problem: Problem;
export {};
