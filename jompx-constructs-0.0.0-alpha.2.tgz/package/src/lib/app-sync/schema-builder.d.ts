import * as appsync from 'aws-cdk-lib/aws-appsync';
import * as appsyncUtils from 'awscdk-appsync-utils';
import * as cdk from 'aws-cdk-lib';
import * as stype from '../catalog/catalog.types';
import { DataSource, SchemaTypes, AppSyncOperationFields, SchemaObjectTypes } from './app-sync.types';
import * as cdirective from './directives-old';
import { Authorization } from '../authorization/authorization';
import { EntityAttributeNamePair } from '../authorization/authorization.types';
/**
 * Prebuild: codeFirstSchema and schemaTypes.
 * Synth: If it requires a real AppSync API (graphqlApi) or Lambda datasource.
 *
 * GraphQL Spec: https://spec.graphql.org/. Mostly for the backend but good to know about.
 * Cursor Edge Node: https://www.apollographql.com/blog/graphql/explaining-graphql-connections/
 * Support relay or not?
 * https://medium.com/open-graphql/using-relay-with-aws-appsync-55c89ca02066
 * Joins should be connections and named as such. e.g. in post TagsConnection
 * https://relay.dev/graphql/connections.htm#sec-undefined.PageInfo
 * https://graphql-rules.com/rules/list-pagination
 * https://www.apollographql.com/blog/graphql/basics/designing-graphql-mutations/
 * - Mutation: Use top level input type for ags. Use top level property for output type.
 */
export interface InheritAuthorizationType {
    fromTypeName: string;
    toTypeName: string;
}
export interface IAddMutationArgs {
    /**
     * The name of the mutation as it will appear in the GraphQL schema.
     */
    name: string;
    /**
     * The mutation datasource.
     */
    dataSourceName: string;
    /**
     * Mutation input (arguments wrapped in an input property).
     */
    input: appsyncUtils.InputType | AppSyncOperationFields;
    /**
     * Mutation output (return value).
     */
    output: appsyncUtils.ObjectType | AppSyncOperationFields;
    /**
     * List of auth rules to apply to the mutation and output type.
     */
    auth: appsyncUtils.Directive;
    /**
     * The class method to call on request mutation.
     */
    methodName?: string;
}
export declare class AppSyncSchemaBuilder {
    apiName: string;
    codeFirstSchema: appsyncUtils.CodeFirstSchema;
    graphqlApi: appsync.GraphqlApi;
    activeAuthorizationTypes: appsync.AuthorizationType[];
    authorization: Authorization;
    authorizationGroupNames: string[];
    dataSources: DataSource;
    schemaTypes: SchemaTypes;
    inheritAuthorizationTypes: InheritAuthorizationType[];
    constructor(apiName: string, codeFirstSchema: appsyncUtils.CodeFirstSchema, graphqlApi: appsync.GraphqlApi, activeAuthorizationTypes: appsync.AuthorizationType[], authorization: Authorization, authorizationGroupNames: string[]);
    addDataSource(lambdaFunction: cdk.aws_lambda.IFunction, options?: appsync.DataSourceOptions): appsync.LambdaDataSource;
    /**
     * Create an AppSync schema from an organization schema.
     * Will create one AppSync schema based on the API name.
     * @param schema - Organization schema.
     */
    addSchema(schema: stype.Catalog): void;
    /**
     * Add enum type objects to AppSync schema from organization schema (for an API name).
     * Enum objects must be added prior to other objects that reference.
     * Note that enum types might exist for use with custom queries/mutations only
     * and not by generated queries/mutations.
     * @param schema - Organization schema.
     */
    private addSchemaEnumTypes;
    /**
     * Add interface type objects to AppSync schema from organization schema (for an API name).
     * Interface objects must be added prior to other objects that reference.
     * @param schema - Organization schema.
     */
    private addCatalogCommonAttributeTypes;
    /**
     * Iterate global complex attributes and add each complex attribute as an object type to the AppSync schema.
     * @param schema
     */
    private addSchemaGlobalComplexAttributeTypes;
    /**
     * Iterate all entities and attributes of type complexAttribute and add them as object types to the AppSync schema.
     * TODO: Support arbitrary nested complex attributes. e.g. common attributes with common attributes.
     * @param schema
     */
    private addSchemaComplexAttributeTypes;
    /**
     * Add a complex attribute type to the AppSync schema.
     * @param schema
     * @param objectTypeName
     * @param complexAttributeProps
     * @returns
     */
    private addSchemaComplexAttributeType;
    private getSchemaRelationshipEntries;
    /**
     * Add object type objects to AppSync schema from organization schema (for an API name).
     * The organization schema consists of entities, attributes, and relationships.
     * Use string object names for references (e.g. relationships). String object names will
     * be resolved to actual objects after all objects in the AppSync schema exist.
     * For now, add directive names to objects so these can be used by AppSync custom datasources.
     * In the future, consider referencing the organization schema directly in custom datasources.
     * @param schema - Organization schema.
     */
    private addSchemaEntityTypes;
    /**
     * Merge AppSync code-first schema types into the global schema types list.
     * All AppSync objects need to exist in a global list before we can finalize the AppSync code-first schema.
     * e.g. a relationship between ObjectType A and ObjectType B (where objects exist in difference files)
     * requires both A and B to exist so that both object types can be referenced.
     * @param schemaTypes -
     */
    addSchemaTypes(schemaTypes: SchemaTypes): void;
    /**
     * Add a mutation to the GraphQL schema.
     * Wrap input in input type and output in output type.
     * https://graphql-rules.com/rules/mutation-payload
     * @returns - The created AppSync mutation object type.
     */
    addMutation({ name, dataSourceName, input, output, auth, methodName, }: IAddMutationArgs): appsyncUtils.ObjectType;
    /**
     * Iterate a list or nested list of AppSync fields and create input type(s).
     * GraphQL doesn't support nested types so create a type for each nested type recursively.
     * Types are added to the graphqlApi.
     * @param name - Create an input type with this name and an "Input" suffix.
     * @param operationFields - list of fields or nested list of AppSync fields e.g.
     * {
     *     number1: GraphqlType.int(),
     *     number2: GraphqlType.int(),
     *     test: {
     *         number1: GraphqlType.int(),
     *         number2: GraphqlType.int(),
     *     }
     * };
     * @returns - An AppSync input type (with references to nested types if any).
     */
    addOperationInputs(name: string, operationFields: AppSyncOperationFields, suffix?: string): appsyncUtils.InputType;
    /**
     * Iterate a list or nested list of AppSync fields and create output type(s).
     * GraphQL doesn't support nested types so create a type for each nested type recursively.
     * Types are added to the graphqlApi.
     * @param name - Create an output type with this name and an "Output" suffix.
     * @param operationFields - list of fields or nested list of AppSync fields e.g.
     * {
     *     number1: GraphqlType.int(),
     *     number2: GraphqlType.int(),
     *     test: {
     *         number1: GraphqlType.int(),
     *         number2: GraphqlType.int(),
     *     }
     * };
     * @returns - An AppSync input type (with references to nested types if any).
     */
    addOperationOutputs(name: string, operationFields: AppSyncOperationFields, directives: appsyncUtils.Directive[], suffix?: string): appsyncUtils.ObjectType;
    /**
     * Get an AppSync graphql type by string name. i.e. Dynamically generate a type from a string type name.
     * @param typeName - AppSync GraphqlType name as string or enum name.
     * @param returnTypeOptions -
     * @param entityNamePrefix - Why do we need this? Because we need the prefix to reference an entity inline (complex object or enum) data type with the correct name.
     * @returns - AppSync graphql type object.
     */
    private getFieldGraphqlTypeByName;
    /**
     *
     * @param attributeName
     * @param attributeProps
     * @param entityNamePrefix - Why do we need this? Because we need the prefix to reference an inline complex object with the correct name.
     * @returns
     */
    private addSchemaAttribute;
    /**
     * Add schema attributes that reference other entities as resolvable fields.
     * @param lambdaDatasource
     * @param entityNamePrefix
     * @param props
     * @returns
     */
    private addSchemaResolvableAttribute;
    create(): void;
    static authPrincipalsFromActive(activeAuthorizationTypes: appsync.AuthorizationType[]): string[];
    /**
     * TODO: We should use activeAuthorizationTypes and map these to authoriation principals e.g.
     * Also look at: authDirectivesFromActive
     *
     * const directiveMapping: Record<string, () => appsyncUtils.Directive> = {
     *   IAM: () => appsyncUtils.Directive.iam(),
     *   ApiKey: () => appsyncUtils.Directive.apiKey(),
     *   OIDC: () => appsyncUtils.Directive.oidc(),
     *   // CognitoGroup may be handled differently, perhaps accumulating groups
     * };
     *
     * Add AppSync coarse grain authorization directives to object (based on Cedar policies).
     * Iterate over AppSync authorization types and create a Cedar authorization request.
     * If the request is authorized then add the appropriate AppSync directive to the object.
     * GraphQLObjectAccess is a Jompx defined Cedar action to represent that an auth type has access to an object.
     *
     * Example Cedar policy:
     *   @description("IAM has access to GraphQL object.")
     *   permit (
     *     principal is IAM,
     *     action == Action::"GraphQLObjectAccess",
     *     resource is MysqlMovie
     *   )
     *   when { resource.apis.contains ("admin")};
     *
     * @param objectType - AppSync object type.
     */
    addAppSyncAuthDirectivesToObject(objectType: appsyncUtils.ObjectType): void;
    /**
     * Add AppSync coarse grain authorization directives to a field on an object (based on Cedar policies).
     *
     * @param objectType - AppSync object type.
     * @param authorizationAllSchemaAttributes - List of all schema attributes across all Cedar policies.
     */
    addAppSyncAuthDirectivesToObjectField(objectType: appsyncUtils.ObjectType, authorizationAllSchemaAttributes: EntityAttributeNamePair[]): void;
    static cloneInterfaceType(interfaceType: appsyncUtils.InterfaceType, directives?: appsyncUtils.Directive[] | undefined): appsyncUtils.InterfaceType;
    /**
     * Iterate object type fields and update returnType of JompxGraphqlType.objectType from string type to actual type.
     * Why? AppSync resolvable fields require a data type. But that data type may not already exist yet. For example:
     *   Post object type has field comments and Comment object type has field post. No matter what order these object types are created in, an object type won't exist yet.
     *   If comment is created first, there is no comment object type. If comment is created first, there is no post object type.
     * To work around this chicken or egg limitation, Jompx defines a custom type that allows a string type to be specified. e.g.
     *   JompxGraphqlType.objectType JompxGraphqlType.objectType({ objectTypeName: 'MPost', isList: false }),
     * This method uses the string type to add an actual type.
     *
     * Caution: Changes to AppSync implementation details may break this method.
     */
    private resolveObject;
    /**
     * Resolve an AppSync ResolvableField with a JompxGraphqlType (with string typeName) to a ResolvableField with a GraphqlType (with an actual type).
     */
    private static resolveResolvableField;
    private addCustomDirectives;
    private static addCustomSchema;
    /**
     * InputType type guard.
     * @param o - Object to test.
     * @returns - true if object is of type InputType (i.e. has definition property).
     */
    private isInputType;
    /**
     * ObjectType type guard.
     * @param o - Object to test.
     * @returns - true if object is of type ObjectType (i.e. has interfaceTypes property).
     */
    private isObjectType;
    static getAllUserPoolGroupsInSchema(objectTypes: SchemaObjectTypes): string[];
    appSyncAuthDirectivesForOperation(objectType: appsyncUtils.ObjectType, actionName: string): appsyncUtils.Directive[];
    /**
     * Given a list of auth rules, return an array of AppSync custom auth directives.
     * For user pool rules, return group rules, or if group = '*' then use the all groups AppSync directive.
     * If getting auth directives for an operation specify an action param so user pool rules can be more fine grain.
     * e.g. If action is delete and only admin group has auth to delete then only return a user pool "admin" directive and do not return directives for other groups.
     * i.e. Only the Cognito admin group has access to the delete operation and this will be enforced by AppSync.
     * Note that we can't use fine grained control for other auth types because AppSync only allows all or nothing permissions.
     * @param authRules - Array of schema auth rule directives.
     * @returns
     */
    static authToAppSyncDirectives(authRules: cdirective.AuthDirectiveRule[] | undefined, actions?: cdirective.AuthActionExtended[]): appsyncUtils.Directive[];
    static authDirectivesFromActive(activeAuthorizationTypes: appsync.AuthorizationType[], objectTypes: SchemaObjectTypes): cdirective.AuthDirectiveRule[];
    /**
     * Build an input type from an object type.
     * Include nested object fields (but ignore lookup fields). Ignore readonly fields.
     * @param sourceObjectType
     * @param sourceObjectTypeName
     * @returns - An input type (used for insert and update operations).
     */
    static buildInputTypeFromObjectType(codeFirstSchema: appsyncUtils.CodeFirstSchema, schemaTypes: SchemaTypes, sourceObjectType: appsyncUtils.ObjectType, sourceObjectTypeName: string, suffix: string): appsyncUtils.InputType;
}
