import * as graphql from 'graphql';
import * as ctype from '../../catalog/catalog.types';
import * as type from './builder.types';
/**
 * Base class for building AppSync GraphQL builders that generate SDL.
 * Variables and methods are shared across builders.
 */
export declare abstract class SchemaBuilder {
    protected registry: type.BuildRegistry;
    buildWithRegistry(registry: type.BuildRegistry, ast: graphql.DocumentNode): string;
    abstract build(ast: graphql.DocumentNode): string;
    /**
     * Add an attribute to an SDL definition.
     * @param attributeName - Name of the attribute to add.
     * @param attributeProps - Catalog attribute properties.
     * @param entityNamePrefix - Why do we need this? Because we need the prefix to reference an inline complex object with the correct name.
     * @returns
     */
    protected addAttribute(attributeName: string, attributeProps: ctype.CatalogAttributeProps, entityNamePrefix?: string): string;
    /**
     * Add a resolvable attribute to an SDL definition.
     * @param datasourceId - Name of the datasource the resolver will later use.
     * @param entityNamePrefix - Prefix to ensure correct inline complex object naming.
     * @param props - Catalog relationship definition.
     * @returns - A fully resolved SDL field string with relationship directives.
     */
    protected addResolvableAttribute(attributeName: string, datasourceId: string, entityNamePrefix: string, paginationType: ctype.ApiPaginationType, props: ctype.CatalogRelationshipProps): string;
    /**
     * Get a GraphQL SDL type by string name. i.e. dynamically generate an SDL type from a catalog return type definition.
     *
     * @param graphqlType - Catalog return type as a primitive name, enum reference, or complex attribute reference.
     * @param returnTypeOptions - Flags controlling required, list, and required-list wrapping.
     * @param entityNamePrefix - Prefix applied when resolving inline complex attributes to ensure correct SDL type naming.
     * @param isConnectionType - Whether to return a connection type (for lists with find properties).
     * @returns - A fully resolved GraphQL SDL type string.
     */
    protected resolveSdlType(graphqlType: ctype.CatalogAttributeApiReturnType, returnTypeOptions?: ctype.ApiReturnTypeOptions, entityNamePrefix?: string, isConnectionType?: boolean): string;
    protected addConnectionAndEdgeTypes(objectTypeName: string, paginationType: string): string;
}
