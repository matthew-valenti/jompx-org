import * as graphql from 'graphql';
import { SchemaBuilder } from './schema-builder';
import * as ctype from '../../catalog/catalog.types';
/**
 * Schema builder for catalog GraphQL schema.
 * Parse the catalog and build SDL definitions for entities, attributes, relationships, and operations defined in the catalog.
 */
export declare class CatalogSchemaBuilder extends SchemaBuilder {
    apiName: string;
    catalog: ctype.Catalog;
    constructor(apiName: string, catalog: ctype.Catalog);
    build(ast: graphql.DocumentNode): string;
    /**
     * Add enum types.
     *
     * Example:
     * enum MovieGenre {
     *   COMEDY
     *   DRAMA
     *   HORROR
     * }
     */
    private addEnumTypes;
    /**
     * Add common attribute types as interfaces.
     *
     * Example:
     * interface Audit {
     *   createdAt: String
     *   createdBy: String
     *   updatedAt: String
     *   updatedBy: String
     * }
     */
    private addCommonAttributeTypes;
    /**
     * Iterate global complex attributes and add each as an object type.
     *
     * Example:
     * type RelatedMovie implements Id {
     *   id: ID! @readonly(isReadonly: true)
     *   relatedMovieId: ID!
     *   mysqlMovie: [MysqlMovie]!
     *     @datasource(id: "mysql")
     *     @resolvable(isResolvable: true)
     *     @lookup(from: "MysqlMovie", localField: "relatedMovieId", foreignField: "id", type: "1-N")
     * }
     *
     * @returns
     */
    private addGlobalComplexAttributeTypes;
    /**
     * Iterate all entities and attributes of type complexAttribute.
     * TODO: Support arbitrary nested complex attributes. e.g. common attributes with common attributes.
     *
     * Example:
     * type DynamodbMovieMeta {
     *   attribute1: String
     *   attribute2: String
     *   attribute3: Int
     *   attribute4: [AWSJSON]
     *   attribute5: [String]
     * }
     */
    private addComplexAttributeTypes;
    /**
     * Add a complex attribute type.
     * @param objectTypeName
     * @param complexAttributeProps
     * @returns
     */
    private addComplexAttributeType;
    /**
     * Get relationship entries.
     * @param relationships
     * @param datasourceName
     * @param defaultIncludeInApis
     * @returns
     */
    private getRelationshipEntries;
    /**
     * Add catalog entities as object types.
     * The organization schema consists of entities, attributes, and relationships.
     */
    private addEntityTypes;
    private addOperations;
}
