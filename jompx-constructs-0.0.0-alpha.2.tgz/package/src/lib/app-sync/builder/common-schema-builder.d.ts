import * as graphql from 'graphql';
import { SchemaBuilder } from './schema-builder';
/**
 * Schema builder for common GraphQL types and directives used across the API.
 * This includes base AppSync definitions, as well as common patterns for pagination, sorting, and basic CRUD operations.
 * The common schema is included in all APIs to provide a consistent foundation of types and directives.
 */
export declare class CommonSchemaBuilder extends SchemaBuilder {
    constructor();
    build(ast: graphql.DocumentNode): string;
}
