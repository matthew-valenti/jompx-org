export interface InheritAuthorizationType {
    fromTypeName: string;
    toTypeName: string;
}
export type BuildRegistry = {
    connections: Set<string>;
    inheritAuthorizationTypes: InheritAuthorizationType[];
};
