import { SchemaBuilder } from './schema-builder';
/**
 * Run chain of graphql builders to produce a single SDL string.
 * Each builder can reference the registry and the AST built so far, allowing for interdependencies between builders.
 * The registry is a shared mutable object that builders can use to store and reference information across the build process.
 * Each builder adds to the overall schema, and can reference types built by previous builders in the chain.
 *
 * Usage example:
 * const builder = new GraphqlSchemaBuilder()
 *   .add(new CommonSchemaBuilder())
 *   .add(new CatalogSchemaBuilder(catalog))
 *   .add(new MetaSchemaBuilder());
 *   .add(new AuthSchemaBuilder(authProps));
 * const sdl = builder.build();
 */
export declare class GraphqlSchemaBuilder {
    private builders;
    private registry;
    add(builder: SchemaBuilder): this;
    build(): string;
}
