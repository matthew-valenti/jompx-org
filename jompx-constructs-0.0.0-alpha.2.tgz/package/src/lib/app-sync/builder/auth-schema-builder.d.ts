import * as graphql from 'graphql';
import * as appsyncUtils from 'awscdk-appsync-utils';
import { Authorization } from '../../authorization/authorization';
import { SchemaBuilder } from './schema-builder';
/**
 * Schema builder for AppSync authorization directives based on Cedar policies.
 * For each object and field in the GraphQL schema, this builder checks the Cedar policies to determine which AppSync auth directives to add.
 */
export interface AuthProps {
    instance: Authorization;
    principalTypes: string[];
    groupNames: string[];
}
export declare class AuthSchemaBuilder extends SchemaBuilder {
    apiName: string;
    authorizationProps: AuthProps;
    private objectAuthorizationDirectives;
    constructor(apiName: string, authorizationProps: AuthProps);
    build(ast: graphql.DocumentNode): string;
    private addOperationAuth;
    private addObjectAuth;
    private addObjectFieldAuth;
    private addComplexObjectFieldAuth;
    appSyncAuthDirectiveForOperation(objectTypeName: string, operationName: string): appsyncUtils.Directive[];
    /**
     * TODO: We should use activeAuthorizationTypes and map these to authoriation principals e.g.
     * Also look at: authDirectivesFromActive
     *
     * const directiveMapping: Record<string, () => appsyncUtils.Directive> = {
     *   IAM: () => AppSyncDirectiveWrapper.iam(),
     *   ApiKey: () => AppSyncDirectiveWrapper.apiKey(),
     *   OIDC: () => AppSyncDirectiveWrapper.oidc(),
     *   // CognitoGroup may be handled differently, perhaps accumulating groups
     * };
     *
     * Add AppSync coarse grain authorization directives to object (based on Cedar policies).
     * Iterate over AppSync authorization types and create a Cedar authorization request.
     * If the request is authorized then add the appropriate AppSync directive to the object.
     * GraphQLObjectAccess is a Jompx defined Cedar action to represent that an auth type has access to an object.
     *
     * Example Cedar policy:
     *   @description("IAM has access to GraphQL object.")
     *   permit (
     *     principal is IAM,
     *     action == Action::"GraphQLObjectAccess",
     *     resource is MysqlMovie
     *   )
     *   when { resource.apis.contains ("admin")};
     *
     * @param objectType - AppSync object type.
     */
    appSyncAuthDirectivesForObject(objectTypeName: string): appsyncUtils.Directive[];
    /**
     * Add AppSync coarse grain authorization directives to a field on an object (based on Cedar policies).
     *
     * @param objectType - AppSync object type.
     * @param authorizationAllSchemaAttributes - List of all schema attributes across all Cedar policies.
     */
    appSyncAuthDirectivesForObjectField(objectTypeName: string, attributeName: string): appsyncUtils.Directive[];
    private operationNameFromObjectName;
    private mergeDirectives;
    private getOperationResourceTypeName;
    private tryResolveConnectionNodeTypeName;
    private getObjectType;
    private getNamedTypeName;
}
