import * as graphql from 'graphql';
export declare class SchemaSanitizerBuilder {
    /**
     * Sanitize an AppSync GraphQL schema.
     * We must add AWS and internal custom directives to the graphql schema for codegen.
     * However, we must remove these before passing the schema to AppSync.
     * @param sdl - GraphQL SDL string to sanitize.
     * @returns - Sanitized GraphQL SDL string.
     */
    build(sdl: string): string;
    sanitizeCustomDirectives(ast: graphql.DocumentNode): graphql.DocumentNode;
    private sanitizeAwsScalars;
    private sanitizeAwsDirectiveDefinitions;
    private static getAwsScalarNames;
    private static getAwsDirectiveNames;
    private static isAwsDirective;
}
