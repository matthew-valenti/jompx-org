import * as graphql from 'graphql';
import * as appsync from 'aws-cdk-lib/aws-appsync';
import * as cdk from 'aws-cdk-lib';
export declare class SchemaResolverBuilder {
    graphqlApi: appsync.GraphqlApi;
    private datasources;
    private resolverPlans;
    constructor(graphqlApi: appsync.GraphqlApi);
    build(ast: graphql.DocumentNode): void;
    buildFile(schemaPath: string): void;
    registerDataSource(lambdaFunction: cdk.aws_lambda.IFunction, options?: appsync.DataSourceOptions): appsync.LambdaDataSource;
    stripCustomDirectives(ast: graphql.DocumentNode): string;
    private buildRequestMappingTemplate;
}
