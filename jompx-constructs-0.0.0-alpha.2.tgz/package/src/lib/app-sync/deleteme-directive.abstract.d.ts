import { Directive } from 'awscdk-appsync-utils';
import { SchemaTypes } from './app-sync.types';
/**
 * Abstract custom directive class. Custom directives to extend this class and implement abstract methods.
 * AppSync supports string value directives only.
 * Documentation: https://www.apollographql.com/docs/apollo-server/schema/creating-directives/
 */
export declare abstract class CustomDirective {
    getValue<T>(name: string, directives?: Directive[]): T | undefined;
    static encodeArguments(json: object): string;
    static decodeArgument(encodedJson: string): any;
    static getIdentifierArgument(identifier: string, argument: string, directives: any[] | undefined): string | undefined;
    /**
     * Directive definition (to be added to GraphQL schema).
     * Return string e.g. directive @auth(rules: [AuthRule!]!) on OBJECT | INTERFACE | FIELD_DEFINITION
     */
    abstract definition(): string;
    /**
     * Directive schema (to be to added to GraphQL schema).
     * e.g. Auth directives adds enums and input types (required to support the definition).
     * @param _schemaTypes - Global list of types.
     */
    schema(_schemaTypes: SchemaTypes): void;
}
