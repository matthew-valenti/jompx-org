import { AuthorizationType } from 'aws-cdk-lib/aws-appsync';
import { SchemaTypes } from '../app-sync.types';
/**
 * Abstract custom schema class. Implement global schemas for use across all datasources.
 * Documentation: https://www.apollographql.com/docs/apollo-server/schema/creating-directives/
 */
export declare abstract class CustomSchema {
    /**
     * Schema (to be to added to GraphQL schema).
     * @param schemaTypes - Global list of types.
     */
    abstract schema(_schemaType: SchemaTypes, _activeAuthorizationTypes?: AuthorizationType[]): void;
}
