import { AuthorizationType } from 'aws-cdk-lib/aws-appsync';
import { SchemaTypes } from '../app-sync.types';
import { CustomSchema } from './schema.abstract';
export declare class UpdateManySchema extends CustomSchema {
    schema(schemaTypes: SchemaTypes, activeAuthorizationTypes: AuthorizationType[]): void;
}
