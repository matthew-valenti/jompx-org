import * as appsync from 'aws-cdk-lib/aws-appsync';
import * as cdk from 'aws-cdk-lib';
import { Construct } from 'constructs';
import { CedarPolicySet } from '../authorization/cedar.types';
export interface AppSyncPropsGraphql {
    schemaFilePath: string;
    introspectionFilePath: string;
    directivesFilePath: string;
}
export interface AppSyncPropsAuthorization {
    policies: CedarPolicySet;
    additionalAuthorizationModes?: appsync.AuthorizationMode[];
}
export interface AppSyncProps {
    /**
     * Name of the AppSync GraphQL resource as it appears in the AWS Management Console.
     * Generally the same name as the api name in schema.
     * The name (snake case), is used as the api subdomain url.
     */
    name: string;
    domainName?: appsync.DomainOptions;
    graphql: AppSyncPropsGraphql;
    authorization: AppSyncPropsAuthorization;
    userPool?: cdk.aws_cognito.UserPool;
}
/**
 * AWS AppSync (serverless GraphQL).
 */
export declare class AppSync extends Construct {
    graphqlApi: appsync.GraphqlApi;
    activeAuthorizationTypes: appsync.AuthorizationType[];
    graphqlLambdaLayer: cdk.aws_lambda.LayerVersion;
    constructor(scope: Construct, id: string, props: AppSyncProps);
    /**
     * TODO: Short term approach. Plan to refactor this. Consider exposing as construct. AppSync construct should receive an already instantiated policies file. i.e. Don't hide this away - it's too specific.
     * This ssm approach remains deterministic and aligns with CDK best practices because the SSM parameters are expected to be created programmatically within the same CDK app (or related apps) with predictable and consistent values.
     * As long as these parameters are defined and managed within the CDK lifecycle, their existence and values are tied to a controlled deployment process, ensuring that the stack behavior is predictable across deployments.
     * It only becomes non-deterministic if the SSM parameters are modified, added, or removed outside the CDK process (e.g., manually through the console or other tools) at unknown times or with unknown values, as this introduces variability outside the CDK's control.
     * Thus, the key to determinism lies in ensuring all dependencies are part of the CDK-managed infrastructure.
     * @param policies
     * @returns
     */
    private instansiateAuthorization;
}
