export { AppSyncMongoDbDataSource } from './mongodb-datasource.construct';
export * as AppSyncMongoDbDatasourceType from './mongodb-datasource.types';
