import { AppSyncMongoDbDataSourceOptions } from './mongodb-datasource.construct';
import * as base from '../base/base-datasource';
import * as btype from '../base/base-datasource.types';
import * as mongodb from 'mongodb';
/**
 * MongoDB will perform aggregation pipeline optimization: https://www.mongodb.com/docs/manual/core/aggregation-pipeline-optimization/
 */
export declare class AppSyncMongoDbDatasource extends base.AppSyncDatasource {
    options: AppSyncMongoDbDataSourceOptions;
    client: mongodb.MongoClient | undefined;
    db: mongodb.Db | undefined;
    mongod: any;
    constructor(region: string, options: AppSyncMongoDbDataSourceOptions);
    getDb(): Promise<mongodb.Db>;
    closeConnection(): Promise<void>;
    find(event: btype.AppSyncResolverEvent): Promise<btype.ConnectionOutput & btype.ProblemProperty>;
    private findStatement;
    findOne(event: btype.AppSyncResolverEvent): Promise<btype.ConnectionNodeOutput & btype.ProblemProperty>;
    private findOneStatement;
    insertOne(event: btype.AppSyncResolverEvent): Promise<btype.InsertOneOutput & btype.ProblemProperty>;
    private insertOneStatement;
    insertMany(event: btype.AppSyncResolverEvent): Promise<btype.InsertManyOutput & btype.ProblemProperty>;
    private insertManyStatement;
    upsertOne(event: btype.AppSyncResolverEvent): Promise<btype.UpsertOneOutput & btype.ProblemProperty>;
    /**
     * Upsert a row. If unique key does not already exist then insert else update existing row.
     * https://stackoverflow.com/questions/75490808/mysql-upsert-with-insert-only-column-value/75491061#75491061
     * An upsert statement is made of two parts insert + update. Insert and update fields do not have to be the same.
     * This is important for default values. Insert default values are to be used on insert only while update default values are to be used on update only.
     * Example MySQL syntax (with unique index on movie name):
     *   This statement inserts a row with both createdBy and updatedBy = Jill. Note that there is no createdBy column specified on the update part.
     *     INSERT INTO `movie` (`name`, `createdBy`, `updatedBy`) VALUES ('The Matrix', 'Jill', 'Jill') ON DUPLICATE KEY UPDATE `name` = VALUES(`name`), `updatedBy` = VALUES(`updatedBy`);
     *   This same statement updates the same row. But only updatedBy is updated to Bob. createdBy remains the same.
     *     INSERT INTO `movie` (`name`, `createdBy`, `updatedBy`) VALUES ('The Matrix', 'Bob', 'Bob') ON DUPLICATE KEY UPDATE `name` = VALUES(`name`), `updatedBy` = VALUES(`updatedBy`);
     * @returns
     */
    private upsertOneStatement;
    upsertMany(event: btype.AppSyncResolverEvent): Promise<btype.UpsertManyOutput & btype.ProblemProperty>;
    private upsertManyStatement;
    deleteOne(event: btype.AppSyncResolverEvent): Promise<btype.DeleteOutput & btype.ProblemProperty>;
    private deleteOneStatement;
    private interpretFilter;
    private interpretAggregation;
    private fieldFromPath;
    /**
     * Convert a field path to a field name suitable for use in a SQL statement.
     * Example 1 (not nested): ['id'] = movie`.`id`
     * Example 2 (nested): ['mMovieActors', 'mActor', 'id'] = `mActor`.`id`
     * SQL field names are always made up of two parts (table name + field name).
     * For nested paths, the 2nd last fieldname will be the table alias name.
     * @param fieldNamePath - Array of field paths. e.g. ['mMovieActors', 'mActor', 'id']
     * @param tableName - Top level table name to append to top level field names. e.g. movie
     * @returns - Field name for use in a SQL statement. e.g. `mActor`.`id`
     */
    private fieldPathToFieldName;
    /**
     * Assumption: The database stores dates and times in UTC.
     * @param rawValues
     * @param typeName
     * @returns
     */
    private formatValueAsDbType;
    private sortStatement;
    private joins;
    /**
     * Return the full source path of a selection.
     * Given a bottom level selection (e.g. field) return the full source path of the field by traversing selection parents.
     * e.g. actorId = mongoDbMovieActors.movieId.
     * @param selection - Selection object reference (with a selections object).
     * @returns - Source path string in MongoDB dot notation. i.e. The physical source field name.
     */
    private sourcePathFromSelection;
    /**
     * TODO: Interesting! This is very complicated. This has  been changed for MongoDB but can we move it to the base class?
     * Select top level fields and top level objects only. MongoDB will automatically project child fields from $lookups.
     * @param aliasName
     * @param selections
     * @returns
     */
    private select;
    private backtick;
    /**
     * Handle database query error.
     * IMPORTANT: For security, do not send database error messages to clients in production environments.
     * TODO: Log errors to CloudWatch.
     */
    handleDatabaseError(error: unknown): void;
}
