import * as cdk from 'aws-cdk-lib';
import { Construct } from 'constructs';
import * as ltypes from './mongodb-datasource.types';
export interface AppSyncMongoDbDataSourceProps {
    datasourceId: string;
    lambdaFunctionProps?: cdk.aws_lambda_nodejs.NodejsFunctionProps;
    layers?: cdk.aws_lambda.LayerVersion[];
    subscriber?: {
        moduleName: string;
        className: string;
    };
    options: AppSyncMongoDbDataSourceOptions;
}
export interface AppSyncMongoDbDataSourceOptions {
    engine: ltypes.Engine;
    connection: {
        connectionString: string;
        secretName: string;
        databaseName: string;
    };
    defaultLimit?: number;
    maxLimit?: number;
    log?: {
        sql?: boolean;
        errors?: boolean;
    };
}
export declare class AppSyncMongoDbDataSource extends Construct {
    lambdaFunction: cdk.aws_lambda.IFunction;
    props: AppSyncMongoDbDataSourceProps;
    constructor(scope: Construct, id: string, props: AppSyncMongoDbDataSourceProps);
}
