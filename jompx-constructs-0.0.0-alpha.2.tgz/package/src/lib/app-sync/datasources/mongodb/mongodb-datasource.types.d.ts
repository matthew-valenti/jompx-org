import { DatasourceField, SchemaField } from '../base/base-datasource.types';
import * as mongodb from 'mongodb';
export declare const engine: readonly ["mongodb-memory-server", "mongodb-memory-server-replica", "mongodb_8.x"];
export type Engine = typeof engine[number];
export interface FindStatement {
    collectionName: string;
    pipeline: mongodb.Document[];
}
export interface DbDatasourceField {
    fieldName: string;
    fieldTypeName: string;
    schemaFields: SchemaField[];
}
export interface DbDatasourceJoinHierarchy {
    id: string;
    parentObjectName: string;
    parentAliasName: string;
    schemaField: SchemaField;
    projectSchemaFields: SchemaField[];
    children: DbDatasourceJoinHierarchy[];
}
export interface DbDatasourceJoin {
    statements: DbDatasourceJoinStatement[];
    fields: DatasourceField[];
}
export interface DbDatasourceJoinStatement {
    $lookup: {
        from: string;
        let: object;
        pipeline: object[];
        as: string;
    };
}
export interface DbInterpretedFilter {
    filter: string | object;
    fields: DatasourceField[];
}
export interface DbInterpretedAggregation {
    aggregation: string | object;
    fields: DatasourceField[];
}
export interface CreateConnectionArgs {
    connectionString: string;
    username: string;
    password: string;
    databaseName: string;
}
export interface ConnectionSecretValue {
    username: string;
    password: string;
}
export interface InsertOneStatement {
    collectionName: string;
    document: object;
}
export interface InsertManyStatement {
    collectionName: string;
    documents: object[];
}
export interface UpsertOneStatement {
    collectionName: string;
    filter: object;
    update: object;
}
export interface UpsertManyStatement {
    collectionName: string;
    upserts: mongodb.AnyBulkWriteOperation<mongodb.BSON.Document>[];
}
export interface UpsertManyStatementUpsert {
    updateOne: {
        filter: object;
        update: object;
        upsert: boolean;
    };
}
export interface DeleteOneStatement {
    collectionName: string;
    filter: object;
}
