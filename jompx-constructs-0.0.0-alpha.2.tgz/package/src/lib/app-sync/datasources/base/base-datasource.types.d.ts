/// <reference types="node" />
import * as lambda from 'aws-lambda';
import { EventEmitter } from 'events';
import { Authorization } from '../../../authorization/authorization';
import { AuthDirectiveValue } from '../../directives-old';
import { CedarPolicySet } from '../../../authorization/cedar.types';
export type AppSyncResolverEvent = lambda.AppSyncResolverEvent<AppSyncResolverEventArguments>;
export interface Env {
    apiName: string;
    datasourceId: string;
    defaultLimit: number;
    maxLimit: number;
    schema: any;
    schemaDirectives: any;
    policies: CedarPolicySet;
    authorization: Authorization;
    disableAuthorization: boolean;
    eventEmitter: EventEmitter;
}
export interface Ctx {
    request: {
        event: AppSyncResolverEvent;
        identity: DatasourceIdentity;
        operation: DataSourceOperation;
        baseSelections: DatasourceSelection[];
        baseFilter: BaseFilter;
        baseSorts: DatasourceField[];
        skip: number;
        limit: number;
    };
    runtime: {};
}
export interface AppSyncCommonDataSourceOptions {
    maxLimit: number;
    defaultLimit: number;
    connection: {
        secretName: string;
    };
}
import { CompositeEntityPhysicalNameDirectiveValue, DefaultValueDirectiveValue, DatasourceDirectiveValue, LookupDirectiveValue, OperationDirectiveValue, PartitionKeyDirectiveValue, PhysicalNameDirectiveValue, ReadonlyDirectiveValue, SecondaryIndexDirectiveValue, SetDirectiveValue, SortKeyDirectiveValue } from '../../directives';
import { AuthAction, AuthDirectiveRule, AuthType } from '../../directives-old';
import { AggregationInterpreterProps } from './arg-parsers/aggregation';
import { FilterInterpreterProps } from './arg-parsers/filter';
import { UpdateInterpreterProps } from './arg-parsers/update';
import { ProblemProperty } from '../../problem';
export type { AggregationInterpreterProps, FilterInterpreterProps, UpdateInterpreterProps, AuthAction as AuthDirectiveAuthAction, AuthType as AuthDirectiveAuthType, AuthDirectiveRule, ProblemProperty, };
export interface AppSyncResolverEventArguments {
    filter?: object;
    limit?: number;
    skip?: number;
    insert?: object;
    inserts?: object;
    sort?: DatasourceSortArgument;
    props?: any;
    update?: object;
    upsert?: {
        filter: object;
        update: object;
    };
    upserts?: object;
}
export type AppSyncIdentity = lambda.AppSyncIdentityIAM | lambda.AppSyncIdentityCognito | lambda.AppSyncIdentityOIDC | lambda.AppSyncIdentityLambda | null | undefined;
export interface DatasourceIdentity {
    type: 'apiKey' | 'iam' | 'oidc' | 'userPool' | 'function';
    id: string;
    username?: string;
    groups?: string[];
}
export interface DataSourceOperation {
    isChild: boolean;
    methodName: string;
    authAction: string;
    objectTypeName: string;
    objectTypeSchema: SchemaType;
    returnTypeName: string;
    childSchemaField?: SchemaField;
}
export interface ChildOperationMap {
    [key: string]: {
        list: string;
        one: string;
    };
}
export interface XDatasource {
    operation: XDatasourceOperation;
}
export interface XDatasourceOperation {
    methodName: string;
    isChild: boolean;
    objectTypeName: string;
    returnTypeName: string;
}
export interface SchemaOperation {
    name: string;
    returnTypeName: string;
    args: [];
    baseKind: string;
    baseName: string;
    type: {
        kind: string;
        name: string;
        ofType: SchemaFieldOfType;
    };
    isDeprecated: boolean;
    deprecationReason: string | null;
}
export interface SchemaType {
    name: string;
    source: string;
    kind: string;
    returnType?: SchemaType;
    fields: SchemaField[];
    interfaces: SchemaInterface[];
    directives: {
        auth: AuthDirectiveValue;
    } & {
        compositeEntityPhysicalName: CompositeEntityPhysicalNameDirectiveValue;
    } & {
        datasource: DatasourceDirectiveValue;
    } & {
        operation: OperationDirectiveValue;
    } & {
        secondaryIndex: SecondaryIndexDirectiveValue;
    } & {
        physicalName: PhysicalNameDirectiveValue;
    };
}
export interface SchemaField {
    name: string;
    source: string;
    args: [];
    baseKind: string;
    baseName: string;
    type: {
        kind: string;
        name: string;
        ofType: SchemaFieldOfType;
        schemaType?: SchemaType;
        parentTypeName?: string;
    };
    isDeprecated: boolean;
    deprecationReason: string | null;
    directives: {
        auth: AuthDirectiveValue;
    } & {
        datasource: DatasourceDirectiveValue;
    } & {
        defaultValue: DefaultValueDirectiveValue;
    } & {
        lookup: LookupDirectiveValue;
    } & {
        partitionKey: PartitionKeyDirectiveValue;
    } & {
        readonly: ReadonlyDirectiveValue;
    } & {
        set: SetDirectiveValue;
    } & {
        sortKey: SortKeyDirectiveValue;
    } & {
        physicalName: PhysicalNameDirectiveValue;
    };
}
export interface SchemaFieldOfType {
    kind: string;
    name: string;
    ofType: SchemaFieldOfType | string | null;
}
export interface SchemaFieldBaseType {
    kind: string;
    name: string;
}
export interface SchemaInterface {
    name: string;
    kind: string;
}
export interface SchemaDirective {
    name: string;
    arguments: SchemaDirectiveArgument[];
}
export interface SchemaDirectiveArgument {
    name: string;
    value: string;
}
export type SortOrder = 'asc' | 'desc';
export interface DatasourceField {
    fieldName: string;
    schemaFields: SchemaField[];
    sortOrder?: SortOrder;
}
export interface DatasourceSelection {
    selection: string;
    parentSelection: string | null;
    schemaField: SchemaField;
    parent: DatasourceSelection | null;
    children?: DatasourceSelection[];
}
export interface BaseFilter {
    argument: object;
    authorization: object;
    child: object;
}
export interface DatasourceSortArgument {
    [key: string]: number;
}
export interface DatasourceJoin {
    id: string;
    datasourceId: string;
    from: SchemaType;
    fromField: SchemaField;
    localField?: SchemaField;
    foreignField?: SchemaField;
    let: object;
    pipeline: object[];
    children: DatasourceJoin[];
}
export type Maybe<T> = T | null;
export interface ConnectionOutput {
    edges?: Maybe<Array<Maybe<ConnectionOutputEdge>>>;
    pageInfo?: PageInfoOffset | PageInfoCursor;
    totalCount?: number;
}
export interface ConnectionOutputEdge {
    cursor?: string;
    node?: Maybe<ConnectionNodeOutput>;
}
export type ConnectionNodeOutput = {
    [key: string]: unknown;
} | null;
export type ConnectionNodeOutputs = ConnectionNodeOutput[] | null;
export interface PageInfoOffset {
    skip: number;
    limit: number;
}
export interface PageInfoCursor {
    hasPreviousPage: boolean;
    hasNextPage: boolean;
    startCursor: string;
    endCursor: string;
}
export interface InsertOneOutput {
    insertedId: string | null;
}
export interface InsertManyOutput {
    insertedIds: (string | null)[];
}
export interface UpsertOneOutput {
    upsertedId: string | null;
    modifiedCount: number;
}
export interface UpsertManyOutput {
    upsertedIds: string[];
    modifiedCount: number;
}
export interface UpdateOutput {
    modifiedCount: number;
}
export interface DeleteOutput {
    deletedCount: number;
}
