import { AppSyncCommonDataSourceOptions, AppSyncResolverEvent, AuthDirectiveAuthAction, AuthDirectiveAuthType, AuthDirectiveRule, ConnectionOutput, ConnectionNodeOutput, ConnectionNodeOutputs, Ctx, DatasourceField, DatasourceJoin, DatasourceSelection, Env, PageInfoOffset, PageInfoCursor, SchemaField, SchemaOperation, SchemaType, XDatasource } from './base-datasource.types';
import { problem } from '../../problem';
export { problem };
import { AggregationParser } from './arg-parsers/aggregation';
export { AggregationParser };
import { FilterParser } from './arg-parsers/filter';
export { FilterParser };
import { UpdateParser } from './arg-parsers/update';
export { UpdateParser };
export declare class AppSyncDatasource {
    private static readonly defaultFileNames;
    env: Env;
    region: string;
    secret: unknown;
    /**
     * Constructor.
     * Lambda layer static files are copied to the Lambda /opt folder.
     * @param fileNames - Object containing explicit file names. In Lambda these files are loaded from /opt by default.
     */
    constructor(region: string, fileNames?: {
        introspectionFileNameJson?: string;
        directivesFileNameJson?: string;
        authorizationPoliciesFileNameJson?: string;
    });
    init(event: AppSyncResolverEvent, options?: AppSyncCommonDataSourceOptions): Promise<Ctx>;
    /**
     * Get a secret value from AWS Secrets Manager. This is used for database connection credentials.
     * @param region - AWS region where the secret is stored.
     * @param secretName - Name of the secret in AWS Secrets Manager.
     * @returns - Parsed secret value. Throws on retrieval failure. Returns an empty object if the secret exists but has no value.
     */
    private getConnectionSecretValue;
    /**
     * Get limit. Never return all rows. A limit is required for safety. If no limit then use a sensible default.
     * Use the request limit or datasource default limit. Never return more than the max limit.
     *
     * @param datasourceMaxLimit
     * @param datasourceDefaultLimit
     * @param requestLimit
     * @returns
     */
    getLimit(datasourceMaxLimit: number | undefined, datasourceDefaultLimit: number | undefined, requestLimit: number | undefined): number;
    /**
     * Represent all joins as pipeline joins. Simplify datasources by handling one join syntax only.
     * @returns
     */
    getBaseJoins(ctx: Ctx, criteriaFields: DatasourceField[]): DatasourceJoin[];
    /**
     * Sanatize variable name. MongoDB does not allow underscore or period char in a variable name.
     * @param variableName - Variable name.
     * @returns - Sanatized variable name. Not allowed chars removed.
     */
    private sanitizeDbVariableName;
    /**
     * Get authorization type used to invoke the data source resolver.
     * Caution: This is undocumented. Derive the authorization type based on Lambda event properties.
     * AppSync interfaces for reference: node_modules\@types\aws-lambda\trigger\appsync-resolver.d.ts
     */
    authorizationType(event: AppSyncResolverEvent): AuthDirectiveAuthType | undefined;
    /**
     * Get the operation CRUD action (create, read, update, delete).
     * Supports standard actions only.
     * TODO: Allow datasource to specify operation to action mapping.
     */
    getAuthAction(fieldName: string): AuthDirectiveAuthAction;
    private buildIdentity;
    /**
     * An operation is the GraphQL operation to run (and will return results) e.g. findOne.
     * However, an operation can be made up of many child operations.
     * For example, a findOne operation includes a field that requires a collection of data from a different datasource.
     * So the findOne operation will first be sent to datasource1 and then the child findMany operation will be sent to datasource2.
     * A datasource will return results for a single operation. The results of many operations are combined to return results for the top level operation.
     * @returns - GraphQL operation to run properties.
     */
    private buildOperation;
    private buildBaseFilters;
    static filterConcat(filters: object[], operator?: string): object;
    /**
     * Get contents of custom event header x-datasource.
     */
    getXDatasource(event: AppSyncResolverEvent): XDatasource;
    /**
     * Get a list of object field selections by path.
     * e.g. It's common to want a list of selected fields starting from the node level.
     * A path of edges/node i.e. ['edges', 'node] will return a list with three fields: id, name, mongoDbMovieActors.
     * The mongoDbMovieActors field will contain an array of selection children: movieId, actorId
     *
     * 'edges',
     *   'edges/node',
     *     'edges/node/id',
     *     'edges/node/name',
     *     'edges/node/mongoDbMovieActors',
     *       'edges/node/mongoDbMovieActors/movieId'
     *        'edges/node/mongoDbMovieActors/actorId'
     *
     * @param path - Path string array e.g. edges/node = ['edges', 'node].
     * @returns - Array of object fields.
     */
    getBaseSelectionsByPath(ctx: Ctx, path?: string[]): DatasourceSelection[];
    /**
     * Convert rows to Relay-style connection output.
     * Keep options optional so callers can include pageInfo/totalCount only when selected.
     */
    toGraphqlConnection(rows: ConnectionNodeOutputs, options?: {
        skip?: number;
        limit?: number;
        totalCount?: number;
        pageInfo?: PageInfoOffset | PageInfoCursor;
    }): ConnectionOutput;
    toGraphqlNode(node: ConnectionNodeOutput): {
        node: ConnectionNodeOutput;
    };
    private buildSelections;
    /**
     * Returns true if filter is a valid BSON document. Does NOT validate filter syntax (e.g. operators or operator syntax).
     * @param filterArgument - filter argument from datasource Lambda event.
     * @returns
     */
    private isValidFilter;
    /**
     * Build a list of sort fields.
     * @param sortArgument - sort argument from datasource Lambda event.
     * @returns
     */
    private buildSorts;
    getSchemaOperation(operationName: string): SchemaOperation;
    getSchemaType(typeName: string, fieldName?: string): SchemaType;
    /**
     * Get an array of schema field objects that match a schema field path.
     * Path must start from the parent object.
     * @param fieldPath
     */
    getSchemaFieldsByPath(schemaTypeName: string, fieldPath: string, errorIfNotFound?: boolean): SchemaField[];
    /**
     * Get active auth rules (that match the current operation).
     * a. Get auth rules for the current auth type.
     * b. Get rules for the matching action (create, read, update, delete). Every operation must match to an action.
     * c. If auth rule is userPool then also match on current user group. A user can belong to zero or many Cognito groups.
     * d. A rule can have an optional condition. So multiple rules can result in multiple conditions.
     * A wilcard (*) value matches all possible property values.
     * @param rules - Schema authorization rules.
     * @returns
     */
    getAuthRules(ctx: Ctx, rules: AuthDirectiveRule[]): AuthDirectiveRule[];
    /**
     * Return true if the action is authorized for the curent user. i.e. Does the user have access to the entity + action requested.
     * Runtime authorization is at the user level i.e. the principal is a user and not a provider or user group.
     * However, the authorization request for a user does contain user groups.
     * So policies where principal is a user group are valid.
     * @param schemaType
     * @param action - Action name e.g. FindOne, Find, etc. If not provided then defaults to the current operation action.
     * @returns
     */
    isObjectAuthorized(event: AppSyncResolverEvent, schemaType: SchemaType, action: string): boolean;
    isOperationAuthorized(schemaType: SchemaType): boolean;
    /**
     * Build authorization filter object from schema auth rules.
     * a. Get auth rules for the current auth type.
     * b. Get rules for the matching action (create, read, update, delete). Every operation must match to an action.
     * c. If auth rule is userPool then also match on current user group. A user can belong to zero or many Cognito groups.
     * d. A rule can have an optional condition. So multiple rules can result in multiple conditions.
     * e. Multiple conditions are combined with an $or operator. i.e. If a user can satisfy any one rule then the operation will be successful.
     * @param rules - Schema type auth rules.
     * @returns - Authorization filter object.
     */
    getAuthorizationFilter(rules: AuthDirectiveRule[]): object;
    /**
     * Walk a GraphQL field type reference chain (`type -> ofType -> ofType ...`) and return the deepest named type.
     * This unwraps wrappers like `NON_NULL` and `LIST`.
     *
     * Example 1:
     * NON_NULL -> LIST -> NON_NULL -> OBJECT(DynamodbMovieActorConnection)
     * returns { kind: "OBJECT", name: "DynamodbMovieActorConnection" }.
     *
     * Example 2:
     * NON_NULL -> SCALAR(ID)
     * returns { kind: "SCALAR", name: "ID" }.
     *
     * Note:
     * This method only unwraps the current field's type reference wrappers.
     * It does not traverse schema fields like `Connection.edges.node`.
     */
    private getFieldBaseType;
    private isJson;
    /**
     * Handle datasource query error.
     * IMPORTANT: For security, do not send database error messages to clients in production environments.
     */
    handleDatabaseError(error: unknown, shouldLog?: boolean): void;
    protected find?(event: AppSyncResolverEvent): Promise<any>;
    protected findOne?(event: AppSyncResolverEvent): Promise<any>;
    protected insertOne?(event: AppSyncResolverEvent): any;
    protected insertMany?(event: AppSyncResolverEvent): any;
    protected upsertOne?(event: AppSyncResolverEvent): any;
    protected upsertMany?(event: AppSyncResolverEvent): any;
    protected updateOne?(event: AppSyncResolverEvent): Promise<any>;
    protected updateMany?(event: AppSyncResolverEvent): Promise<any>;
    protected deleteOne?(event: AppSyncResolverEvent): any;
    protected deleteMany?(event: AppSyncResolverEvent): any;
}
