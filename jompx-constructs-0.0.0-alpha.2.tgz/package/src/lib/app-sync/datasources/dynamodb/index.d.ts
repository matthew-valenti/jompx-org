export { AppSyncDynamoDbDataSource } from './dynamodb-datasource.construct';
export * as AppSyncDynamoDbDatasourceType from './dynamodb-datasource.types';
