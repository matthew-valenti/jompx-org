import * as cdk from 'aws-cdk-lib';
import { Construct } from 'constructs';
export interface IAppSyncDynamoDbDataSourceProps {
    datasourceId: string;
    lambdaFunctionProps?: cdk.aws_lambda_nodejs.NodejsFunctionProps;
    layers?: cdk.aws_lambda.LayerVersion[];
    subscriber?: {
        moduleName: string;
        className: string;
    };
    options: AppSyncDynamoDbDataSourceOptions;
}
export interface AppSyncDynamoDbDataSourceOptions {
    defaultLimit?: number;
    maxLimit?: number;
}
export declare class AppSyncDynamoDbDataSource extends Construct {
    lambdaFunction: cdk.aws_lambda.IFunction;
    props: IAppSyncDynamoDbDataSourceProps;
    constructor(scope: Construct, id: string, props: IAppSyncDynamoDbDataSourceProps);
}
