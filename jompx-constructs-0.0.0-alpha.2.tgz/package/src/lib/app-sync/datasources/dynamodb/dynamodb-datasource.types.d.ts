import * as dynamodb from '@aws-sdk/client-dynamodb';
import { SchemaField } from '../base/base-datasource.types';
export interface MySqlPreparedStatement {
    sql: string;
    values: unknown[];
}
export interface DynamoDbDatasourceField {
    fieldName: string;
    expressionFieldName: string;
    expressionAttributeName: object;
    fieldTypeName: string;
    fieldTypeCode: string;
    schemaFields: SchemaField[];
}
export interface DynamoDbDataSourceFilter {
    key: object;
    filter?: object;
    condition?: object;
}
export type ExpressionAttributeNames = Record<string, string>;
export type ExpressionAttributeValues = Record<string, any> | undefined;
export type TableKey = Record<string, any> | undefined;
export interface DynamoDbInterpretedFilter {
    expression: string;
    expressionAttributeNames: ExpressionAttributeNames;
    expressionAttributeValues: ExpressionAttributeValues;
}
export interface DynamoDbInterpretedFilterKey {
    key: TableKey;
}
export interface DynamoDbDataSourceUpdate {
    expression: string;
    expressionAttributeNames: ExpressionAttributeNames;
    expressionAttributeValues: ExpressionAttributeValues;
}
export interface DynamoDbDataSourceInsert {
    item: Record<string, dynamodb.AttributeValue> | undefined;
}
export interface DynamoDbFieldExpressionAttribute {
    expressionAttributeNames: ExpressionAttributeNames;
    expressionAttributeValues: ExpressionAttributeValues;
}
export interface UpdateInterpreterExpression {
    operator: string;
    expression: string;
}
