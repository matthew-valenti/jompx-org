import { AppSyncDynamoDbDataSourceOptions } from './dynamodb-datasource.construct';
import * as base from '../base/base-datasource';
import * as btype from '../base/base-datasource.types';
/**
 * batch get 100 items.
 * batch write 25 items.
 * datatype char
 * put item all_old
 * updated item all_old, all_new, updated_old, updated_new
 * delete all_old
 * scan + filter + pagination
 * secondary index - is like another table/schema?
 *
 * key condition expression
 * expression attribute values
 * expression attribute names
 * projection expression
 * filter expression
 * example scan query: https://www.screencast.com/t/sMfhInBInGD | https://www.screencast.com/t/hD81ufSV7 https://www.npmjs.com/package/ulid
 *
 * conditionn expressions (modify conditionally)
 * atomic counters
 *
 * avoid scans - use queries. scans are slow and expensive.
 * query = < <= > >= between beginswith
 * scan != exists not exists (string binary number boolean null
 * list set of strings set of binaries set of numbers maps)
 *
 * RCU - 4k per sec
 * WCU - 1k per sec
 * var uuid = require('uuid'); uuid.v1(); uuid.v4();
 * better is ulid that allows query by created date ulid() // 01ARZ3NDEKTSV4RRFFQ69G5FAV
 * Use --max-items=2 instead of --limit=2, max-items will do limit after filtering.
 *
 * DynamoDB is that it won’t let you write a bad query. And by 'bad query', I mean a query that will degrade in performance as it scales.
 * Do not support batch ('findBatch') or transactions at this time. These don't fit a turn-key method well. Use a custom query or mutation instead.
 * scanCursor. Do not support at this time. Typically not used with apps.
 *
 * TODO: We have to get rid of schemas right!? And use schemaField. I'm not aware of anything DynamoDb rath requires a dot notation nested field.
 */
export declare class AppSyncDynamoDbDatasource extends base.AppSyncDatasource {
    options: AppSyncDynamoDbDataSourceOptions;
    constructor(region: string, options: AppSyncDynamoDbDataSourceOptions);
    find(event: btype.AppSyncResolverEvent): Promise<btype.ConnectionOutput & btype.ProblemProperty>;
    private findStatement;
    findOne(event: btype.AppSyncResolverEvent): Promise<btype.ConnectionNodeOutput | btype.ProblemProperty>;
    /**
     * Find one item (by primary key).
     * Filter must include the primary key field and match exactly.
     * @returns - A "set" of attributes for the item with the given primary key.
     * @returns - OR Attributes for the item with the given primary key.
     */
    private findOneStatement;
    insertOne(event: btype.AppSyncResolverEvent): Promise<btype.InsertOneOutput>;
    private insertOneStatement;
    private createManyStatement;
    updateOne(event: btype.AppSyncResolverEvent): Promise<btype.UpdateOutput>;
    /**
     * MongoDB update operators for reference: https://www.mongodb.com/docs/manual/reference/operator/update/
     * e.g. input:
     *   { id: 'abc' } // SET
     *   { $addToSet: { owners: 'admin' } } // ADD
     *   { $unset: { owners: 'admin' } } // REMOVE
     *   { $inc: { int: -1, decimal: 1 } } // SET #int = #int + :intInc, #decimal = #decimal + :decimalInc,
     *
     * @returns
     */
    private updateOneStatement;
    /**
     * MongoDB update operators for reference: https://www.mongodb.com/docs/manual/reference/operator/update/
     * e.g. input:
     *   { id: 'abc' } // SET
     *   { $addToSet: { owners: 'admin' } } // ADD
     *   { $unset: { owners: 'admin' } } // REMOVE
     *   { $inc: { int: -1, decimal: 1 } } // SET #int = #int + :intInc, #decimal = #decimal + :decimalInc,
     *
     * @returns
     */
    deleteOne(event: btype.AppSyncResolverEvent): Promise<btype.DeleteOutput & btype.ProblemProperty>;
    private deleteOneStatement;
    private deleteManyStatement;
    private upsertOneStatement;
    private upsertManyStatement;
    private interpretFilter;
    private interpretFilterKey;
    private interpretAggregation;
    private interpretInsert;
    private interpretUpdate;
    /**
     * Available on a query operation only. Controls the order in which sort key results are returned.
     * @param sorts - Array of sort fields.
     * @returns - true if sort by sort key desc, false otherwise.
     */
    private getScanIndexForward;
    private fieldFromPath;
    /**
     * Given an insert statement field and value, return a DynamoDB expression attribute value. e.g. { 'name': { 'S': 'abc' } }
     * The expressionAttributeValues parameter for an insert statement is different to other CRUD operations because it doesn't use expressionAttributeNames.
     * Scalar and set types are straight forward. However, map types require recursing through child schema objects and nested values.
     * @param schemaFields
     * @param fieldValue
     * @param expressionAttributeValues
     * @returns
     */
    private toExpressionAttributeValue;
    private static dynamoDbFieldType;
    /**
     * Build a list of attributes names from a list of selections.
     * @param selections - Array of selections.
     * @returns - Set of expression attribute names. e.g. { #id: 'id', #name: 'name' }
     */
    private attributeNamesFromSelections;
    /**
     * Get select statements (recursively).
     * @param aliasName
     * @param selections
     * @returns
     */
    private projection;
    handleDatabaseError(error: unknown): void;
}
