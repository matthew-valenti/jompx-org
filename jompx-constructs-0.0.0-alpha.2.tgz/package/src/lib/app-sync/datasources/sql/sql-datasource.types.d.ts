/// <reference types="node" />
import type { Connection as MysqlConnection, Pool as MysqlPool } from 'mysql2/promise';
import type { Database as SqliteDatabase } from 'better-sqlite3';
import type { Client as PostgresClient, Pool as PostgresPool } from 'pg';
export type Connection = MysqlConnection | PostgresClient | SqliteDatabase;
export type Pool = MysqlPool | PostgresPool;
export interface ConnectionSecretValue {
    host: string;
    port: number;
    username: string;
    password: string;
    database: string;
}
export type CreateClientArgs = {
    pool: CreatePoolArgs;
    connection?: CreateConnectionArgs;
} | {
    connection: CreateConnectionArgs;
    pool?: CreatePoolArgs;
};
export type Client = {
    kind: 'sqlite';
    db: Connection;
} | {
    kind: 'sql';
    pool: Pool;
};
import { DatasourceField, SchemaField } from '../base/base-datasource.types';
export declare const engine: readonly ["sqlite_3.x", "mysql_5.7.x", "mysql_8.0.x", "postgres_18.x"];
export type Engine = typeof engine[number];
export interface SqlPreparedStatement {
    sql: string;
    values: unknown[];
}
export interface DbDatasourceField {
    fieldName: string;
    shortFieldName: string;
    fieldTypeName: string;
    schemaFields: SchemaField[];
}
export interface DbDatasourceJoin {
    statements: string[];
    fields: DatasourceField[];
    values: unknown[];
}
export interface DbInterpretedFilter {
    filter: string;
    fields: DatasourceField[];
    values: unknown[];
}
export interface DbInterpretedAggregate {
    aggregation: string;
    fields: DatasourceField[];
    values: unknown[];
}
export interface CreatePoolArgs {
    /**
     * MySQL pool properties.
     */
    mysql?: {
        config: object;
    };
    /**
     * PostgreSQL pool properties.
     */
    postgres?: {
        config: object;
    };
}
export interface CreateConnectionArgs {
    /**
     * SQLite connection properties.
     */
    sqlite?: {
        filename: string | Buffer;
        options: object;
    };
    /**
     * MySQL connection properties.
     */
    mysql?: {
        config: object;
    };
    /**
     * PostgreSQL connection properties.
     */
    postgres?: {
        config: object;
    };
}
