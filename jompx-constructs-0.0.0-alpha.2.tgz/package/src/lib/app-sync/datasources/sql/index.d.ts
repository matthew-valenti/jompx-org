export { AppSyncSqlDataSource } from './sql-datasource.construct';
export * as AppSyncSqlDatasourceType from './sql-datasource.types';
