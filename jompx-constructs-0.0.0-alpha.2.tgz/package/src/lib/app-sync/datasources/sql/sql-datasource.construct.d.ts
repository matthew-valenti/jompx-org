import * as cdk from 'aws-cdk-lib';
import { Construct } from 'constructs';
import * as ltypes from './sql-datasource.types';
export interface AppSyncSqlDataSourceProps {
    datasourceId: string;
    lambdaFunctionProps?: cdk.aws_lambda_nodejs.NodejsFunctionProps;
    layers?: cdk.aws_lambda.LayerVersion[];
    subscriber?: {
        moduleName: string;
        className: string;
    };
    options: AppSyncSqlDataSourceOptions;
}
export interface AppSyncSqlDataSourceOptions {
    engine: ltypes.Engine;
    /**
     * Client-side SQL connection pool settings. Used for safe connection reuse with Lambda + server-side pooling.
     */
    connection?: {
        secretName: string;
        databaseName: string;
    };
    pool?: {
        /**
         * Maximum number of connections maintained by the client pool within a single Lambda execution environment.
         * Default value = 5
         */
        max?: number;
        /**
         * How long an idle connection may remain in the client pool before being closed. Should be lower than the server-side pool idle timeout (e.g., RDS Proxy IdleClientTimeout).
         * Default value = 5 minutes (300,000 ms)
         */
        idleTimeoutMs?: number;
        /**
         * Maximum time to wait when establishing a new database connection before failing.
         * Default value = 10 seconds (10,000 ms)
         */
        connectionTimeoutMs?: number;
    };
    defaultLimit?: number;
    maxLimit?: number;
    log?: {
        sql?: boolean;
        errors?: boolean;
    };
}
export declare class AppSyncSqlDataSource extends Construct {
    lambdaFunction: cdk.aws_lambda.IFunction;
    props: AppSyncSqlDataSourceProps;
    constructor(scope: Construct, id: string, props: AppSyncSqlDataSourceProps);
}
