import { AppSyncSqlDataSourceOptions } from './sql-datasource.construct';
import * as base from '../base/base-datasource';
import * as btype from '../base/base-datasource.types';
import * as type from './sql-datasource.types';
/**
 * TODO:
 * Auth Data where clause.
 * Move connection management to class SqlDriver.
 *
 * Middleware / Events.
 * Namespace j / jompx? You can use the event's namespace to unbind or trigger specific event handlers for an event, not all.
 * beforeEvent, beforeDatasource, beforeQuery, beforeData, afterQuery, beforeData
 * OR
 * beforeAuth(ctx), beforePlan(ctx), afterPlan(ctx), beforeExecute(ctx), afterExecute(ctx), onError(ctx)
 *
 * run or operation or runOperation
 * custom directives (for use with schema)
 * ??? HOW CAN WE GET THESE CUSTOM DIRECTIVES INTO THE EXECUTOR TO GEN THE GRAPHQL SCHEMA. MAYBE WE HAVE A GLOBAL LSIT AND THAT'S IT? BUT WHAT ABOUT CUSTOM OPERATIONS. ???
 * publish to event bridge (before and after)
 * server side validation filter??? how can we have this but save one field at a time? base it on angular i.e. field or table level validation?
 * Phase 2: annotated emit/listeners to create a queue of lambda function calls.
 *
 * Dynamic module loading: https://www.typescriptlang.org/docs/handbook/modules.html
 */
export declare class AppSyncSqlDatasource extends base.AppSyncDatasource {
    options: AppSyncSqlDataSourceOptions;
    module: any;
    client: any;
    constructor(region: string, options: AppSyncSqlDataSourceOptions);
    /**
     * Get a reusable database client (suitable for use with Lambda).
     * @returns
     */
    getClient(): Promise<type.Client>;
    private disposeClient;
    /**
     * Create a client side database connection pool.
     * We implement a three-part connection strategy to make Lambda + SQL reliable at scale.
     * 1. Ise a server-side pool (e.g., RDS Proxy) to protect Aurora from connection storms and manage failover.
     * 2. Use the database driver’s client-side pool inside each Lambda execution environment to safely reuse connections across warm invocations and automatically evict stale sockets.
     * 3. Wrap queries with a single retry on transport-level failure to recover from idle timeouts, freeze/thaw, or transient network drops.
     * Why? This layered approach is necessary because Lambda runtimes are ephemeral and connections are not durable, so stability requires controlled reuse plus safe, bounded recovery.
     */
    createPool(props: type.CreatePoolArgs): Promise<type.Pool>;
    /**
     * Create a database connection.
     *
     * @param config
     * @returns
     */
    createConnection(props: type.CreateConnectionArgs): Promise<type.Connection>;
    /**
     * Run an operation once, then retry once only for transient transport errors.
     * On retry path, reset/recreate the client before re-executing.
     */
    private withTransportRetry;
    /**
     * Return `true` when an error is likely transient at the transport/socket layer and safe to retry once after client re-initialization.
     *
     * Scope:
     * - Generic network failures (reset/refused/timeout/DNS)
     * - Driver/engine connection-loss signals (MySQL/Postgres)
     *
     * Non-goals:
     * - SQL syntax/data/auth/business errors (these are not retryable here)
     */
    private isTransportError;
    /**
     * Run synchronous work in a SQLite transaction.
     * better-sqlite3 transactions must remain synchronous.
     */
    private withTransactionSync;
    /**
     * Run async work in a MySQL transaction.
     * Passes the active connection to prevent usage of a different connection accidentally.
     */
    private withTransaction;
    find(event: btype.AppSyncResolverEvent): Promise<btype.ConnectionOutput & btype.ProblemProperty>;
    private findStatement;
    private countStatement;
    findOne(event: btype.AppSyncResolverEvent): Promise<btype.ConnectionNodeOutput & btype.ProblemProperty>;
    private findOneStatement;
    insertOne(event: btype.AppSyncResolverEvent): Promise<btype.InsertOneOutput & btype.ProblemProperty>;
    private insertOneStatement;
    insertMany(event: btype.AppSyncResolverEvent): Promise<btype.InsertManyOutput & btype.ProblemProperty>;
    private insertManyStatement;
    upsertOne(event: btype.AppSyncResolverEvent): Promise<btype.UpsertOneOutput & btype.ProblemProperty>;
    /**
     * Upsert a row. If unique key does not already exist then insert else update existing row.
     * https://stackoverflow.com/questions/75490808/mysql-upsert-with-insert-only-column-value/75491061#75491061
     * SQL uses unique indexes to trigger an insert or an update. You must index tables correctly for the upsert statement to work correctly.
     * If the table does not have a unique index then there will be no update and only an insert.
     * An upsert statement is made of two parts insert + update. Insert and update fields do not have to be the same.
     * This is important for default values. Insert default values are to be used on insert only while update default values are to be used on update only.
     * Example MySQL syntax (with unique index on movie name):
     *   This statement inserts a row with both createdBy and updatedBy = Jill. Note that there is no createdBy column specified on the update part.
     *     INSERT INTO `movie` (`name`, `createdBy`, `updatedBy`) VALUES ('The Matrix', 'Jill', 'Jill') ON DUPLICATE KEY UPDATE `name` = VALUES(`name`), `updatedBy` = VALUES(`updatedBy`);
     *   This same statement updates the same row. But only updatedBy is updated to Bob. createdBy remains the same.
     *     INSERT INTO `movie` (`name`, `createdBy`, `updatedBy`) VALUES ('The Matrix', 'Bob', 'Bob') ON DUPLICATE KEY UPDATE `name` = VALUES(`name`), `updatedBy` = VALUES(`updatedBy`);
     * @returns
     */
    private upsertOneStatement;
    upsertMany(event: btype.AppSyncResolverEvent): Promise<btype.UpsertManyOutput & btype.ProblemProperty>;
    /**
     * Upsert many rows. If unique key does not already exist then insert else update existing row.
     * https://stackoverflow.com/questions/75490808/mysql-upsert-with-insert-only-column-value/75491061#75491061
     * An upsert statement is made of two parts insert + update. Insert and update fields do not have to be the same.
     * This is important for default values. Insert default values are to be used on insert only while update default values are to be used on update only.
     * Example MySQL syntax (with unique index on movie name):
     *   This statement inserts a row with both createdBy and updatedBy = Jill. Note that there is no createdBy column specified on the update part.
     *     INSERT INTO `movie` (`name`, `createdBy`, `updatedBy`) VALUES ('The Matrix', 'Jill', 'Jill') ON DUPLICATE KEY UPDATE `name` = VALUES(`name`), `updatedBy` = VALUES(`updatedBy`);
     *   This same statement updates the same row. But only updatedBy is updated to Bob. createdBy remains the same.
     *     INSERT INTO `movie` (`name`, `createdBy`, `updatedBy`) VALUES ('The Matrix', 'Bob', 'Bob') ON DUPLICATE KEY UPDATE `name` = VALUES(`name`), `updatedBy` = VALUES(`updatedBy`);
     * @returns
     */
    private upsertManyStatement;
    updateOne(event: btype.AppSyncResolverEvent): Promise<btype.UpdateOutput & btype.ProblemProperty>;
    private updateOneStatement;
    updateMany(event: btype.AppSyncResolverEvent): Promise<btype.UpdateOutput & btype.ProblemProperty>;
    private updateManyStatement;
    deleteOne(event: btype.AppSyncResolverEvent): Promise<btype.DeleteOutput & btype.ProblemProperty>;
    private deleteOneStatement;
    deleteMany(event: btype.AppSyncResolverEvent): Promise<btype.DeleteOutput & btype.ProblemProperty>;
    private deleteManyStatement;
    private interpretFilter;
    private interpretAggregation;
    private fieldFromPath;
    /**
     * Convert a field path to a field name suitable for use in a SQL statement.
     * Example 1 (not nested): ['id'] = movie`.`id`
     * Example 2 (nested): ['mMovieActors', 'mActor', 'id'] = `mActor`.`id`
     * SQL field names are always made up of two parts (table name + field name).
     * For nested paths, the 2nd last fieldname will be the table alias name.
     * @param fieldNamePath - Array of field paths. e.g. ['mMovieActors', 'mActor', 'id']
     * @param tableName - Top level table name to append to top level field names. e.g. movie
     * @returns - Field name for use in a SQL statement. e.g. `mActor`.`id`
     */
    private fieldPathToFieldName;
    private fieldPathToFieldType;
    /**
     * Assumption: The database stores dates and times in UTC.
     * @param rawValues
     * @param typeName
     * @returns
     */
    private formatValueAsDbType;
    private sortStatement;
    private joins;
    /**
     * Get select statements (recursively).
     * @param aliasName
     * @param selections
     * @returns
     */
    private select;
    private backtick;
    private removeBacktick;
    /**
     * Handle database query error.
     * IMPORTANT: For security, do not send database error messages to clients in production environments.
     */
    handleDatabaseError(error: unknown): void;
}
