import * as appsync from 'aws-cdk-lib/aws-appsync';
import * as appsyncUtils from 'awscdk-appsync-utils';
import * as cdk from 'aws-cdk-lib';
export interface DataSource {
    [key: string]: {
        lambdaDataSource: appsync.LambdaDataSource;
        lambdaFunction: cdk.aws_lambda.IFunction;
    };
}
export interface SchemaTypes {
    enumTypes: SchemaEnumTypes;
    inputTypes: SchemaInputTypes;
    interfaceTypes: SchemaInterfaceTypes;
    objectTypes: SchemaObjectTypes;
    unionTypes: SchemaUnionTypes;
}
export type SchemaEnumTypes = {
    [key: string]: appsyncUtils.EnumType;
};
export interface ObjectDefinition {
    [key: string]: appsyncUtils.IField;
}
export type SchemaInputTypes = {
    [key: string]: appsyncUtils.InputType;
};
export type SchemaInterfaceTypes = {
    [key: string]: appsyncUtils.InterfaceType;
};
export type SchemaObjectTypes = {
    [key: string]: appsyncUtils.ObjectType;
};
export type SchemaUnionTypes = {
    [key: string]: appsyncUtils.UnionType;
};
export interface AppSyncOperationFields {
    [key: string]: appsyncUtils.GraphqlType | AppSyncOperationFields;
}
export interface AppSyncIFields {
    [key: string]: AppSyncIFields | appsyncUtils.IField;
}
export interface AppSyncMethodPropsCognito {
    sub: string;
    email: string;
    groups: string[];
    authorization: string;
}
export interface AppSyncMethodProps {
    cognito?: AppSyncMethodPropsCognito;
    event: any;
}
declare const paginationType: string[];
export type PaginationType = typeof paginationType[number];
export {};
