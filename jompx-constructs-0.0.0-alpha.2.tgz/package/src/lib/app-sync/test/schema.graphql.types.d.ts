import { TypedDocumentNode as DocumentNode } from '@graphql-typed-document-node/core';
export type Maybe<T> = T | null;
export type InputMaybe<T> = Maybe<T>;
export type Exact<T extends {
    [key: string]: unknown;
}> = {
    [K in keyof T]: T[K];
};
export type MakeOptional<T, K extends keyof T> = Omit<T, K> & {
    [SubKey in K]?: Maybe<T[SubKey]>;
};
export type MakeMaybe<T, K extends keyof T> = Omit<T, K> & {
    [SubKey in K]: Maybe<T[SubKey]>;
};
export type MakeEmpty<T extends {
    [key: string]: unknown;
}, K extends keyof T> = {
    [_ in K]?: never;
};
export type Incremental<T> = T | {
    [P in keyof T]?: P extends ' $fragmentName' | '__typename' ? T[P] : never;
};
/** All built-in and custom scalars, mapped to their actual values */
export type Scalars = {
    ID: {
        input: string;
        output: string;
    };
    String: {
        input: string;
        output: string;
    };
    Boolean: {
        input: boolean;
        output: boolean;
    };
    Int: {
        input: number;
        output: number;
    };
    Float: {
        input: number;
        output: number;
    };
    AWSDate: {
        input: any;
        output: any;
    };
    AWSDateTime: {
        input: any;
        output: any;
    };
    AWSEmail: {
        input: any;
        output: any;
    };
    AWSIPAddress: {
        input: any;
        output: any;
    };
    AWSJSON: {
        input: any;
        output: any;
    };
    AWSPhone: {
        input: any;
        output: any;
    };
    AWSTime: {
        input: any;
        output: any;
    };
    AWSTimestamp: {
        input: any;
        output: any;
    };
    AWSURL: {
        input: any;
        output: any;
    };
};
export declare enum AuthAction {
    Create = "create",
    Delete = "delete",
    Read = "read",
    Update = "update"
}
export declare enum AuthProvider {
    ApiKey = "apiKey",
    Iam = "iam",
    Oidc = "oidc",
    UserPool = "userPool"
}
export type AuthRule = {
    action?: InputMaybe<Scalars['String']['input']>;
    conditions?: InputMaybe<Array<InputMaybe<Scalars['AWSJSON']['input']>>>;
    provider: AuthProvider;
};
export type DNode = {
    createdAt?: Maybe<Scalars['AWSDateTime']['output']>;
    createdBy?: Maybe<Scalars['AWSDateTime']['output']>;
    id?: Maybe<Scalars['ID']['output']>;
    updatedAt?: Maybe<Scalars['AWSDateTime']['output']>;
    updatedBy?: Maybe<Scalars['AWSDateTime']['output']>;
};
export type DeleteOneOutput = {
    __typename?: 'DeleteOneOutput';
    deletedCount?: Maybe<Scalars['Int']['output']>;
};
export type DeleteOneProps = {
    returnConsumedCapacity?: InputMaybe<Scalars['String']['input']>;
    returnItemCollectionMetrics?: InputMaybe<Scalars['String']['input']>;
    returnValues?: InputMaybe<Scalars['String']['input']>;
};
export type DynamoDbActor = DNode & {
    __typename?: 'DynamoDbActor';
    createdAt?: Maybe<Scalars['AWSDateTime']['output']>;
    createdBy?: Maybe<Scalars['AWSDateTime']['output']>;
    dynamoDbMovieActors?: Maybe<Array<Maybe<DynamoDbMovieActor>>>;
    id?: Maybe<Scalars['ID']['output']>;
    name?: Maybe<Scalars['String']['output']>;
    updatedAt?: Maybe<Scalars['AWSDateTime']['output']>;
    updatedBy?: Maybe<Scalars['AWSDateTime']['output']>;
};
export type DynamoDbActorDynamoDbMovieActorsArgs = {
    filter?: InputMaybe<Scalars['AWSJSON']['input']>;
    props?: InputMaybe<FindProps>;
    sort?: InputMaybe<Scalars['AWSJSON']['input']>;
};
export type DynamoDbActorConnection = {
    __typename?: 'DynamoDbActorConnection';
    edges?: Maybe<Array<Maybe<DynamoDbActorEdge>>>;
    pageInfo: PageInfoOffset;
    totalCount?: Maybe<Scalars['Int']['output']>;
};
export type DynamoDbActorEdge = {
    __typename?: 'DynamoDbActorEdge';
    node?: Maybe<DynamoDbActor>;
};
export type DynamoDbActorInput = {
    createdAt?: InputMaybe<Scalars['AWSDateTime']['input']>;
    createdBy?: InputMaybe<Scalars['AWSDateTime']['input']>;
    id?: InputMaybe<Scalars['ID']['input']>;
    name?: InputMaybe<Scalars['String']['input']>;
    updatedAt?: InputMaybe<Scalars['AWSDateTime']['input']>;
    updatedBy?: InputMaybe<Scalars['AWSDateTime']['input']>;
};
export type DynamoDbMovie = DNode & {
    __typename?: 'DynamoDbMovie';
    attributes?: Maybe<DynamoDbMovieAttributes>;
    boolean?: Maybe<Scalars['Boolean']['output']>;
    createdAt?: Maybe<Scalars['AWSDateTime']['output']>;
    createdBy?: Maybe<Scalars['AWSDateTime']['output']>;
    date?: Maybe<Scalars['AWSDate']['output']>;
    dateTime?: Maybe<Scalars['AWSDateTime']['output']>;
    decimal?: Maybe<Scalars['Float']['output']>;
    dynamoDbMovieActors: Array<Maybe<DynamoDbMovieActor>>;
    email?: Maybe<Scalars['AWSEmail']['output']>;
    files?: Maybe<Array<Maybe<MySqlFile>>>;
    float?: Maybe<Scalars['Float']['output']>;
    groups?: Maybe<Array<Maybe<Scalars['String']['output']>>>;
    id?: Maybe<Scalars['ID']['output']>;
    int?: Maybe<Scalars['Int']['output']>;
    ipAddress?: Maybe<Scalars['AWSIPAddress']['output']>;
    list?: Maybe<Array<Maybe<Scalars['String']['output']>>>;
    name?: Maybe<Scalars['String']['output']>;
    owners?: Maybe<Array<Maybe<Scalars['String']['output']>>>;
    phone?: Maybe<Scalars['AWSPhone']['output']>;
    poster?: Maybe<MySqlFile>;
    sourceField?: Maybe<Scalars['String']['output']>;
    time?: Maybe<Scalars['AWSTime']['output']>;
    timestamp?: Maybe<Scalars['AWSTimestamp']['output']>;
    updatedAt?: Maybe<Scalars['AWSDateTime']['output']>;
    updatedBy?: Maybe<Scalars['AWSDateTime']['output']>;
    url?: Maybe<Scalars['AWSURL']['output']>;
};
export type DynamoDbMovieDynamoDbMovieActorsArgs = {
    filter?: InputMaybe<Scalars['AWSJSON']['input']>;
    props?: InputMaybe<FindProps>;
    sort?: InputMaybe<Scalars['AWSJSON']['input']>;
};
export type DynamoDbMovieFilesArgs = {
    filter?: InputMaybe<Scalars['AWSJSON']['input']>;
    props?: InputMaybe<FindProps>;
    sort?: InputMaybe<Scalars['AWSJSON']['input']>;
};
export type DynamoDbMovieActor = DNode & {
    __typename?: 'DynamoDbMovieActor';
    actorId?: Maybe<Scalars['ID']['output']>;
    createdAt?: Maybe<Scalars['AWSDateTime']['output']>;
    createdBy?: Maybe<Scalars['AWSDateTime']['output']>;
    dynamoDbActor?: Maybe<DynamoDbActor>;
    dynamoDbMovie?: Maybe<DynamoDbMovie>;
    id?: Maybe<Scalars['ID']['output']>;
    movieId?: Maybe<Scalars['ID']['output']>;
    updatedAt?: Maybe<Scalars['AWSDateTime']['output']>;
    updatedBy?: Maybe<Scalars['AWSDateTime']['output']>;
};
export type DynamoDbMovieActorConnection = {
    __typename?: 'DynamoDbMovieActorConnection';
    edges?: Maybe<Array<Maybe<DynamoDbMovieActorEdge>>>;
    pageInfo: PageInfoOffset;
    totalCount?: Maybe<Scalars['Int']['output']>;
};
export type DynamoDbMovieActorEdge = {
    __typename?: 'DynamoDbMovieActorEdge';
    node?: Maybe<DynamoDbMovieActor>;
};
export type DynamoDbMovieActorInput = {
    actorId?: InputMaybe<Scalars['ID']['input']>;
    createdAt?: InputMaybe<Scalars['AWSDateTime']['input']>;
    createdBy?: InputMaybe<Scalars['AWSDateTime']['input']>;
    id?: InputMaybe<Scalars['ID']['input']>;
    movieId?: InputMaybe<Scalars['ID']['input']>;
    updatedAt?: InputMaybe<Scalars['AWSDateTime']['input']>;
    updatedBy?: InputMaybe<Scalars['AWSDateTime']['input']>;
};
export type DynamoDbMovieAnalytics = DNode & {
    __typename?: 'DynamoDbMovieAnalytics';
    action?: Maybe<Scalars['String']['output']>;
    createdAt?: Maybe<Scalars['AWSDateTime']['output']>;
    createdBy?: Maybe<Scalars['AWSDateTime']['output']>;
    id?: Maybe<Scalars['ID']['output']>;
    movieId: Scalars['ID']['output'];
    timeStamp: Scalars['AWSTimestamp']['output'];
    updatedAt?: Maybe<Scalars['AWSDateTime']['output']>;
    updatedBy?: Maybe<Scalars['AWSDateTime']['output']>;
};
export type DynamoDbMovieAnalyticsConnection = {
    __typename?: 'DynamoDbMovieAnalyticsConnection';
    edges?: Maybe<Array<Maybe<DynamoDbMovieAnalyticsEdge>>>;
    pageInfo: PageInfoOffset;
    totalCount?: Maybe<Scalars['Int']['output']>;
};
export type DynamoDbMovieAnalyticsEdge = {
    __typename?: 'DynamoDbMovieAnalyticsEdge';
    node?: Maybe<DynamoDbMovieAnalytics>;
};
export type DynamoDbMovieAttributes = {
    __typename?: 'DynamoDbMovieAttributes';
    attribute1?: Maybe<Scalars['String']['output']>;
    attribute2?: Maybe<Scalars['String']['output']>;
    attribute3?: Maybe<Scalars['Int']['output']>;
    attribute4?: Maybe<Array<Maybe<Scalars['String']['output']>>>;
    attribute5?: Maybe<Array<Maybe<Scalars['String']['output']>>>;
};
export type DynamoDbMovieAttributesInput = {
    attribute1?: InputMaybe<Scalars['String']['input']>;
    attribute2?: InputMaybe<Scalars['String']['input']>;
    attribute3?: InputMaybe<Scalars['Int']['input']>;
    attribute4?: InputMaybe<Array<InputMaybe<Scalars['String']['input']>>>;
    attribute5?: InputMaybe<Array<InputMaybe<Scalars['String']['input']>>>;
};
export type DynamoDbMovieConnection = {
    __typename?: 'DynamoDbMovieConnection';
    edges?: Maybe<Array<Maybe<DynamoDbMovieEdge>>>;
    pageInfo: PageInfoOffset;
    totalCount?: Maybe<Scalars['Int']['output']>;
};
export type DynamoDbMovieEdge = {
    __typename?: 'DynamoDbMovieEdge';
    node?: Maybe<DynamoDbMovie>;
};
export type DynamoDbMovieIndex = DNode & {
    __typename?: 'DynamoDbMovieIndex';
    createdAt?: Maybe<Scalars['AWSDateTime']['output']>;
    createdBy?: Maybe<Scalars['AWSDateTime']['output']>;
    id?: Maybe<Scalars['ID']['output']>;
    name: Scalars['String']['output'];
    updatedAt?: Maybe<Scalars['AWSDateTime']['output']>;
    updatedBy?: Maybe<Scalars['AWSDateTime']['output']>;
};
export type DynamoDbMovieIndexConnection = {
    __typename?: 'DynamoDbMovieIndexConnection';
    edges?: Maybe<Array<Maybe<DynamoDbMovieIndexEdge>>>;
    pageInfo: PageInfoOffset;
    totalCount?: Maybe<Scalars['Int']['output']>;
};
export type DynamoDbMovieIndexEdge = {
    __typename?: 'DynamoDbMovieIndexEdge';
    node?: Maybe<DynamoDbMovieIndex>;
};
export type DynamoDbMovieInput = {
    attributes?: InputMaybe<DynamoDbMovieAttributesInput>;
    boolean?: InputMaybe<Scalars['Boolean']['input']>;
    createdAt?: InputMaybe<Scalars['AWSDateTime']['input']>;
    createdBy?: InputMaybe<Scalars['AWSDateTime']['input']>;
    date?: InputMaybe<Scalars['AWSDate']['input']>;
    dateTime?: InputMaybe<Scalars['AWSDateTime']['input']>;
    decimal?: InputMaybe<Scalars['Float']['input']>;
    email?: InputMaybe<Scalars['AWSEmail']['input']>;
    float?: InputMaybe<Scalars['Float']['input']>;
    groups?: InputMaybe<Array<InputMaybe<Scalars['String']['input']>>>;
    id?: InputMaybe<Scalars['ID']['input']>;
    int?: InputMaybe<Scalars['Int']['input']>;
    ipAddress?: InputMaybe<Scalars['AWSIPAddress']['input']>;
    list?: InputMaybe<Array<InputMaybe<Scalars['String']['input']>>>;
    name?: InputMaybe<Scalars['String']['input']>;
    owners?: InputMaybe<Array<InputMaybe<Scalars['String']['input']>>>;
    phone?: InputMaybe<Scalars['AWSPhone']['input']>;
    sourceField?: InputMaybe<Scalars['String']['input']>;
    time?: InputMaybe<Scalars['AWSTime']['input']>;
    timestamp?: InputMaybe<Scalars['AWSTimestamp']['input']>;
    updatedAt?: InputMaybe<Scalars['AWSDateTime']['input']>;
    updatedBy?: InputMaybe<Scalars['AWSDateTime']['input']>;
    url?: InputMaybe<Scalars['AWSURL']['input']>;
};
export type FindOneProps = {
    consistentRead?: InputMaybe<Scalars['Boolean']['input']>;
    returnConsumedCapacity?: InputMaybe<Scalars['String']['input']>;
};
export type FindProps = {
    consistentRead?: InputMaybe<Scalars['Boolean']['input']>;
    returnConsumedCapacity?: InputMaybe<Scalars['String']['input']>;
};
export type InsertManyOutput = {
    __typename?: 'InsertManyOutput';
    insertedIds?: Maybe<Scalars['ID']['output']>;
};
export type InsertManyProps = {
    returnConsumedCapacity?: InputMaybe<Scalars['String']['input']>;
    returnValues?: InputMaybe<Scalars['String']['input']>;
};
export type InsertOneOutput = {
    __typename?: 'InsertOneOutput';
    insertedId?: Maybe<Scalars['ID']['output']>;
};
export type InsertOneProps = {
    returnConsumedCapacity?: InputMaybe<Scalars['String']['input']>;
    returnValues?: InputMaybe<Scalars['String']['input']>;
};
export type Mutation = {
    __typename?: 'Mutation';
    dynamoDbActorDeleteOne?: Maybe<DeleteOneOutput>;
    dynamoDbActorInsertMany?: Maybe<InsertManyOutput>;
    dynamoDbActorInsertOne?: Maybe<InsertOneOutput>;
    dynamoDbActorUpdateMany?: Maybe<UpdateManyOutput>;
    dynamoDbActorUpdateOne?: Maybe<UpdateOneOutput>;
    dynamoDbActorUpsertOne?: Maybe<UpsertOneOutput>;
    dynamoDbMovieActorDeleteOne?: Maybe<DeleteOneOutput>;
    dynamoDbMovieActorInsertMany?: Maybe<InsertManyOutput>;
    dynamoDbMovieActorInsertOne?: Maybe<InsertOneOutput>;
    dynamoDbMovieActorUpdateMany?: Maybe<UpdateManyOutput>;
    dynamoDbMovieActorUpdateOne?: Maybe<UpdateOneOutput>;
    dynamoDbMovieActorUpsertOne?: Maybe<UpsertOneOutput>;
    dynamoDbMovieDeleteOne?: Maybe<DeleteOneOutput>;
    dynamoDbMovieInsertMany?: Maybe<InsertManyOutput>;
    dynamoDbMovieInsertOne?: Maybe<InsertOneOutput>;
    dynamoDbMovieUpdateMany?: Maybe<UpdateManyOutput>;
    dynamoDbMovieUpdateOne?: Maybe<UpdateOneOutput>;
    dynamoDbMovieUpsertOne?: Maybe<UpsertOneOutput>;
    mySqlActorDeleteOne?: Maybe<DeleteOneOutput>;
    mySqlActorInsertMany?: Maybe<InsertManyOutput>;
    mySqlActorInsertOne?: Maybe<InsertOneOutput>;
    mySqlActorUpdateMany?: Maybe<UpdateManyOutput>;
    mySqlActorUpdateOne?: Maybe<UpdateOneOutput>;
    mySqlActorUpsertOne?: Maybe<UpsertOneOutput>;
    mySqlFileDeleteOne?: Maybe<DeleteOneOutput>;
    mySqlFileInsertMany?: Maybe<InsertManyOutput>;
    mySqlFileInsertOne?: Maybe<InsertOneOutput>;
    mySqlFileUpdateMany?: Maybe<UpdateManyOutput>;
    mySqlFileUpdateOne?: Maybe<UpdateOneOutput>;
    mySqlFileUpsertOne?: Maybe<UpsertOneOutput>;
    mySqlMovieActorDeleteOne?: Maybe<DeleteOneOutput>;
    mySqlMovieActorInsertMany?: Maybe<InsertManyOutput>;
    mySqlMovieActorInsertOne?: Maybe<InsertOneOutput>;
    mySqlMovieActorUpdateMany?: Maybe<UpdateManyOutput>;
    mySqlMovieActorUpdateOne?: Maybe<UpdateOneOutput>;
    mySqlMovieActorUpsertOne?: Maybe<UpsertOneOutput>;
    mySqlMovieDeleteOne?: Maybe<DeleteOneOutput>;
    mySqlMovieInsertMany?: Maybe<InsertManyOutput>;
    mySqlMovieInsertOne?: Maybe<InsertOneOutput>;
    mySqlMovieUpdateMany?: Maybe<UpdateManyOutput>;
    mySqlMovieUpdateOne?: Maybe<UpdateOneOutput>;
    mySqlMovieUpsertOne?: Maybe<UpsertOneOutput>;
};
export type MutationDynamoDbActorDeleteOneArgs = {
    filter?: InputMaybe<Scalars['AWSJSON']['input']>;
    props?: InputMaybe<DeleteOneProps>;
};
export type MutationDynamoDbActorInsertManyArgs = {
    insert: Array<DynamoDbActorInput>;
    props?: InputMaybe<InsertManyProps>;
};
export type MutationDynamoDbActorInsertOneArgs = {
    insert: DynamoDbActorInput;
    props?: InputMaybe<InsertOneProps>;
};
export type MutationDynamoDbActorUpdateManyArgs = {
    filter?: InputMaybe<Scalars['AWSJSON']['input']>;
    props?: InputMaybe<UpdateManyProps>;
    update: Scalars['AWSJSON']['input'];
};
export type MutationDynamoDbActorUpdateOneArgs = {
    filter?: InputMaybe<Scalars['AWSJSON']['input']>;
    props?: InputMaybe<UpdateOneProps>;
    update: Scalars['AWSJSON']['input'];
};
export type MutationDynamoDbActorUpsertOneArgs = {
    filter?: InputMaybe<Scalars['AWSJSON']['input']>;
    props?: InputMaybe<UpsertOneProps>;
    upsert: Scalars['AWSJSON']['input'];
};
export type MutationDynamoDbMovieActorDeleteOneArgs = {
    filter?: InputMaybe<Scalars['AWSJSON']['input']>;
    props?: InputMaybe<DeleteOneProps>;
};
export type MutationDynamoDbMovieActorInsertManyArgs = {
    insert: Array<DynamoDbMovieActorInput>;
    props?: InputMaybe<InsertManyProps>;
};
export type MutationDynamoDbMovieActorInsertOneArgs = {
    insert: DynamoDbMovieActorInput;
    props?: InputMaybe<InsertOneProps>;
};
export type MutationDynamoDbMovieActorUpdateManyArgs = {
    filter?: InputMaybe<Scalars['AWSJSON']['input']>;
    props?: InputMaybe<UpdateManyProps>;
    update: Scalars['AWSJSON']['input'];
};
export type MutationDynamoDbMovieActorUpdateOneArgs = {
    filter?: InputMaybe<Scalars['AWSJSON']['input']>;
    props?: InputMaybe<UpdateOneProps>;
    update: Scalars['AWSJSON']['input'];
};
export type MutationDynamoDbMovieActorUpsertOneArgs = {
    filter?: InputMaybe<Scalars['AWSJSON']['input']>;
    props?: InputMaybe<UpsertOneProps>;
    upsert: Scalars['AWSJSON']['input'];
};
export type MutationDynamoDbMovieDeleteOneArgs = {
    filter?: InputMaybe<Scalars['AWSJSON']['input']>;
    props?: InputMaybe<DeleteOneProps>;
};
export type MutationDynamoDbMovieInsertManyArgs = {
    insert: Array<DynamoDbMovieInput>;
    props?: InputMaybe<InsertManyProps>;
};
export type MutationDynamoDbMovieInsertOneArgs = {
    insert: DynamoDbMovieInput;
    props?: InputMaybe<InsertOneProps>;
};
export type MutationDynamoDbMovieUpdateManyArgs = {
    filter?: InputMaybe<Scalars['AWSJSON']['input']>;
    props?: InputMaybe<UpdateManyProps>;
    update: Scalars['AWSJSON']['input'];
};
export type MutationDynamoDbMovieUpdateOneArgs = {
    filter?: InputMaybe<Scalars['AWSJSON']['input']>;
    props?: InputMaybe<UpdateOneProps>;
    update: Scalars['AWSJSON']['input'];
};
export type MutationDynamoDbMovieUpsertOneArgs = {
    filter?: InputMaybe<Scalars['AWSJSON']['input']>;
    props?: InputMaybe<UpsertOneProps>;
    upsert: Scalars['AWSJSON']['input'];
};
export type MutationMySqlActorDeleteOneArgs = {
    filter?: InputMaybe<Scalars['AWSJSON']['input']>;
    props?: InputMaybe<DeleteOneProps>;
};
export type MutationMySqlActorInsertManyArgs = {
    insert: Array<MySqlActorInput>;
    props?: InputMaybe<InsertManyProps>;
};
export type MutationMySqlActorInsertOneArgs = {
    insert: MySqlActorInput;
    props?: InputMaybe<InsertOneProps>;
};
export type MutationMySqlActorUpdateManyArgs = {
    filter?: InputMaybe<Scalars['AWSJSON']['input']>;
    props?: InputMaybe<UpdateManyProps>;
    update: Scalars['AWSJSON']['input'];
};
export type MutationMySqlActorUpdateOneArgs = {
    filter?: InputMaybe<Scalars['AWSJSON']['input']>;
    props?: InputMaybe<UpdateOneProps>;
    update: Scalars['AWSJSON']['input'];
};
export type MutationMySqlActorUpsertOneArgs = {
    filter?: InputMaybe<Scalars['AWSJSON']['input']>;
    props?: InputMaybe<UpsertOneProps>;
    upsert: Scalars['AWSJSON']['input'];
};
export type MutationMySqlFileDeleteOneArgs = {
    filter?: InputMaybe<Scalars['AWSJSON']['input']>;
    props?: InputMaybe<DeleteOneProps>;
};
export type MutationMySqlFileInsertManyArgs = {
    insert: Array<MySqlFileInput>;
    props?: InputMaybe<InsertManyProps>;
};
export type MutationMySqlFileInsertOneArgs = {
    insert: MySqlFileInput;
    props?: InputMaybe<InsertOneProps>;
};
export type MutationMySqlFileUpdateManyArgs = {
    filter?: InputMaybe<Scalars['AWSJSON']['input']>;
    props?: InputMaybe<UpdateManyProps>;
    update: Scalars['AWSJSON']['input'];
};
export type MutationMySqlFileUpdateOneArgs = {
    filter?: InputMaybe<Scalars['AWSJSON']['input']>;
    props?: InputMaybe<UpdateOneProps>;
    update: Scalars['AWSJSON']['input'];
};
export type MutationMySqlFileUpsertOneArgs = {
    filter?: InputMaybe<Scalars['AWSJSON']['input']>;
    props?: InputMaybe<UpsertOneProps>;
    upsert: Scalars['AWSJSON']['input'];
};
export type MutationMySqlMovieActorDeleteOneArgs = {
    filter?: InputMaybe<Scalars['AWSJSON']['input']>;
    props?: InputMaybe<DeleteOneProps>;
};
export type MutationMySqlMovieActorInsertManyArgs = {
    insert: Array<MySqlMovieActorInput>;
    props?: InputMaybe<InsertManyProps>;
};
export type MutationMySqlMovieActorInsertOneArgs = {
    insert: MySqlMovieActorInput;
    props?: InputMaybe<InsertOneProps>;
};
export type MutationMySqlMovieActorUpdateManyArgs = {
    filter?: InputMaybe<Scalars['AWSJSON']['input']>;
    props?: InputMaybe<UpdateManyProps>;
    update: Scalars['AWSJSON']['input'];
};
export type MutationMySqlMovieActorUpdateOneArgs = {
    filter?: InputMaybe<Scalars['AWSJSON']['input']>;
    props?: InputMaybe<UpdateOneProps>;
    update: Scalars['AWSJSON']['input'];
};
export type MutationMySqlMovieActorUpsertOneArgs = {
    filter?: InputMaybe<Scalars['AWSJSON']['input']>;
    props?: InputMaybe<UpsertOneProps>;
    upsert: Scalars['AWSJSON']['input'];
};
export type MutationMySqlMovieDeleteOneArgs = {
    filter?: InputMaybe<Scalars['AWSJSON']['input']>;
    props?: InputMaybe<DeleteOneProps>;
};
export type MutationMySqlMovieInsertManyArgs = {
    insert: Array<MySqlMovieInput>;
    props?: InputMaybe<InsertManyProps>;
};
export type MutationMySqlMovieInsertOneArgs = {
    insert: MySqlMovieInput;
    props?: InputMaybe<InsertOneProps>;
};
export type MutationMySqlMovieUpdateManyArgs = {
    filter?: InputMaybe<Scalars['AWSJSON']['input']>;
    props?: InputMaybe<UpdateManyProps>;
    update: Scalars['AWSJSON']['input'];
};
export type MutationMySqlMovieUpdateOneArgs = {
    filter?: InputMaybe<Scalars['AWSJSON']['input']>;
    props?: InputMaybe<UpdateOneProps>;
    update: Scalars['AWSJSON']['input'];
};
export type MutationMySqlMovieUpsertOneArgs = {
    filter?: InputMaybe<Scalars['AWSJSON']['input']>;
    props?: InputMaybe<UpsertOneProps>;
    upsert: Scalars['AWSJSON']['input'];
};
export type MySqlActor = MySqlNode & {
    __typename?: 'MySqlActor';
    createdAt: Scalars['AWSDateTime']['output'];
    createdBy: Scalars['AWSDateTime']['output'];
    id: Scalars['ID']['output'];
    mySqlMovieActors?: Maybe<Array<Maybe<MySqlMovieActor>>>;
    name?: Maybe<Scalars['String']['output']>;
    updatedAt: Scalars['AWSDateTime']['output'];
    updatedBy: Scalars['AWSDateTime']['output'];
};
export type MySqlActorMySqlMovieActorsArgs = {
    filter?: InputMaybe<Scalars['AWSJSON']['input']>;
    limit?: InputMaybe<Scalars['Int']['input']>;
    props?: InputMaybe<FindProps>;
    skip?: InputMaybe<Scalars['Int']['input']>;
    sort?: InputMaybe<Scalars['AWSJSON']['input']>;
};
export type MySqlActorConnection = {
    __typename?: 'MySqlActorConnection';
    edges?: Maybe<Array<Maybe<MySqlActorEdge>>>;
    pageInfo: PageInfoOffset;
    totalCount?: Maybe<Scalars['Int']['output']>;
};
export type MySqlActorEdge = {
    __typename?: 'MySqlActorEdge';
    node?: Maybe<MySqlActor>;
};
export type MySqlActorInput = {
    name?: InputMaybe<Scalars['String']['input']>;
};
export type MySqlFile = MySqlNode & {
    __typename?: 'MySqlFile';
    createdAt: Scalars['AWSDateTime']['output'];
    createdBy: Scalars['AWSDateTime']['output'];
    entityId?: Maybe<Scalars['String']['output']>;
    entityKey?: Maybe<Scalars['String']['output']>;
    entityName?: Maybe<Scalars['String']['output']>;
    filename?: Maybe<Scalars['String']['output']>;
    id: Scalars['ID']['output'];
    updatedAt: Scalars['AWSDateTime']['output'];
    updatedBy: Scalars['AWSDateTime']['output'];
};
export type MySqlFileConnection = {
    __typename?: 'MySqlFileConnection';
    edges?: Maybe<Array<Maybe<MySqlFileEdge>>>;
    pageInfo: PageInfoOffset;
    totalCount?: Maybe<Scalars['Int']['output']>;
};
export type MySqlFileEdge = {
    __typename?: 'MySqlFileEdge';
    node?: Maybe<MySqlFile>;
};
export type MySqlFileInput = {
    entityId?: InputMaybe<Scalars['String']['input']>;
    entityKey?: InputMaybe<Scalars['String']['input']>;
    entityName?: InputMaybe<Scalars['String']['input']>;
    filename?: InputMaybe<Scalars['String']['input']>;
};
export type MySqlMovie = MySqlNode & {
    __typename?: 'MySqlMovie';
    boolean?: Maybe<Scalars['Boolean']['output']>;
    clicks?: Maybe<Array<Maybe<DynamoDbMovieAnalytics>>>;
    createdAt: Scalars['AWSDateTime']['output'];
    createdBy: Scalars['AWSDateTime']['output'];
    date?: Maybe<Scalars['AWSDate']['output']>;
    dateTime?: Maybe<Scalars['AWSDateTime']['output']>;
    email?: Maybe<Scalars['AWSEmail']['output']>;
    float?: Maybe<Scalars['Float']['output']>;
    id: Scalars['ID']['output'];
    int?: Maybe<Scalars['Int']['output']>;
    ipAddress?: Maybe<Scalars['AWSIPAddress']['output']>;
    json?: Maybe<Scalars['AWSJSON']['output']>;
    mySqlMovieActors: Array<Maybe<MySqlMovieActor>>;
    name?: Maybe<Scalars['String']['output']>;
    owners?: Maybe<Array<Maybe<Scalars['String']['output']>>>;
    phone?: Maybe<Scalars['AWSPhone']['output']>;
    poster?: Maybe<MySqlFile>;
    sourceField?: Maybe<Scalars['String']['output']>;
    time?: Maybe<Scalars['AWSTime']['output']>;
    timestamp?: Maybe<Scalars['AWSTimestamp']['output']>;
    updatedAt: Scalars['AWSDateTime']['output'];
    updatedBy: Scalars['AWSDateTime']['output'];
    url?: Maybe<Scalars['AWSURL']['output']>;
};
export type MySqlMovieClicksArgs = {
    filter?: InputMaybe<Scalars['AWSJSON']['input']>;
    limit?: InputMaybe<Scalars['Int']['input']>;
    props?: InputMaybe<FindProps>;
    skip?: InputMaybe<Scalars['Int']['input']>;
    sort?: InputMaybe<Scalars['AWSJSON']['input']>;
};
export type MySqlMovieMySqlMovieActorsArgs = {
    filter?: InputMaybe<Scalars['AWSJSON']['input']>;
    limit?: InputMaybe<Scalars['Int']['input']>;
    props?: InputMaybe<FindProps>;
    skip?: InputMaybe<Scalars['Int']['input']>;
    sort?: InputMaybe<Scalars['AWSJSON']['input']>;
};
export type MySqlMovieActor = MySqlNode & {
    __typename?: 'MySqlMovieActor';
    actorId?: Maybe<Scalars['ID']['output']>;
    createdAt: Scalars['AWSDateTime']['output'];
    createdBy: Scalars['AWSDateTime']['output'];
    id: Scalars['ID']['output'];
    movieId?: Maybe<Scalars['ID']['output']>;
    mySqlActor?: Maybe<MySqlActor>;
    mySqlMovie?: Maybe<MySqlMovie>;
    updatedAt: Scalars['AWSDateTime']['output'];
    updatedBy: Scalars['AWSDateTime']['output'];
};
export type MySqlMovieActorConnection = {
    __typename?: 'MySqlMovieActorConnection';
    edges?: Maybe<Array<Maybe<MySqlMovieActorEdge>>>;
    pageInfo: PageInfoOffset;
    totalCount?: Maybe<Scalars['Int']['output']>;
};
export type MySqlMovieActorEdge = {
    __typename?: 'MySqlMovieActorEdge';
    node?: Maybe<MySqlMovieActor>;
};
export type MySqlMovieActorInput = {
    actorId?: InputMaybe<Scalars['ID']['input']>;
    movieId?: InputMaybe<Scalars['ID']['input']>;
};
export type MySqlMovieConnection = {
    __typename?: 'MySqlMovieConnection';
    edges?: Maybe<Array<Maybe<MySqlMovieEdge>>>;
    pageInfo: PageInfoOffset;
    totalCount?: Maybe<Scalars['Int']['output']>;
};
export type MySqlMovieEdge = {
    __typename?: 'MySqlMovieEdge';
    node?: Maybe<MySqlMovie>;
};
export type MySqlMovieInput = {
    boolean?: InputMaybe<Scalars['Boolean']['input']>;
    date?: InputMaybe<Scalars['AWSDate']['input']>;
    dateTime?: InputMaybe<Scalars['AWSDateTime']['input']>;
    email?: InputMaybe<Scalars['AWSEmail']['input']>;
    float?: InputMaybe<Scalars['Float']['input']>;
    int?: InputMaybe<Scalars['Int']['input']>;
    ipAddress?: InputMaybe<Scalars['AWSIPAddress']['input']>;
    json?: InputMaybe<Scalars['AWSJSON']['input']>;
    name?: InputMaybe<Scalars['String']['input']>;
    owners?: InputMaybe<Array<InputMaybe<Scalars['String']['input']>>>;
    phone?: InputMaybe<Scalars['AWSPhone']['input']>;
    sourceField?: InputMaybe<Scalars['String']['input']>;
    time?: InputMaybe<Scalars['AWSTime']['input']>;
    timestamp?: InputMaybe<Scalars['AWSTimestamp']['input']>;
    url?: InputMaybe<Scalars['AWSURL']['input']>;
};
export type MySqlNode = {
    createdAt: Scalars['AWSDateTime']['output'];
    createdBy: Scalars['AWSDateTime']['output'];
    id: Scalars['ID']['output'];
    updatedAt: Scalars['AWSDateTime']['output'];
    updatedBy: Scalars['AWSDateTime']['output'];
};
export type PageInfoCursor = {
    __typename?: 'PageInfoCursor';
    endCursor: Scalars['String']['output'];
    hasNextPage: Scalars['Boolean']['output'];
    hasPreviousPage: Scalars['Boolean']['output'];
    startCursor: Scalars['String']['output'];
};
export type PageInfoOffset = {
    __typename?: 'PageInfoOffset';
    limit: Scalars['Int']['output'];
    skip: Scalars['Int']['output'];
};
export type Problem = ProblemDetail;
export type ProblemDetail = {
    __typename?: 'ProblemDetail';
    detail?: Maybe<Scalars['String']['output']>;
    instance?: Maybe<Scalars['String']['output']>;
    status?: Maybe<Scalars['Int']['output']>;
    title?: Maybe<Scalars['String']['output']>;
    type?: Maybe<Scalars['String']['output']>;
};
export type Query = {
    __typename?: 'Query';
    dynamoDbActorFind?: Maybe<DynamoDbActorConnection>;
    dynamoDbActorFindOne?: Maybe<DynamoDbActor>;
    dynamoDbMovieActorFind?: Maybe<DynamoDbMovieActorConnection>;
    dynamoDbMovieActorFindOne?: Maybe<DynamoDbMovieActor>;
    dynamoDbMovieAnalyticsFind?: Maybe<DynamoDbMovieAnalyticsConnection>;
    dynamoDbMovieAnalyticsFindOne?: Maybe<DynamoDbMovieAnalytics>;
    dynamoDbMovieFind?: Maybe<DynamoDbMovieConnection>;
    dynamoDbMovieFindOne?: Maybe<DynamoDbMovie>;
    dynamoDbMovieIndexFind?: Maybe<DynamoDbMovieIndexConnection>;
    mySqlActorFind?: Maybe<MySqlActorConnection>;
    mySqlActorFindOne?: Maybe<MySqlActor>;
    mySqlFileFind?: Maybe<MySqlFileConnection>;
    mySqlFileFindOne?: Maybe<MySqlFile>;
    mySqlMovieActorFind?: Maybe<MySqlMovieActorConnection>;
    mySqlMovieActorFindOne?: Maybe<MySqlMovieActor>;
    mySqlMovieFind?: Maybe<MySqlMovieConnection>;
    mySqlMovieFindOne?: Maybe<MySqlMovie>;
};
export type QueryDynamoDbActorFindArgs = {
    filter?: InputMaybe<Scalars['AWSJSON']['input']>;
    props?: InputMaybe<FindProps>;
    sort?: InputMaybe<Scalars['AWSJSON']['input']>;
};
export type QueryDynamoDbActorFindOneArgs = {
    filter?: InputMaybe<Scalars['AWSJSON']['input']>;
    props?: InputMaybe<FindOneProps>;
};
export type QueryDynamoDbMovieActorFindArgs = {
    filter?: InputMaybe<Scalars['AWSJSON']['input']>;
    props?: InputMaybe<FindProps>;
    sort?: InputMaybe<Scalars['AWSJSON']['input']>;
};
export type QueryDynamoDbMovieActorFindOneArgs = {
    filter?: InputMaybe<Scalars['AWSJSON']['input']>;
    props?: InputMaybe<FindOneProps>;
};
export type QueryDynamoDbMovieAnalyticsFindArgs = {
    filter?: InputMaybe<Scalars['AWSJSON']['input']>;
    props?: InputMaybe<FindProps>;
    sort?: InputMaybe<Scalars['AWSJSON']['input']>;
};
export type QueryDynamoDbMovieAnalyticsFindOneArgs = {
    filter?: InputMaybe<Scalars['AWSJSON']['input']>;
    props?: InputMaybe<FindOneProps>;
};
export type QueryDynamoDbMovieFindArgs = {
    filter?: InputMaybe<Scalars['AWSJSON']['input']>;
    props?: InputMaybe<FindProps>;
    sort?: InputMaybe<Scalars['AWSJSON']['input']>;
};
export type QueryDynamoDbMovieFindOneArgs = {
    filter?: InputMaybe<Scalars['AWSJSON']['input']>;
    props?: InputMaybe<FindOneProps>;
};
export type QueryDynamoDbMovieIndexFindArgs = {
    filter?: InputMaybe<Scalars['AWSJSON']['input']>;
    props?: InputMaybe<FindProps>;
    sort?: InputMaybe<Scalars['AWSJSON']['input']>;
};
export type QueryMySqlActorFindArgs = {
    filter?: InputMaybe<Scalars['AWSJSON']['input']>;
    limit?: InputMaybe<Scalars['Int']['input']>;
    props?: InputMaybe<FindProps>;
    skip?: InputMaybe<Scalars['Int']['input']>;
    sort?: InputMaybe<Scalars['AWSJSON']['input']>;
};
export type QueryMySqlActorFindOneArgs = {
    filter?: InputMaybe<Scalars['AWSJSON']['input']>;
    props?: InputMaybe<FindOneProps>;
};
export type QueryMySqlFileFindArgs = {
    filter?: InputMaybe<Scalars['AWSJSON']['input']>;
    limit?: InputMaybe<Scalars['Int']['input']>;
    props?: InputMaybe<FindProps>;
    skip?: InputMaybe<Scalars['Int']['input']>;
    sort?: InputMaybe<Scalars['AWSJSON']['input']>;
};
export type QueryMySqlFileFindOneArgs = {
    filter?: InputMaybe<Scalars['AWSJSON']['input']>;
    props?: InputMaybe<FindOneProps>;
};
export type QueryMySqlMovieActorFindArgs = {
    filter?: InputMaybe<Scalars['AWSJSON']['input']>;
    limit?: InputMaybe<Scalars['Int']['input']>;
    props?: InputMaybe<FindProps>;
    skip?: InputMaybe<Scalars['Int']['input']>;
    sort?: InputMaybe<Scalars['AWSJSON']['input']>;
};
export type QueryMySqlMovieActorFindOneArgs = {
    filter?: InputMaybe<Scalars['AWSJSON']['input']>;
    props?: InputMaybe<FindOneProps>;
};
export type QueryMySqlMovieFindArgs = {
    filter?: InputMaybe<Scalars['AWSJSON']['input']>;
    limit?: InputMaybe<Scalars['Int']['input']>;
    props?: InputMaybe<FindProps>;
    skip?: InputMaybe<Scalars['Int']['input']>;
    sort?: InputMaybe<Scalars['AWSJSON']['input']>;
};
export type QueryMySqlMovieFindOneArgs = {
    filter?: InputMaybe<Scalars['AWSJSON']['input']>;
    props?: InputMaybe<FindOneProps>;
};
export type UpdateManyOutput = {
    __typename?: 'UpdateManyOutput';
    modifiedCount?: Maybe<Scalars['Int']['output']>;
};
export type UpdateManyProps = {
    returnConsumedCapacity?: InputMaybe<Scalars['String']['input']>;
    returnValues?: InputMaybe<Scalars['String']['input']>;
};
export type UpdateOneOutput = {
    __typename?: 'UpdateOneOutput';
    modifiedCount?: Maybe<Scalars['Int']['output']>;
};
export type UpdateOneProps = {
    returnConsumedCapacity?: InputMaybe<Scalars['String']['input']>;
    returnValues?: InputMaybe<Scalars['String']['input']>;
};
export type UpsertManyOutput = {
    __typename?: 'UpsertManyOutput';
    modifiedCount?: Maybe<Scalars['Int']['output']>;
    upsertedIds?: Maybe<Scalars['ID']['output']>;
};
export type UpsertManyProps = {
    returnConsumedCapacity?: InputMaybe<Scalars['String']['input']>;
    returnValues?: InputMaybe<Scalars['String']['input']>;
};
export type UpsertOneOutput = {
    __typename?: 'UpsertOneOutput';
    modifiedCount?: Maybe<Scalars['Int']['output']>;
    upsertedId?: Maybe<Scalars['ID']['output']>;
};
export type UpsertOneProps = {
    returnConsumedCapacity?: InputMaybe<Scalars['String']['input']>;
    returnValues?: InputMaybe<Scalars['String']['input']>;
};
export type SubscriptionPage_RunMutation_DynamoDbMovieFragment = {
    __typename?: 'DynamoDbMovie';
    id?: string | null;
    name?: string | null;
};
export declare const SubscriptionPage_RunMutation_DynamoDbMovieFragmentDoc: DocumentNode<SubscriptionPage_RunMutation_DynamoDbMovieFragment, unknown>;
