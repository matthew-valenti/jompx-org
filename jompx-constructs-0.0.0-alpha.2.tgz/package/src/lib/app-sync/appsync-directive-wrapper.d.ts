import { Directive as AppSyncDirective } from 'awscdk-appsync-utils';
/**
 * Wrapper around awscdk-appsync-utils Directive.
 *
 * Why? do we need this class?
 *
 * - AppSync supports multiple authorization modes, but schema directives differ
 *   between single-auth and multi-auth APIs.
 *
 * - `@aws_auth` is intended for **single authorization type only** and becomes
 *   ambiguous or incorrect once additional auth modes (IAM, OIDC, API Key) are added.
 *
 * - `awscdk-appsync-utils` does not reliably expose or enforce
 *   `@aws_cognito_user_pools`, and may emit `@aws_auth` depending on context.
 *
 * - This wrapper enforces a **single, explicit, multi-auth-safe directive**
 *   (`@aws_cognito_user_pools`) for all Cognito field/type authorization.
 *
 * - Centralizing directives avoids schema drift, reduces confusion when new
 *   auth modes are introduced, and allows safe evolution of auth policy
 *   without touching every schema file.
 */
export declare class AppSyncDirectiveWrapper {
    static iam(): AppSyncDirective;
    static oidc(): AppSyncDirective;
    static apiKey(): AppSyncDirective;
    static subscribe(...mutations: string[]): AppSyncDirective;
    static custom(statement: string): AppSyncDirective;
    /**
     * Emits @aws_cognito_user_pools with optional cognito_groups.
     *
     * Examples:
     *  - Directives.cognito()
     *  - Directives.cognito("Admins", "Ops")
     */
    static cognito(...groups: string[]): AppSyncDirective;
}
