import * as graphql from 'graphql';
import { Directive } from 'awscdk-appsync-utils';
import { SchemaTypes } from '../app-sync.types';
/**
 * Abstract custom directive class. Extend this class to to create a custom directives.
 * Note that AppSync supports string value directives only so use stringified object values.
 * Documentation: https://www.apollographql.com/docs/apollo-server/schema/creating-directives/
 */
export declare abstract class CustomDirective {
    /**
     * Directive definition (added to GraphQL schema).
     * Return a string e.g. directive @auth(rules: [AuthRule!]!) on OBJECT | INTERFACE | FIELD_DEFINITION
     */
    abstract definition(): string;
    /**
     * Get the directive value from array of directives on a type.
     * Used primarly for implementation of the directive in datasources.
     * Return one primitive or object type.
     * AppSync only supports string values for directives. Encode/decode values using the base methods as needed (e.g. encodeArgument, decodeArgument).
     * @param directives - Array of directives (on a type).
     */
    abstract value(directives?: Directive[]): void;
    /**
     * Directive schema (to be to added to GraphQL schema).
     * e.g. Auth directives adds enums and input types (required to support the definition).
     * @param schemaTypes - Global list of types.
     */
    schema(schemaTypes: SchemaTypes): void;
    static getDefinition(name: string, locations: graphql.DirectiveLocation[]): string;
    /**
     * Create a directive decorator for use in GraphQL schema definitions.
     * @param value - JSON object value.
     * @returns - Directive decorator type.
     */
    static getDecorator(name: string, value: object): Directive;
    /**
     * Create an SDL-based directive string for use in GraphQL schema definitions.
     * Emits a plain SDL directive (e.g. @directive(arg: "value")) rather than an AppSync
     * Directive object, and preserves encoded JSON values when needed.
     * @param name - Directive name.
     * @param value - Directive argument object to encode into the SDL directive.
     * @returns - A fully formed GraphQL SDL directive string.
     */
    static getDecoratorSdl(name: string, args: Record<string, any>): string;
    static printGraphqlValue(value: any): string;
    /**
     * Get the typed directive value from an array of string directive values.
     * @param name - Directive name.
     * @param directives - Array of directives values.
     * @returns - Directive value.
     */
    static getValue<T>(name: string, directives?: Directive[]): T | undefined;
    /**
     * Encode directive JSON value as string (suitable for a GraphQL schema file).
     * e.g. @auth(rules: "[{\"allow\":\"private\",\"provider\":\"iam\"}]")
     * e.g. @lookup(from: "${lookup.from}", localField: "${lookup.localField}", foreignField: "${lookup.foreignField}
     * @param json - Directive JSON value.
     * @returns - Encoded directive value.
     */
    static encodeArguments(json: object): string;
    /**
     * Decode directive string value to JSON.
     * @param encodedJson - Encoded directive value.
     * @returns - Directive JSON value.
     */
    static decodeArgument(encodedJson: string): any;
    /**
     * Get an argument value (by name) from an array of directive string values.
     * @param identifier - Directive name.
     * @param argument - Directive argument name.
     * @param directives - Array of directive values.
     * @returns - Directive string value.
     */
    static getIdentifierArgument(identifier: string, argument: string, directives: any[] | undefined): string | undefined;
}
