import { Directive } from 'awscdk-appsync-utils';
import { CustomDirective } from './custom-directive-abstract';
export type CustomDirectiveSetDataType = 'number' | 'string';
export interface SetDirectiveValue {
    dataType: CustomDirectiveSetDataType;
}
export declare function set(dataType: string): Directive;
export declare class SetDirective extends CustomDirective {
    definition(): string;
    value(directives?: Directive[]): SetDirectiveValue | undefined;
}
