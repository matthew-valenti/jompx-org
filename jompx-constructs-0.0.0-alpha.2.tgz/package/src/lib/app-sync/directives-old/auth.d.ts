import { Directive } from 'awscdk-appsync-utils';
import { SchemaTypes } from '../app-sync.types';
import { CustomDirective } from './custom-directive-abstract';
export declare const authEffect: string[];
export declare const authType: string[];
export type AuthType = 'apiKey' | 'iam' | 'oidc' | 'userPool' | 'function';
export declare const authAction: string[];
export type AuthAction = 'create' | 'read' | 'update' | 'delete';
export type AuthActionExtended = AuthAction | '*';
export interface AuthDirectiveValue {
    rules: AuthDirectiveRule[];
}
export interface AuthDirectiveProviderProps {
    groups?: string[];
}
export interface AuthDirectiveRule {
    type: AuthType;
    props?: AuthDirectiveProviderProps;
    actions?: AuthActionExtended[];
    condition?: object;
    comment?: string;
}
export declare function auth(rules: AuthDirectiveRule[]): Directive;
export declare class AuthDirective extends CustomDirective {
    definition(): string;
    schema(schemaTypes: SchemaTypes): void;
    value(directives?: Directive[]): AuthDirectiveValue | undefined;
}
