import { Directive } from 'awscdk-appsync-utils';
import { CustomDirective } from './custom-directive-abstract';
export interface ReadonlyDirectiveValue {
    isReadonly: boolean;
}
export declare function readonly(isReadonly: boolean): Directive;
export declare class ReadonlyDirective extends CustomDirective {
    definition(): string;
    value(directives?: Directive[]): ReadonlyDirectiveValue | undefined;
}
