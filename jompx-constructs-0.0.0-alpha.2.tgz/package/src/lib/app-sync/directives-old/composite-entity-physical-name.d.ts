import { Directive } from 'awscdk-appsync-utils';
import { CustomDirective } from './custom-directive-abstract';
export interface CompositeEntityPhysicalNameDirectiveValue {
    name: string;
}
export declare function compositeEntityPhysicalName(name: string): Directive;
export declare class CompositeEntityPhysicalNameDirective extends CustomDirective {
    definition(): string;
    value(directives?: Directive[]): CompositeEntityPhysicalNameDirectiveValue | undefined;
}
