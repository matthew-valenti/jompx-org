import { Directive } from 'awscdk-appsync-utils';
import { CustomDirective } from './custom-directive-abstract';
export interface DefaultValueDirectiveValue {
    onInsert?: object;
    onUpdate?: object;
}
export declare function defaultValue(defaultValueValue: DefaultValueDirectiveValue): Directive;
export declare class DefaultValueDirective extends CustomDirective {
    definition(): string;
    value(directives?: Directive[]): DefaultValueDirectiveValue | undefined;
}
