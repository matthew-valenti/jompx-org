import { Directive } from 'awscdk-appsync-utils';
import { CustomDirective } from './custom-directive-abstract';
export interface ResolvableDirectiveValue {
    isResolvable: boolean;
}
export declare function resolvable(isResolvable: boolean): Directive;
export declare class ResolvableDirective extends CustomDirective {
    definition(): string;
    value(directives?: Directive[]): ResolvableDirectiveValue | undefined;
}
