import { Directive } from 'awscdk-appsync-utils';
import { CustomDirective } from './custom-directive-abstract';
export type CustomDirectiveOperation = 'find' | 'findOne' | 'insertOne' | 'insertMany' | 'updateOne' | 'updateMany' | 'upsertOne' | 'upsertMany' | 'deleteOne' | 'deleteMany' | 'search';
export interface OperationDirectiveValue {
    names: CustomDirectiveOperation[];
}
export declare function operation(names: CustomDirectiveOperation[]): Directive;
export declare class OperationDirective extends CustomDirective {
    definition(): string;
    value(directives?: Directive[]): OperationDirectiveValue | undefined;
}
