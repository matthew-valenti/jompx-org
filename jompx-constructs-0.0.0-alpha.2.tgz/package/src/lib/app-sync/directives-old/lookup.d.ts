import { Directive } from 'awscdk-appsync-utils';
import { CustomDirective } from './custom-directive-abstract';
export interface LookupDirectiveValue {
    from: string;
    localField?: string;
    foreignField?: string;
    let?: object;
    pipeline?: object[];
}
export interface LookupDirectiveValueLet {
    [key: string]: number;
}
export declare function lookup(lookupValue: LookupDirectiveValue): Directive;
export declare class LookupDirective extends CustomDirective {
    definition(): string;
    value(directives: Directive[]): LookupDirectiveValue | undefined;
}
