import { Directive } from 'awscdk-appsync-utils';
import { CustomDirective } from './custom-directive-abstract';
export interface SortKeyDirectiveValue {
    isSortKey: boolean;
}
export declare function sortKey(isSortKey: boolean): Directive;
export declare class SortKeyDirective extends CustomDirective {
    definition(): string;
    value(directives?: Directive[]): SortKeyDirectiveValue | undefined;
}
