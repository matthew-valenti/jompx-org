import { Directive } from 'awscdk-appsync-utils';
import { CustomDirective } from './custom-directive-abstract';
export interface PartitionKeyDirectiveValue {
    isPartitionKey: boolean;
}
export declare function partitionKey(isPartitionKey: boolean): Directive;
export declare class PartitionKeyDirective extends CustomDirective {
    definition(): string;
    value(directives?: Directive[]): PartitionKeyDirectiveValue | undefined;
}
