import { Directive } from 'awscdk-appsync-utils';
import { CustomDirective } from './custom-directive-abstract';
export interface PhysicalNameDirectiveValue {
    name: string;
}
export declare function physicalName(name: string): Directive;
export declare class PhysicalNameDirective extends CustomDirective {
    definition(): string;
    value(directives?: Directive[]): PhysicalNameDirectiveValue | undefined;
}
