import { Directive } from 'awscdk-appsync-utils';
import { CustomDirective } from './custom-directive-abstract';
export interface SecondaryIndexDirectiveValue {
    name: string;
}
export declare function secondaryIndex(name: string): Directive;
export declare class SecondaryIndexDirective extends CustomDirective {
    definition(): string;
    value(directives?: Directive[]): SecondaryIndexDirectiveValue | undefined;
}
