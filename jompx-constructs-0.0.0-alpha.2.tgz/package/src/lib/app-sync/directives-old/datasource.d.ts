import { Directive } from 'awscdk-appsync-utils';
import { CustomDirective } from './custom-directive-abstract';
export interface DatasourceDirectiveValue {
    id: string;
}
export declare function datasource(id: string): Directive;
export declare class DatasourceDirective extends CustomDirective {
    definition(): string;
    value(directives?: Directive[]): DatasourceDirectiveValue | undefined;
}
