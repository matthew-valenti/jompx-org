import * as appsync from 'aws-cdk-lib/aws-appsync';
import * as appsyncUtils from 'awscdk-appsync-utils';
import { DataSource, SchemaTypes } from '../app-sync.types';
export declare class FindOperation {
    codeFirstSchema: appsyncUtils.CodeFirstSchema;
    graphqlApi: appsync.GraphqlApi;
    dataSources: DataSource;
    schemaTypes: SchemaTypes;
    constructor(codeFirstSchema: appsyncUtils.CodeFirstSchema, graphqlApi: appsync.GraphqlApi, dataSources: DataSource, schemaTypes: SchemaTypes);
    schema(objectType: appsyncUtils.ObjectType): void;
}
