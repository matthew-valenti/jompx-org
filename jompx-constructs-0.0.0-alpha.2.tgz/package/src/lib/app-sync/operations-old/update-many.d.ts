import * as appsync from 'aws-cdk-lib/aws-appsync';
import * as appsyncUtils from 'awscdk-appsync-utils';
import { DataSource, SchemaTypes } from '../app-sync.types';
export declare class UpdateManyOperation {
    codeFirstSchema: appsyncUtils.CodeFirstSchema;
    graphqlApi: appsync.GraphqlApi;
    dataSources: DataSource;
    schemaTypes: SchemaTypes;
    authorizationDirectives: appsyncUtils.Directive[];
    constructor(codeFirstSchema: appsyncUtils.CodeFirstSchema, graphqlApi: appsync.GraphqlApi, dataSources: DataSource, schemaTypes: SchemaTypes, authorizationDirectives: appsyncUtils.Directive[]);
    schema(objectType: appsyncUtils.ObjectType): void;
}
