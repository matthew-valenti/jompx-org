import * as appsyncUtils from 'awscdk-appsync-utils';
import { DataSource, SchemaTypes } from '../app-sync.types';
export declare class DeleteOneOperation {
    codeFirstSchema: appsyncUtils.CodeFirstSchema;
    dataSources: DataSource;
    schemaTypes: SchemaTypes;
    authorizationDirectives: appsyncUtils.Directive[];
    constructor(codeFirstSchema: appsyncUtils.CodeFirstSchema, dataSources: DataSource, schemaTypes: SchemaTypes, authorizationDirectives: appsyncUtils.Directive[]);
    schema(objectType: appsyncUtils.ObjectType): void;
}
