export interface FilterInterpreterProps {
    operator: string;
    key: string;
    expression: object;
}
type InterpreterMethodSignature = (props: FilterInterpreterProps) => object | string;
type InterpreterMethod = {
    [key: string]: InterpreterMethodSignature;
};
/**
 * Parse filter argument (based on MongoDB syntax).
 */
export declare class FilterParser {
    interpreters: InterpreterMethod;
    constructor(interpreters: InterpreterMethod);
    interpret(expression: object): object | string;
    private isOperator;
    private nextOperator;
}
export {};
