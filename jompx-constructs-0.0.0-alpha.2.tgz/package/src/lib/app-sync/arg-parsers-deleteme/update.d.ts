export interface UpdateInterpreterProps {
    operator: string;
    value: object;
    expression: object;
}
type InterpreterMethodSignature = (props: UpdateInterpreterProps) => object | string;
type InterpreterMethod = {
    [key: string]: InterpreterMethodSignature;
};
/**
 * Parse update argument (based on MongoDB syntax).
 */
export declare class UpdateParser {
    interpreters: InterpreterMethod;
    constructor(interpreters: InterpreterMethod);
    interpret(expression: object): (object | string)[];
    private isOperator;
}
export {};
