export interface AggregationInterpreterProps {
    operator: string;
    expression: object;
}
export interface ParsedExpression {
    isOperation: boolean;
    isField: boolean;
    fieldPath?: string;
}
export interface DefaultVariableValues {
    /** K-Sortable unique iDentifier. Use for DynamoDB ids. */
    KSUID: string;
    /** Universally unique iDentifier. Use for MongoDB ids. */
    UUID: string;
    /** Current UTC date and time (in ISO). */
    NOW: string;
}
type InterpreterMethodSignature = (props: AggregationInterpreterProps) => object | string;
type InterpreterMethod = {
    [key: string]: InterpreterMethodSignature;
};
/**
 * Parse Aggregation argument (based on MongoDB syntax).
 * MongoDB expressions reference: https://www.mongodb.com/docs/manual/meta/aggregation-quick-reference/#std-label-aggregation-expressions
 * Varibles: Strings that start with $$.
 */
export declare class AggregationParser {
    interpreters: InterpreterMethod;
    constructor(interpreters: InterpreterMethod);
    interpret(expression: object, variableValues?: {}): object | string;
    static parseExpressions(expressions: string[] | object[], numberOfExpressions?: number): ParsedExpression[];
    private isOperator;
    private nextOperator;
    /**
     * Given a MongoDB expression syntax, replace any $$ variables with values (if exist).
     * e.g. { $expr: { $in: { '$$identity.username': '$owners' } } } becomes { $expr: { $in: { 'abc': '$owners' } } }
     * @param expression - MongoDB expression JSON.
     * @param customVariableValues - Custom variable values object.
     * @param defaultVariableValues - Default variable values object. Ensure default dates and times apply to the entire operation.
     * @returns - expression with $$ variables replaced with values.
     */
    static replaceExpressionVariables(expression: object, customVariableValues: object, defaultVariableValues: DefaultVariableValues): object;
    static defaultVariableValues(): DefaultVariableValues;
    static isTestingWithJest(): boolean;
}
export {};
