import * as graphql from 'graphql';
import { CustomDirective } from './custom-directive-abstract';
export interface ReadonlyDirectiveValue {
    isReadonly: boolean;
}
export declare function readonly(isReadonly: boolean): string;
export declare class ReadonlyDirective extends CustomDirective {
    definition(): string;
    value(directives?: readonly graphql.DirectiveNode[]): ReadonlyDirectiveValue | undefined;
}
