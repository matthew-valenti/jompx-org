import * as graphql from 'graphql';
import { CustomDirective } from './custom-directive-abstract';
export interface ResolvableDirectiveValue {
    isResolvable: boolean;
}
export declare function resolvable(isResolvable: boolean): string;
export declare class ResolvableDirective extends CustomDirective {
    definition(): string;
    value(directives?: readonly graphql.DirectiveNode[]): ResolvableDirectiveValue | undefined;
}
