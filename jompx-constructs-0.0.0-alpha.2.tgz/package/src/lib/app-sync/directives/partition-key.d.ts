import * as graphql from 'graphql';
import { CustomDirective } from './custom-directive-abstract';
export interface PartitionKeyDirectiveValue {
    isPartitionKey: boolean;
}
export declare function partitionKey(isPartitionKey: boolean): string;
export declare class PartitionKeyDirective extends CustomDirective {
    definition(): string;
    value(directives?: readonly graphql.DirectiveNode[]): PartitionKeyDirectiveValue | undefined;
}
