import * as graphql from 'graphql';
import { CustomDirective } from './custom-directive-abstract';
export interface PhysicalNameDirectiveValue {
    name: string;
}
export declare function physicalName(name: string): string;
export declare class PhysicalNameDirective extends CustomDirective {
    definition(): string;
    value(directives?: readonly graphql.DirectiveNode[]): PhysicalNameDirectiveValue | undefined;
}
