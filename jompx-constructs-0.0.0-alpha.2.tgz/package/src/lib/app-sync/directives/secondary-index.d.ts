import * as graphql from 'graphql';
import { CustomDirective } from './custom-directive-abstract';
export interface SecondaryIndexDirectiveValue {
    name: string;
}
export declare function secondaryIndex(name: string): string;
export declare class SecondaryIndexDirective extends CustomDirective {
    definition(): string;
    value(directives?: readonly graphql.DirectiveNode[]): SecondaryIndexDirectiveValue | undefined;
}
