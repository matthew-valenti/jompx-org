import * as graphql from 'graphql';
import { CustomDirective } from './custom-directive-abstract';
export declare const operationNames: readonly ["find", "findOne", "insertOne", "insertMany", "updateOne", "updateMany", "upsertOne", "upsertMany", "deleteOne", "deleteMany", "search"];
export type CustomDirectiveOperation = typeof operationNames[number];
export interface OperationDirectiveValue {
    names: CustomDirectiveOperation[];
}
export declare function operation(names: CustomDirectiveOperation[]): string;
export declare class OperationDirective extends CustomDirective {
    definition(): string;
    value(directives?: readonly graphql.DirectiveNode[]): OperationDirectiveValue | undefined;
}
