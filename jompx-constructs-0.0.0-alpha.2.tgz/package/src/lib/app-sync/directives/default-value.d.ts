import * as graphql from 'graphql';
import { CustomDirective } from './custom-directive-abstract';
export interface DefaultValueDirectiveValue {
    onInsert?: object;
    onUpdate?: object;
}
export declare function defaultValue(defaultValueValue: DefaultValueDirectiveValue): string;
export declare class DefaultValueDirective extends CustomDirective {
    definition(): string;
    value(directives?: readonly graphql.DirectiveNode[]): DefaultValueDirectiveValue | undefined;
}
