import * as graphql from 'graphql';
import { CustomDirective } from './custom-directive-abstract';
export interface CompositeEntityPhysicalNameDirectiveValue {
    name: string;
}
export declare function compositeEntityPhysicalName(name: string): string;
export declare class CompositeEntityPhysicalNameDirective extends CustomDirective {
    definition(): string;
    value(directives?: readonly graphql.DirectiveNode[]): CompositeEntityPhysicalNameDirectiveValue | undefined;
}
