import * as graphql from 'graphql';
import { CustomDirective } from './custom-directive-abstract';
export interface DatasourceDirectiveValue {
    id: string;
}
export declare function datasource(id: string): string;
export declare class DatasourceDirective extends CustomDirective {
    definition(): string;
    value(directives?: readonly graphql.DirectiveNode[]): DatasourceDirectiveValue | undefined;
}
