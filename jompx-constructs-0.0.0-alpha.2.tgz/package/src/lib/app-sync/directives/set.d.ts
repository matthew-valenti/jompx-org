import * as graphql from 'graphql';
import { CustomDirective } from './custom-directive-abstract';
export type CustomDirectiveSetDataType = 'number' | 'string';
export interface SetDirectiveValue {
    dataType: CustomDirectiveSetDataType;
}
export declare function set(dataType: string): string;
export declare class SetDirective extends CustomDirective {
    definition(): string;
    value(directives?: readonly graphql.DirectiveNode[]): SetDirectiveValue | undefined;
}
