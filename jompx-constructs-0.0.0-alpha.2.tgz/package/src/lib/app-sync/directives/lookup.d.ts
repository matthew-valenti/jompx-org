import * as graphql from 'graphql';
import { CustomDirective } from './custom-directive-abstract';
export interface LookupDirectiveValue {
    from: string;
    localField?: string;
    foreignField?: string;
    let?: object;
    pipeline?: object[];
    type: string;
}
export interface LookupDirectiveValueLet {
    [key: string]: number;
}
export declare function lookup(lookupValue: LookupDirectiveValue): string;
export declare class LookupDirective extends CustomDirective {
    definition(): string;
    value(directives?: readonly graphql.DirectiveNode[]): LookupDirectiveValue | undefined;
}
