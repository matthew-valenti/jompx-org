import { CustomSchema } from './schema.abstract';
export declare class ProblemSchema extends CustomSchema {
    schema(): string;
}
