import { CustomSchema } from './schema.abstract';
export declare class DeleteOneSchema extends CustomSchema {
    schema(): string;
}
