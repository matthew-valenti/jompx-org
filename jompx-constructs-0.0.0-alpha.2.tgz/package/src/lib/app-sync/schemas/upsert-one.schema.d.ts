import { CustomSchema } from './schema.abstract';
export declare class UpsertOneSchema extends CustomSchema {
    schema(): string;
}
