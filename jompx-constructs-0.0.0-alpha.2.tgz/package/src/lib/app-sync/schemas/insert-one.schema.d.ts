import { CustomSchema } from './schema.abstract';
export declare class InsertOneSchema extends CustomSchema {
    schema(): string;
}
