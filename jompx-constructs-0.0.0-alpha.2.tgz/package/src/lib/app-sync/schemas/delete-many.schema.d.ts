import { CustomSchema } from './schema.abstract';
export declare class DeleteManySchema extends CustomSchema {
    schema(): string;
}
