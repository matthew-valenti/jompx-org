import { CustomSchema } from './schema.abstract';
export declare class InsertManySchema extends CustomSchema {
    schema(): string;
}
