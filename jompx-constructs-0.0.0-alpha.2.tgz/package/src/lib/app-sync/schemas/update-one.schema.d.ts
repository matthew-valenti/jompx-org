import { CustomSchema } from './schema.abstract';
export declare class UpdateOneSchema extends CustomSchema {
    schema(): string;
}
