/**
 * Abstract custom schema class. Implement global schemas for use across all datasources.
 * Documentation: https://www.apollographql.com/docs/apollo-server/schema/creating-directives/
 */
export declare abstract class CustomSchema {
    /**
     * Schema (to be to added to GraphQL schema).
     * @param schemaTypes - Global list of types.
     */
    abstract schema(): void;
}
