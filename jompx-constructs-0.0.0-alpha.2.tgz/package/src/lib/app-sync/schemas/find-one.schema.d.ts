import { CustomSchema } from './schema.abstract';
export declare class FindOneSchema extends CustomSchema {
    schema(): string;
}
