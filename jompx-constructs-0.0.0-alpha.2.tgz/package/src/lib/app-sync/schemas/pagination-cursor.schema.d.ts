import { CustomSchema } from './schema.abstract';
export declare class PaginationCursorSchema extends CustomSchema {
    schema(): string;
}
