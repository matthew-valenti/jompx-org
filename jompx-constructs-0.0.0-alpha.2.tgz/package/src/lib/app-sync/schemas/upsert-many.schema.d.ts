import { CustomSchema } from './schema.abstract';
export declare class UpsertManySchema extends CustomSchema {
    schema(): string;
}
