import { CustomSchema } from './schema.abstract';
export declare class PaginationOffsetSchema extends CustomSchema {
    schema(): string;
}
