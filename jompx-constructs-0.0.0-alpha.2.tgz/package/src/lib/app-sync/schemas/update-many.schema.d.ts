import { CustomSchema } from './schema.abstract';
export declare class UpdateManySchema extends CustomSchema {
    schema(): string;
}
