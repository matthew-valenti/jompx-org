import { CustomSchema } from './schema.abstract';
export declare class FindSchema extends CustomSchema {
    schema(): string;
}
