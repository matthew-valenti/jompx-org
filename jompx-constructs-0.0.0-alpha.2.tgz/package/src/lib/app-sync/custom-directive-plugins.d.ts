import { CustomDirective } from './directives/custom-directive-abstract';
/**
 * A simple plugin architecture for dynamically loading custom directives.
 * A custom directive is simply a typescript class. However, we must load the transpiled .js and not the source .ts file.
 * Given a glob pattern, load and instantiate each custom directive class.
 * Plugin architecture is based on this example: https://javascript.plainenglish.io/how-to-build-a-plugin-system-with-typescript-e7efb9f7e1ab
 */
export declare class CustomDirectivePlugins {
    private readonly matchClassName;
    /**
     * Array of instantiated custom directive classes. Empty if glob file pattern does not match any files.
     */
    customDirectives: CustomDirective[];
    /**
     *
     * @param globFilePattern - Glob file pattern matching transpiled custom directive .js files e.g. directives/!(*.d).js
     */
    init(globFilePattern: string): Promise<void>;
}
