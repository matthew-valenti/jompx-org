import * as codepipeline from 'aws-cdk-lib/aws-codepipeline';
import { Construct } from 'constructs';
import { DatabaseMigrationContractReference, DatabaseMigrationContractRegistryConfig, DatabaseMigrationEngine } from '../database-migration/database-migration.types';
export interface DatabaseMigrationPipelineGitHubProps {
    connectionArn: string;
    owner: string;
    repo: string;
    branch: string;
    triggerOnPush?: boolean;
}
export interface DatabaseMigrationPipelineActionProps {
    databaseIdentifier: string;
    targetId?: string;
    engine: DatabaseMigrationEngine;
    buildCommand: string;
    buildOutputPath: string;
    direction?: 'up' | 'down';
    secretName?: string;
    runOrder?: number;
}
export interface DatabaseMigrationPipelineProps {
    pipelineName: string;
    stage: string;
    gitHub: DatabaseMigrationPipelineGitHubProps;
    migrations: DatabaseMigrationPipelineActionProps[];
    /**
     * Registry connection details used by migration actions to resolve Store and Orchestrator config.
     */
    contractRegistry: DatabaseMigrationContractRegistryConfig;
    /**
     * Pointer to the Store contract published by DatabaseMigrationStore.
     */
    storeContractReference: DatabaseMigrationContractReference;
    /**
     * Pointer to the Orchestrator contract published by DatabaseMigrationOrchestrator.
     */
    orchestratorContractReference: DatabaseMigrationContractReference;
    /**
     * Store roles migration actions are allowed to assume for artifact upload.
     */
    assumableStoreRoleArns: string[];
    /**
     * Orchestrator roles migration actions are allowed to assume to start executions.
     */
    assumableOrchestratorRoleArns: string[];
}
/**
 * CodePipeline that sources repository code, uploads migration artifacts to Store S3, and
 * triggers Orchestrator executions.
 *
 * Consumes Store and Orchestrator config from the service contract registry at pipeline runtime.
 */
export declare class DatabaseMigrationPipeline extends Construct {
    readonly pipeline: codepipeline.Pipeline;
    constructor(scope: Construct, id: string, props: DatabaseMigrationPipelineProps);
}
