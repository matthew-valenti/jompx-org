import * as codepipeline from 'aws-cdk-lib/aws-codepipeline';
import { Construct } from 'constructs';
import { DatabaseMigrationOrchestratorConfig, DatabaseMigrationPublishedContract, DatabaseMigrationStoreConfig } from '../database-migration/database-migration.types';
export interface DatabaseMigrationPipelineGitHubProps {
    connectionArn: string;
    owner: string;
    repo: string;
    branch: string;
    triggerOnPush?: boolean;
}
export interface DatabaseMigrationPipelineActionProps {
    databaseIdentifier: string;
    targetId?: string;
    buildCommand: string;
    buildOutputPath: string;
    direction?: 'up' | 'down';
    runOrder?: number;
}
export interface DatabaseMigrationPipelineProps {
    pipelineName: string;
    stage: string;
    gitHub: DatabaseMigrationPipelineGitHubProps;
    migrations: DatabaseMigrationPipelineActionProps[];
    /**
     * Published Store contract. Pass the full lookup result directly.
     */
    storeContract: DatabaseMigrationPublishedContract<DatabaseMigrationStoreConfig>;
    /**
     * Published Orchestrator contract. Pass the full lookup result directly.
     */
    orchestratorContract: DatabaseMigrationPublishedContract<DatabaseMigrationOrchestratorConfig>;
}
/**
 * CodePipeline that sources repository code, uploads migration artifacts to Store S3, and
 * triggers Orchestrator executions.
 *
 * Consumes Store and Orchestrator config passed directly at construct time.
 */
export declare class DatabaseMigrationPipeline extends Construct {
    readonly pipeline: codepipeline.Pipeline;
    constructor(scope: Construct, id: string, props: DatabaseMigrationPipelineProps);
}
