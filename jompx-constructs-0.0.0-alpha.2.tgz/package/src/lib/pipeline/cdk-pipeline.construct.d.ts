import * as cdk from 'aws-cdk-lib';
import * as pipelines from 'aws-cdk-lib/pipelines';
import { Construct } from 'constructs';
/**
 *  IMPORTANT: Cannot use CDK pipeline while there are "link" npm packages in org package.json.
 *
 *
 *
 * Case 1: CDK Pipeline to run on CI/CD account
 * CI/CD prod to listen to branches e.g. main.
 * CI/CD test to listen to test branches e.g. test-main.
 * Use context parameter "stage" to identity prod vs. test.
 * CDK pipeline stack does a CDK synth and each CI/CD account should inject it's appropriate stage context param on synth.
 * e.g. cdk synth --context stage=prod
 *
 * Case 2: Deploy CDK pipeline stack to CI/CD account (e.g. first time)
 * When manually deploying CDK pipeline stack to CI/CD account specify stage as context param.
 * e.g. cdk deploy CdkPipelineStack --context stage=test
 *
 * Case 3: Developer to manually deploy any branch from any CI/CD environment
 * When manually deploying a branch via CDK pipeline stack specify both stage and branch as context params.
 * The branch must be included to give the deploy context. e.g. Is the stack to be deployed to a sandbox or prod account?
 * Deploys are branch specific. A sandbox branch will typically deploy to a specific sandbox.
 * A prod branch deploy might deploy first to a test environment and then the prod environment.
 * A stack cannot be deployed to a specific account because a stack might deploy to a variety of accounts.
 * e.g. cdk deploy MyStack --context stage=test branch=main
 *
 * Continuous integration and delivery (CI/CD) using CDK Pipelines:
 * https://docs.aws.amazon.com/cdk/v2/guide/cdk_pipeline.html
 * https://docs.aws.amazon.com/cdk/api/v2/docs/aws-cdk-lib.pipelines-readme.html
 * https://docs.aws.amazon.com/cdk/api/v2/docs/aws-cdk-lib.aws_codebuild-readme.html
 *
 * Build Spec Reference: https://docs.aws.amazon.com/codebuild/latest/userguide/build-spec-ref.html
 *
 * NEW mono repo support.
 * https://aws.amazon.com/blogs/devops/aws-codepipeline-adds-support-for-branch-based-development-and-monorepos/
 *
 * TODO: nx affected:
 * https://nx.dev/ci/monorepo-ci-circle-ci
 *
 * TODO deploy in parallel:
 * https://docs.aws.amazon.com/cdk/api/v1/docs/pipelines-readme.html
 *
 * TODO: Trigger apps pipeline
 * https://stackoverflow.com/questions/62857925/how-to-invoke-a-pipeline-based-on-another-pipeline-success-using-aws-codecommit
 *
 * Create CDK pipelines that deploy CDK code across AWS accounts on GitHub branch updates.
 * All CDK pipeline resources reside on a single AWS account (preferrably a dedicated CI/CD AWS account)
 * This dedicated AWS account will have permissions to deploy to all other accounts (as needed). Developers can also be given admin or readonly permissions to troubleshoot CDK deployment errors.
 * To give permissions to the CI/CD AWS accounts use the --trust parameter when CDK boostrapping AWS accounts.
 * Allow for both test and prod CI/CD AWS accounts. CI/CD enhancements can be done safely on the test CI/CD AWS account without affecting production deployments.
 * CI/CD prod will run all pipelines including test and sandbox branches.
 * CI/CD test is for testing only and will run the same pipelines but will listen to branches with test- e.g. test-main, test-test, test-sandbox1.
 * It's important that test pipelines don't trigger on commits to main, test, sandbox1, etc. This would result in multiple pipelines deploying at the same time.
 * Create a CDK pipeline for each stage (e.g. sandbox1, test, prod) where each stage is an AWS account (e.g. prod resources reside on a prod AWS account).
 * Each stage is compromised of a set of "CDK stages" which can be deployed to any account. This allows common CDK resources to be deployed to a common AWS account (e.g. AWS WAF or GuardDuty can be deployed to a common AWS account and shared across stages sandbox1, test, prod).
 * A github branch update will trigger a CDK pipeline to start. i.e. push a branch to trigger a pipeline deploy.
 * Each stage is associated with a branch (e.g. updates to the main branch triggers the prod pipeline to start, updates to the sandbox1 branch triggers the sandbox1 pipelien to start).
 * A CDK stage is comprised or one or more CDK stacks. A CDK stack is comprised of one or more CDK constructs.
 * Developers can also manually deploy stacks (if they have the appropriate AWS account permissions setup on their local).
 * During development, developers will typically manually deploy a stack they're working on to their sandbox AWS account.
 * A one-time manual deployment of the CDK pipeline stack is needed to the test and prod CI/CD AWS accounts.
 * Supports configuration to allow an organization to have any number of stages, accounts, and CDK stages.
 *
 * AWS CodePipeline recommends using a CodePipelineSource connection to securly connect to GitHub. However, CodeBuild only supports the old Github token authorization.
 * Stage branches use a connection. Regex stage branches use a token.
 * Setup steps are required to enable both a connection and a token.
 *
 * GitHub has a 20 web hook limit per event (per repo). It may be necessary to switch from web hook to polling or not create unused code pipelines (e.g. test-sandbox1 branch deploys may not be needed).
 *
 * AWS Docs: The pipeline is self-mutating, which means that if you add new application stages in the source code, or new stacks to MyApplication, the pipeline will automatically reconfigure itself to deploy those new stages and stacks.
 *
 * Important:
 * - The CDK pipeline acts in the context of a stage (e.g. sandbox1, test, prod) and a stage is typically associated with one AWS account (e.g. prod AWS account).
 * - A stage parameter must always be available. This parameter can be specified on the command line (which always takes precedence) or from a config file.
 * - The cdk synth command in the pipeline includes a stage param. When the pipeline runs, the stage param is available in our CDK code.
 * e.g. When the main branch is updated, it triggers the prod pipeline to synth and deploy CDK changes with stage param = 'prod'. This allows developers to write conditional CDK code e.g. if (status === 'prod').
 * - A CDK pipeline is connected to one GitHub branch (and listens to that branch for updates).
 *
 * Deployments supported:
 * - Manual CDK Pipeline stack deployment to CI/CD test and prod environments.
 * - GitHub triggered deployments across all branches and all CI/CD stage branches e.g. (prod & test-prod, test & test-test, sandbox1 & test-sandbox1).
 * - Manual CDK stack deploys (to any env). e.g. deploy stack to sandbox1, deploy stack to test, deploy stack to prod.
 *
 * Troubleshooting:
 * - Do NOT use "Start build" button in AWS management console for github copy to S3 build projects. Results in unexpected files in S3! Push the branch and let it trigger the build project.
 */
export interface CdkPipelineProps {
    pipelineName: string;
    stage: string;
    gitHub: CdkPipelineGitHubProps;
    codeBuild: CdkPipelineCodeBuildProps;
}
export interface CdkPipelineGitHubProps {
    connectionArn: string;
    owner: string;
    repo: string;
    branch: string;
}
export interface CdkPipelineCodeBuildProps {
    buildEnvironment: cdk.aws_codebuild.BuildEnvironment;
    installCommands?: string[];
    commands: string[];
    env?: Record<string, string>;
    partialBuildSpec?: cdk.aws_codebuild.BuildSpec;
    primaryOutputDirectory?: string;
}
export declare class CdkPipeline extends Construct {
    pipeline: pipelines.CodePipeline;
    constructor(scope: Construct, id: string, props: CdkPipelineProps);
}
