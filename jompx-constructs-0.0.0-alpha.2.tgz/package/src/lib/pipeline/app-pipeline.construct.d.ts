import * as cdk from 'aws-cdk-lib';
import * as s3 from 'aws-cdk-lib/aws-s3';
import { Construct } from 'constructs';
export interface AppPipelineProps {
    organizationName: string;
    stage: string;
    branches: string[];
    apps: AppPipelineAppProps[];
    gitHub: AppPipelineGitHubProps;
}
export interface AppPipelineAppProps {
    name: string;
    bucket: s3.IBucket;
    codebuildBuildSpecObject: object;
    buildEnvironment?: cdk.aws_codebuild.BuildEnvironment;
}
export interface AppPipelineGitHubProps {
    owner: string;
    repo: string;
    token: cdk.SecretValue;
}
export interface StagePipeline {
    stage: string;
    branch: string;
    pipeline: cdk.aws_codepipeline.Pipeline;
}
/**
 * The test CICD account only listens for test-branches.
 * I prefer the concept of all pipelines being on a single CICD AWS account.
 * - We can secure the GitHub token.
 * - No sandbox clutter.
 * - 1x S3 passthru source.
 * However, what do we do about test vs. prod? It over complicates things.
 * It's so simple to have one pipeline per account. I can make a change test and deploy it without affecting all accounts. This is the biggest advantage.
 */
export declare class AppPipeline extends Construct {
    stagePipelines: StagePipeline[];
    constructor(scope: Construct, id: string, props: AppPipelineProps);
}
