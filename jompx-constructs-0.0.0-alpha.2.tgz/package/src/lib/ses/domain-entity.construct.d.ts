import * as ses from 'aws-cdk-lib/aws-ses';
import { Construct } from 'constructs';
export interface SesDomainEntityProps {
    domainName: string;
}
/**
 * Create an SES verified domain entity.
 * Required for sending emails from email addresses on this domain.
 */
export declare class SesDomainEntity extends Construct {
    emailIdentity: ses.EmailIdentity;
    constructor(scope: Construct, id: string, props: SesDomainEntityProps);
}
