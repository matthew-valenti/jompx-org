import * as cdk from 'aws-cdk-lib';
import * as rds from 'aws-cdk-lib/aws-rds';
import { Construct } from 'constructs';
import { RdsProxy } from './rds-proxy.construct';
export interface AuroraServerlessVersion1Props {
    /**
     * The CloudFormation removal policy for the DB cluster.
     *
     * @default cdk.RemovalPolicy.RETAIN
     */
    removalPolicy?: cdk.RemovalPolicy;
    /**
     * An identifier for the cluster.
     * e.g. `aurora-serverless-1-mysql-${environment.name}`
     */
    clusterIdentifier: string;
    /**
     * Best practice is to use a versioned engine using auroraMysql() or auroraPostgres() method.
     * e.g. rds.DatabaseClusterEngine.auroraMysql({ version: rds.AuroraMysqlEngineVersion.VER_3_02_1 })
     */
    engine: cdk.aws_rds.IClusterEngine;
    /**
     * Enable RDS Proxy for Lambda-style SQL workloads.
     *
     * @default false
     */
    proxy?: boolean;
    vpc: cdk.aws_ec2.IVpc;
    /**
     * Security best practice is to use private isolated subnets (at least two that span AZs for redundancy).
     * e.g. { subnetType: ec2.SubnetType.PRIVATE_ISOLATED }
     */
    vpcSubnets: cdk.aws_ec2.SubnetSelection;
    /**
     * Use a customer-managed KMS key for cluster storage encryption at rest.
     * Aurora storage remains encrypted either way; this controls whether you use your own KMS key
     * instead of the default AWS-managed key. This is a low-cost choice that is worth making up front
     * if you expect stricter audit/compliance requirements later, because changing keys later is
     * operationally awkward.
     *
     * @default false
     */
    useCustomerManagedKmsKey?: boolean;
    /**
     * Default = admin.
     */
    adminDatabaseUsername?: string;
    /**
     * Whether to enable the HTTP-based RDS Data API.
     *
     * @default false
     */
    enableDataApi?: boolean;
    /**
     * The number of days during which automatic DB snapshots are retained.
     * Automatic backup retention cannot be disabled on serverless clusters.
     *
     * @default 1 day
     */
    backupRetention?: cdk.Duration;
    parameterGroupParameters?: {
        [key: string]: string;
    };
}
/**
 * Aurora Serverless v1 cluster.
 * AWS does not recommend version 1 for most new production workloads, but it can still be useful
 * for low-throughput or intermittent environments that benefit from automatic pause and resume.
 * Cons:
 * - Requires SQL CI/CD e.g. A database migration tool to apply database schema changes.
 * - Aurora Serverless v1 is a legacy platform choice compared with newer Aurora options.
 * Security:
 * - This construct places the cluster in a VPC isolated subnet. A VPN (or similar) is required for connecting directly to the database from outside AWS.
 * - For Lambda to connect directly to the database, it must also run inside the VPC and attach the construct client security group.
 * - When proxy is enabled, the network path becomes client -> proxy -> database.
 * - Deploy database change scripts for RDBMS in SQL and DynamoDB in TypeScript. umzug is NodeJS native and framework agnostic: https://github.com/sequelize/umzug
 * Cost:
 * - Aurora Serverless v1 pricing is separate from backup storage, Data API usage, and any optional KMS key.
 * - Enabling Secrets Manager rotation adds small additional cost beyond the base secret.
 * - Enabling proxy adds separate monthly cost per environment.
 */
export declare class AuroraServerlessVersion1 extends Construct {
    cluster: rds.ServerlessCluster;
    proxy: RdsProxy | undefined;
    dbSecurityGroup: cdk.aws_ec2.SecurityGroup;
    clientSecurityGroup: cdk.aws_ec2.SecurityGroup;
    parameterGroup: cdk.aws_rds.ParameterGroup;
    storageEncryptionKey: cdk.aws_kms.Key | undefined;
    constructor(scope: Construct, id: string, props: AuroraServerlessVersion1Props);
}
