import * as ec2 from 'aws-cdk-lib/aws-ec2';
import * as rds from 'aws-cdk-lib/aws-rds';
import * as secretsmanager from 'aws-cdk-lib/aws-secretsmanager';
import { Construct } from 'constructs';
export interface RdsProxyProps {
    /**
     * The database instance or cluster the proxy forwards connections to.
     */
    proxyTarget: rds.ProxyTarget;
    /**
     * The database connection target whose security group should trust the proxy.
     */
    database: ec2.IConnectable;
    vpc: ec2.IVpc;
    /**
     * Best practice is to place the proxy in private subnets within the same VPC as the database.
     */
    vpcSubnets: ec2.SubnetSelection;
    /**
     * The client security group trusted by the proxy.
     */
    clientSecurityGroup: ec2.ISecurityGroup;
    /**
     * One or more service-account secrets the proxy uses to connect to the database.
     */
    secrets: secretsmanager.ISecret[];
}
/**
 * Shared RDS Proxy construct for Lambda-style SQL workloads.
 * Use this internally from top-level database constructs to add server-side SQL connection pooling
 * without duplicating proxy security and networking setup.
 * Security:
 * - This construct keeps the network path explicit: client -> proxy -> database.
 * - Clients never need direct network access to the database when the proxy is enabled.
 * - The proxy has its own security group so trust remains layered and easy to reason about.
 * - The proxy trusts only the client security group and the database trusts only the proxy security group.
 * Cost:
 * - RDS Proxy is billed separately from the database.
 * - Pricing is based on DB compute capacity (vCPU / ACU), not connection count.
 * - Enabling proxy per environment (QA, Prod) adds separate monthly cost.
 */
export declare class RdsProxy extends Construct {
    proxy: rds.DatabaseProxy;
    proxySecurityGroup: ec2.SecurityGroup;
    constructor(scope: Construct, id: string, props: RdsProxyProps);
}
