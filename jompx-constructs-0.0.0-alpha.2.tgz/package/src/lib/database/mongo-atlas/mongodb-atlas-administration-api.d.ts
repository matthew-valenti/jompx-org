import urllib = require('urllib');
/**
 * https://www.mongodb.com/docs/atlas/reference/api-resources-spec/v2/
 * https://github.com/mongodb-developer/atlas-admin-api-digest-auth/blob/main/node/request.js
 */
export declare class MongoDbAtlasAdministrationApi {
    private publicKey;
    private privateKey;
    readonly mongodbAtlasAdministrationApiBaseUrl = "https://cloud.mongodb.com/api/atlas/v2";
    readonly maxPageNum = 500;
    constructor(publicKey: string, privateKey: string);
    fetch(path: string, options?: urllib.RequestOptions): Promise<urllib.HttpClientResponse>;
}
