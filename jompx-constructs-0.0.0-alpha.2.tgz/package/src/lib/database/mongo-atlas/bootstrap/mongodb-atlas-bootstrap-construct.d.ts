import * as cdk from 'aws-cdk-lib';
import * as iam from 'aws-cdk-lib/aws-iam';
import { Construct } from 'constructs';
export interface MongoDbAtlasBootstrapProps {
    accountId: string;
    organizationId: string;
    activationTypes: string[];
    accessListProfiles: MongoDbAtlasBootstrapProfiles[];
}
export interface MongoDbAtlasBootstrapProfiles {
    profile: string;
    region: string;
}
/**
 * Atlas MongoDB boostrap.
 * A one-time boostrap is required to allow the CDK to deploy Atlas MongoDB using CloudFormation.
 * https://github.com/mongodb/awscdk-resources-mongodbatlas/blob/334e4a2790e5fc537dcf4ed95167d950ddd95606/src/l3-resources/atlas-bootstrap/index.ts
 */
export declare class MongoDbAtlasBootstrap extends Construct {
    role: iam.Role;
    lambdaFunction: cdk.aws_lambda_nodejs.NodejsFunction;
    topic: cdk.aws_sns.ITopic;
    constructor(scope: Construct, id: string, props: MongoDbAtlasBootstrapProps);
}
