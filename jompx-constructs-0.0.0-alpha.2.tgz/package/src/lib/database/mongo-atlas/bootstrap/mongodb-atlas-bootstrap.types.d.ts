export interface MongoDbAtlasProfileSecretValue {
    apiKeyId: string;
    privateKey: string;
    publicKey: string;
}
export interface AwsIpRange {
    ip_prefix: string;
    region: string;
    service: string;
    network_border_group: string;
}
export interface AccessListEntry {
    cidrBlock: string;
}
