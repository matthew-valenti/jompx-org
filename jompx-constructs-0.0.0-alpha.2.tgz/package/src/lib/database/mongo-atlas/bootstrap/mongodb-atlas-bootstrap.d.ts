import { MongoDbAtlasBootstrapProfiles } from './mongodb-atlas-bootstrap-construct';
import * as ltypes from './mongodb-atlas-bootstrap.types';
/**
 * Bootstrap MongoDB Atlas for use with the AWS CDK.
 * https://www.mongodb.com/docs/atlas/reference/api-resources-spec/v2/
 */
export declare class MongoDbAtlasBootstrap {
    readonly mongodbAtlasAdministrationApiBaseUrl = "https://cloud.mongodb.com/api/atlas/v2";
    readonly organizationId: string;
    readonly accessListProfiles: MongoDbAtlasBootstrapProfiles[];
    readonly awsIpRangesUrl: string;
    private api;
    private awsIpRanges;
    constructor(organizationId: string, accessListProfiles: MongoDbAtlasBootstrapProfiles[], awsIpRangesUrl: string);
    /**
     * Sync the MongoDB Atlas API Key access list entries with publised AWS IP ranges (i.e. CIDR blocks).
     * The API Key must contain the dynamic IP that CloudFormation uses to deploy the CDK and call MongoDB Atlas APIs.
     * https://docs.aws.amazon.com/vpc/latest/userguide/aws-ip-ranges.html
     */
    syncApiKeyAccessListEntriesWithAwsIpRanges(): Promise<void>;
    /**
     * Get the offical published list of all AWS IP ranges and filter by region/service.
     * @param region
     * @param service
     * @returns
     */
    getAwsIpRangesByFilter(region: string, service: string): Promise<ltypes.AwsIpRange[]>;
    /**
     * Use the MongoDB Atlas administrative API to get access list entries.
     * This endpoint doesn't support concurrent POST requests. You must submit multiple POST requests synchronously.
     * https://www.mongodb.com/docs/atlas/reference/api-resources-spec/v2/#tag/Project-IP-Access-List/operation/listProjectIpAccessLists
     */
    getAccessListEntries(apiKeyId: string): Promise<string[]>;
    /**
     * Add CIDRs to the MongoD Atlas API Key access list.
     * @param apiKeyId
     * @param currentAccessListEntries
     * @param awsIpRanges
     * @returns - An array of CIDRs successfully added.
     */
    addCidrs(apiKeyId: string, currentAccessListEntries: string[], awsIpRanges: ltypes.AwsIpRange[]): Promise<string[]>;
    /**
     * Use the MongoDB Atlas administrative API to add access list entries.
     * @param apiKeyId
     * @param entryValues
     */
    addApiKeyAccessListEntries(apiKeyId: string, entryValues: string[]): Promise<void>;
    /**
     * Delete CIDRs from the MongoD Atlas API Key access list.
     * @param apiKeyId
     * @param currentAccessListEntries
     * @param awsIpRanges
     * @returns - An array of CIDRs successfully deleted.
     */
    deleteCidrs(apiKeyId: string, currentAccessListEntries: string[], awsIpRanges: ltypes.AwsIpRange[]): Promise<string[]>;
    /**
     * Use the MongoDB Atlas administrative API to delete access list entries.
     * @param apiKeyId
     * @param entryValue
     */
    deleteApiKeyAccessListEntry(apiKeyId: string, entryValue: string): Promise<void>;
    /**
     * Get the MongoDB Atlas AWS Secrets Manager secret.
     * This is the standard secret required by MongoDB Atlas to use the AWS CDK.
     * Check that the secret exists and has values for all requied properties.
     * The ApiKeyId property is non-standard but required by Jompx to manage API Key access list entries.
     * @param region
     * @param profile
     * @returns
     */
    getProfileSecretValue(region: string, profile: string): Promise<ltypes.MongoDbAtlasProfileSecretValue | undefined>;
}
