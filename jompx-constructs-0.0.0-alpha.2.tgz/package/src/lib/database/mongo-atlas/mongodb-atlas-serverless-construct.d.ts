import * as cdk from 'aws-cdk-lib';
import * as atlas from 'awscdk-resources-mongodbatlas';
import { Construct } from 'constructs';
export interface MongoDbAtlasServerlessProps {
    region: string;
    /**
     * Unique 24-hexadecimal digit string that identifies the Atlas project.
     */
    projectId: string;
    /**
     * Profile to use for credentials. An AWS Secrets Manager secret with name: cfn/atlas/profile/{Profile}
     */
    profile: string;
    /**
     * MongoDB Atlas serverless instance name (unique to the project).
     */
    instanceName: string;
    defaultDatabaseName: string;
    vpc: cdk.aws_ec2.IVpc;
    /**
     * Security best practice is to use private isolated subnets (at least two that span AZs for redundancy).
     * e.g. { subnetType: ec2.SubnetType.PRIVATE_ISOLATED }
     */
    vpcSubnets: cdk.aws_ec2.SubnetSelection;
    terminationProtectionEnabled?: boolean;
    continuousBackupEnabled?: boolean;
    /**
     * Default = admin.
     */
    adminDatabaseUsername?: string;
    adminDatabaseUserSecretName?: string;
    /**
     * Default = dba.
     */
    dbaDatabaseUsername?: string;
    dbaDatabaseUserSecretName?: string;
}
/**
 * MongoDB Atlas serverless.
 *  - Develop or test in a cloud environment.
 *  - Have your database scale automatically and dynamically to meet your workload.
 *  - Run infrequent or sparse workloads.
 * Requires boostrap activation types: Project, ServerlessInstance, ServerlessPrivateEndpoint.
 * Warning: Not all AWS regions are supported: https://www.mongodb.com/docs/atlas/reference/amazon-aws/
 * Creates one admin user (for administrator tasks) and one dba user (for CI/CD) with access to all databases in the cluster.
 * https://www.mongodb.com/docs/atlas/create-database-deployment/#std-label-ref-deployment-types
 */
export declare class MongoDbAtlasServerless extends Construct {
    serverlessInstance: atlas.CfnServerlessInstance;
    adminDatabaseUserSecret: cdk.aws_secretsmanager.Secret;
    adminDatabaseUser: atlas.CfnDatabaseUser;
    dbaDatabaseUserSecret: cdk.aws_secretsmanager.Secret;
    dbaDatabaseUser: atlas.CfnDatabaseUser;
    constructor(scope: Construct, id: string, props: MongoDbAtlasServerlessProps);
}
