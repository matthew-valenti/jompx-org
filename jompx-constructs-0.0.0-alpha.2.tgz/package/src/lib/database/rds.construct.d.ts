import * as cdk from 'aws-cdk-lib';
import { Construct } from 'constructs';
import { RdsProxy } from './rds-proxy.construct';
export interface RdsProps {
    /**
     * The CloudFormation removal policy for the DB instance.
     *
     * @default cdk.RemovalPolicy.RETAIN
     */
    removalPolicy?: cdk.RemovalPolicy;
    /**
     * An identifier for the instance.
     * e.g. `rds-postgres-${environment.name}`
     */
    instanceIdentifier: string;
    /**
     * The database engine to use. e.g. rds.DatabaseInstanceEngine.postgres({ version: rds.PostgresEngineVersion.VER_16_2 })
     */
    engine: cdk.aws_rds.IInstanceEngine;
    /**
     * The instance type of the RDS instance e.g. ec2.InstanceType.of(ec2.InstanceClass.BURSTABLE4_GRAVITON, ec2.InstanceSize.MICRO)
     */
    instanceType: cdk.aws_ec2.InstanceType;
    storage: {
        /**
         * The allocated storage size, specified in gibibytes (GiB).
         *
         * @default 20
         */
        allocatedStorage?: number;
        /**
         * Upper limit to which RDS can scale the storage in GiB(Gibibyte).
         */
        maxAllocatedStorage: number;
        /**
         * The storage type.
         *
         * @default gp3
         */
        storageType?: cdk.aws_rds.StorageType;
        /**
         * Use a customer-managed KMS key for RDS storage encryption at rest.
         * RDS storage remains encrypted either way; this controls whether you use your own KMS key
         * instead of the default AWS-managed key. This is a low-cost choice that is worth making up front
         * if you expect stricter audit/compliance requirements later, because changing keys later is
         * operationally awkward.
         *
         * @default false
         */
        useCustomerManagedKmsKey?: boolean;
    };
    /**
     * Enable RDS Proxy for Lambda-style SQL workloads.
     *
     * @default false
     */
    proxy?: boolean;
    vpc: cdk.aws_ec2.IVpc;
    /**
     * Security best practice is to use private isolated subnets (and at least two that span AZs for redundancy).
     * e.g. { subnetType: ec2.SubnetType.PRIVATE_ISOLATED }
     */
    vpcSubnets: cdk.aws_ec2.SubnetSelection;
    /**
     * Default = dbadmin.
     */
    adminDatabaseUsername?: string;
    /**
     * Whether to enable mapping of AWS Identity and Access Management (IAM) accounts to database accounts.
     *
     * Default = true
     */
    iamAuthentication?: boolean;
    /**
     * The number of days during which automatic DB snapshots are retained. Set to cdk.Duration.days(0) to disable backups.
     *
     * Default = 7 days.
     */
    backupRetention?: cdk.Duration;
    /**
     * The daily time range during which automated backups are performed.
     * e.g. '03:00-03:30'
     *
     * Default = a 1-hour window selected at random from an 8-hour block of time for each AWS Region.
     */
    preferredBackupWindow?: string;
    /**
     * The weekly time range (in UTC) during which system maintenance can occur. Set after backups, non-overlapping
     * e.g. 'sun:04:00-sun:04:30'
     *
     * Default = A 30-minute window selected at random from an 8-hour block of time for each AWS Region
     */
    preferredMaintenanceWindow?: string;
    parameterGroupParameters?: {
        [key: string]: string;
    };
    cloudwatchLogs?: {
        /**
         * The list of log types that need to be enabled for exporting to CloudWatch Logs.
         *
         * Default = Low-cost, high-signal defaults per engine e.g. errors.
         */
        exports?: string[];
        /**
         * The number of days log events are kept in CloudWatch Logs.
         *
         * Default = ONE_MONTH
         */
        retention?: cdk.aws_logs.RetentionDays;
    };
}
export type FamilyKind = 'postgres' | 'mysql' | 'oracle' | 'sqlserver' | 'other';
/**
 * RDS instance with a least-privilege client security group and secure defaults for AWS-native workloads.
 *
 * Security:
 * - The instance is created in the supplied VPC subnets and is not publicly accessible.
 * - Attach the exposed `clientSecurityGroup` to trusted clients that need database access.
 * - Direct connections from outside AWS typically require a VPN, bastion, or similar private network path.
 *
 * Operations:
 * - Apply database schema changes separately via the framework's database migration Store, Executor, and Orchestrator constructs.
 *
 * Cost:
 * - Base RDS pricing is separate from backup storage, CloudWatch logs, and any optional customer-managed KMS key.
 * - Secrets Manager rotation and RDS Proxy add incremental monthly cost.
 *
 * Security Group Lookup Example:
 * const clientSecurityGroup = ec2.SecurityGroup.fromSecurityGroupId(
 *   this,
 *   'ClientSecurityGroup',
 *   clientSecurityGroupId
 * );
 */
export declare class Rds extends Construct {
    instance: cdk.aws_rds.DatabaseInstance;
    proxy: RdsProxy | undefined;
    dbSecurityGroup: cdk.aws_ec2.SecurityGroup;
    clientSecurityGroup: cdk.aws_ec2.SecurityGroup;
    parameterGroup: cdk.aws_rds.ParameterGroup;
    storageEncryptionKey: cdk.aws_kms.Key | undefined;
    constructor(scope: Construct, id: string, props: RdsProps);
}
