import * as cdk from 'aws-cdk-lib';
import * as logs from 'aws-cdk-lib/aws-logs';
import * as route53 from 'aws-cdk-lib/aws-route53';
import { Construct } from 'constructs';
export interface ClientVpnSsoProps {
    accountId: string;
    cidr: string;
    vpc: cdk.aws_ec2.IVpc;
    vpcSubnets: cdk.aws_ec2.SubnetSelection;
    /**
     * e.g. 'arn:aws:iam::account:saml-provider/provider-name'
     */
    samlProviderName: string;
    rootDomainName: string;
    /**
     * Number of days to retain CloudWatch logs.
     */
    logRetentionDays: logs.RetentionDays;
    /**
     * Use security groups to allow client VPN access to specific resources only.
     */
    securityGroups?: cdk.aws_ec2.ISecurityGroup[];
    /**
     * If not provided, will be set to the default DNS server for a VPC provided by AWS.
     * It is the base of the VPC network range plus two. e.g. 10.3.0.2 for the network account.
     */
    dnsServers?: string[];
    /**
     * Defaults to 443.
     */
    port?: number;
    /**
     * If true, only traffic intended for the VPC will traverse the VPN tunnel.
     * All other traffic, such as internet traffic would not traverse the tunnel.
     * In many cases, this is preferred since it reduces the overall traffic over the VPN.
     */
    splitTunnel?: boolean;
    restrictCertificateAuthorities?: boolean;
    clientLoginBanner?: string;
}
/**
 * Create a Client VPN for use with AWS SSO.
 * VPN connection domain = vpn.<rootDomainName>
 *
 * Using AWS SSO with AWS Client VPN for authentication and authorization:
 * https://aws.amazon.com/blogs/networking-and-content-delivery/using-aws-sso-with-aws-client-vpn-for-authentication-and-authorization/
 *
 * By default, all SSO groups with client VPN access can access all resources.
 * Authorizations can be used to govern which groups have access to what resources. e.g. The developer group has access to the Aurora database but not the EC2 instance.
 * The CDK doesn't support the set up of who can access the VPN based on their group in AWS SSO.
 * So do this using the AWS CLI, SDK, or the AWS Management Console.
 * Consider adding this feature to this construct using a CDK custom resource.
 */
export declare class ClientVpnSso extends Construct {
    publicHostedZone: route53.IHostedZone;
    certificate: cdk.aws_certificatemanager.Certificate;
    logGroup: cdk.aws_logs.LogGroup;
    clientVpnEndpoint: cdk.aws_ec2.ClientVpnEndpoint;
    caaAmazonRecord: route53.CaaAmazonRecord | undefined;
    constructor(scope: Construct, id: string, props: ClientVpnSsoProps);
}
