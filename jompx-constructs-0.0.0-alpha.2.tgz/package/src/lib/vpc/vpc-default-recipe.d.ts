import * as ec2 from 'aws-cdk-lib/aws-ec2';
import { Construct } from 'constructs';
export interface VpcProps {
    accountId: string;
    region: string;
    cidrBlock: string;
    cidrPrefixLength?: number;
    /**
     * Allows lookup of this VPC by tag.
     */
    key?: string;
}
/**
 * This is a VPC to generally use across all AWS accounts.
 * Manually delete the default VPC that is provided by default in new AWS accounts.
 * Using a CDK managed VPC is preferrable because IAC can be used to manage VPC setup and configuration.
 */
export declare class Vpc extends Construct {
    vpc: ec2.Vpc;
    constructor(scope: Construct, id: string, props: VpcProps);
}
