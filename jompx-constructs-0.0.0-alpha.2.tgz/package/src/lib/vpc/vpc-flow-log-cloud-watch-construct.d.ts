import * as cdk from 'aws-cdk-lib';
import * as ec2 from 'aws-cdk-lib/aws-ec2';
import { Construct } from 'constructs';
export interface VpcFlowLogCloudWatchProps {
    vpc?: ec2.IVpc;
    subnet?: ec2.ISubnet;
    networkInterfaceId?: string;
    retentionDays?: cdk.aws_logs.RetentionDays;
    flowLogName?: string;
}
/**
 * Create a VPC Flow Log that logs to CloudWatch.
 */
export declare class VpcFlowLogCloudWatch extends Construct {
    flowLog?: cdk.aws_ec2.FlowLog;
    logGroup?: cdk.aws_logs.LogGroup;
    constructor(scope: Construct, id: string, props: VpcFlowLogCloudWatchProps);
}
