import * as ec2 from 'aws-cdk-lib/aws-ec2';
import { Construct } from 'constructs';
export interface VpcProps {
    accountId: string;
    region: string;
    cidrBlock: string;
    cidrPrefixLength?: number;
    /**
     * Allows lookup of this VPC by tag.
     */
    key?: string;
}
/**
 * This VPC is designed to be deployed to the network AWS account only.
 * It's a copy/paste of the default VPC construct with:
 * - Dedicated subnets for client VPN access.
 */
export declare class Vpc extends Construct {
    vpc: ec2.Vpc;
    constructor(scope: Construct, id: string, props: VpcProps);
}
