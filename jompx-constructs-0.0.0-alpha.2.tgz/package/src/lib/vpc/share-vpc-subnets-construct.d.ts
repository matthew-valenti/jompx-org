import * as cdk from 'aws-cdk-lib';
import * as ec2 from 'aws-cdk-lib/aws-ec2';
import { Construct } from 'constructs';
export interface ShareVpcSubnetsProps {
    accountId: string;
    region: string;
    selectedSubnets: ec2.SelectedSubnets;
    principals: string[];
    name?: string;
}
/**
 * Share VPC subnets with other AWS accounts.
 */
export declare class ShareVpcSubnets extends Construct {
    resourceShare: cdk.aws_ram.CfnResourceShare;
    constructor(scope: Construct, id: string, props: ShareVpcSubnetsProps);
}
