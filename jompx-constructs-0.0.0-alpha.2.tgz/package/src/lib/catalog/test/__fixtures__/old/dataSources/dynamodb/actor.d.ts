import * as jompx from '@jompx/constructs';
export declare const actorEntity: jompx.CatalogEntity;
