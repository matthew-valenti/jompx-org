import * as jompx from '@jompx/constructs';
export declare const commonAttributes: jompx.CatalogCommonAttribute;
