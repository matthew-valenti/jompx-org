import * as jompx from '@jompx/constructs';
export declare const mongodbEntities: jompx.CatalogEntity;
