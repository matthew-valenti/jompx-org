import * as jompx from '@jompx/constructs';
export declare const mysqlEntities: jompx.CatalogEntity;
