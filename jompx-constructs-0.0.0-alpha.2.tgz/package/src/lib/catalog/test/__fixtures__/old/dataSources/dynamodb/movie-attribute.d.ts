import * as jompx from '@jompx/constructs';
export declare const movieAttributeEntity: jompx.CatalogEntity;
