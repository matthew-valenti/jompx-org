import * as jompx from '@jompx/constructs';
export declare const fileEntity: jompx.CatalogEntity;
