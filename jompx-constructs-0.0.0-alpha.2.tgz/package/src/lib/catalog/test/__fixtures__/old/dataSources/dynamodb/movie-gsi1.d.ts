import * as jompx from '@jompx/constructs';
export declare const movieGsi1Entity: jompx.CatalogEntity;
