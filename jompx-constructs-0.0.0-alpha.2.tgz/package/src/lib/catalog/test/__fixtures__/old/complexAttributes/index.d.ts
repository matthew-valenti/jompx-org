import * as jompx from '@jompx/constructs';
export declare const complexAttributes: jompx.CatalogComplexAttribute;
