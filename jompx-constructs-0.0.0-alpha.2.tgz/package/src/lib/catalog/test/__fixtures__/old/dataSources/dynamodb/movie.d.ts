import * as jompx from '@jompx/constructs';
export declare const movieEntity: jompx.CatalogEntity;
