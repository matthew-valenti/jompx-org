import * as jompx from '@jompx/constructs';
export declare const enums: jompx.CatalogEnum;
