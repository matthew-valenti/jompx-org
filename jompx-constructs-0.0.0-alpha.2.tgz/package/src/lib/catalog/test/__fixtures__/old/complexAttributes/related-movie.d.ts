import * as jompx from '@jompx/constructs';
export declare const relatedMovie: jompx.CatalogComplexAttribute;
