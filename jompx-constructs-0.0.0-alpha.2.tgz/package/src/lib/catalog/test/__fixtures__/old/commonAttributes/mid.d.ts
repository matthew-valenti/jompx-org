import { CatalogCommonAttribute } from '@jompx/constructs';
export declare const mid: CatalogCommonAttribute;
