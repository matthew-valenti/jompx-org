import { CatalogCommonAttribute } from '@jompx/constructs';
export declare const id: CatalogCommonAttribute;
