import * as jompx from '@jompx/constructs';
export declare const mysqlComplexAttributes: jompx.CatalogComplexAttribute;
