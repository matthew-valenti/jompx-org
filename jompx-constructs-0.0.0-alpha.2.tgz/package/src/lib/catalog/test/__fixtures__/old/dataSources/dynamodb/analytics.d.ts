import * as jompx from '@jompx/constructs';
export declare const analyticsEntity: jompx.CatalogEntity;
