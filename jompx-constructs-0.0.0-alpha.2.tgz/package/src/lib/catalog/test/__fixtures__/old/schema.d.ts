import * as jompx from '@jompx/constructs';
export declare const schema: jompx.Catalog;
