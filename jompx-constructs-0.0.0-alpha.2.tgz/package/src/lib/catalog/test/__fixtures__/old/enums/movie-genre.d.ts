import { CatalogEnum } from '@jompx/constructs';
export declare const movieGenre: CatalogEnum;
