import * as jompx from '@jompx/constructs';
export declare const dynamodbEntities: jompx.CatalogEntity;
