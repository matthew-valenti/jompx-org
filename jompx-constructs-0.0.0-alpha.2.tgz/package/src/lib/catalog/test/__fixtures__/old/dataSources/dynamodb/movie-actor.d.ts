import * as jompx from '@jompx/constructs';
export declare const movieActorEntity: jompx.CatalogEntity;
