import { CatalogCommonAttribute } from '@jompx/constructs';
export declare const audit: CatalogCommonAttribute;
