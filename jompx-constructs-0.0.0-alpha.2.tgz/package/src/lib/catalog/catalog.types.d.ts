import { z } from 'zod';
export interface Catalog {
    /**
     * Version of the catalog using semantic versioning (e.g., '1.0.0').
     */
    version: string;
    /**
     * A datasource is a collection of entities and attributes.
     * Create a datasource for each database (e.g. MySQL, MongoDB etc.) and/or each system (e.g. WordPress, Salesforce, etc.)
     */
    datasources: CatalogDatasource;
    /**
     * Reusable attributes shared across multiple entities.
     * Example: `id`, `createdAt`, `updatedAt` used in many entities.
     * Usage: An entity includes common attributes via `commonAttributes: ["id", "timestamp"]`.
     */
    commonAttributes?: CatalogCommonAttribute;
    /**
     * Define reusable complex attributes that contain nested attributes and relationships.
     * For use with MongoDB embedded documents, DynamoDB nested attributes, and SQL JSON columns.
     * Example: { name, email, address: { street, city, state, zip } }
     * Usage: An entity attribute can be of type 'complexAttributes' to represent structured data.
     */
    complexAttributes?: CatalogComplexAttribute;
    /**
     * Enumerations representing predefined lists of values.
     */
    enums?: CatalogEnum;
    /**
     * An API is a collection of endpoints.
     * API CRUD endpoints can be progrmatically created from catalog.
     */
    apis?: CatalogApi;
}
/**
 * Meta data as key/value pairs.
 * Use meta data to further describe entities, attributes, relationships, and common attributes.
 * Consider using meta to document any of the following:
 * Data Usage and Purpose: Documents the intended use of the attribute, such as analytics, reporting, or operational purposes.
 * Lineage: Captures and tracks the origin and history of the attribute's data, including source systems and transformations applied.
 * Data Security Classification: Assigns security levels, such as confidential or restricted, and notes related compliance requirements or access controls.
 * Data Ownership and Stewardship: Records the entity or individual responsible for maintaining and overseeing the attribute, such as a department or person.
 * Data Quality Metrics: Tracks the attribute's quality, including metrics like completeness, accuracy, timeliness, and validity of the data.
 * Data Lifecycle Management: Governs retention periods, archival policies, and deletion rules, typically for compliance and data governance purposes.
 * Internationalization and Localization: Describes locale-specific settings, such as language, currency, or date formats for the attribute.
 * Data Update Frequency: Specifies how often the attribute's data is updated, such as real-time, daily, or monthly.
 * Versions (Historical Data Handling): Indicates whether historical versions of the data are retained, and if so, how those versions are handled or accessed.
 * Security: Defines rules to protect the attribute, such as access control, confidentiality, or encryption.
 * Event Metadata for Streaming Data: Captures details specific to event-driven systems, such as event type, timestamps, and any associated metadata for streaming data.
 * Data Transformation Rules: Defines any transformations applied to the attribute data, such as calculated fields, normalization, or data enrichment processes.
 */
export interface CatalogMeta {
    [metaKey: string]: unknown;
}
/**
 * A unique common attribute name that defines a set of attributes.
 * Include a common set of attributes across entities e.g. id, createdAt, createdBy, updatedAt, updatedBy
 */
export interface CatalogCommonAttribute {
    [commonAttributeName: string]: CatalogCommonAttributeProps;
}
/**
 * Set of attributes for a common attribute key.
 */
export interface CatalogCommonAttributeProps {
    attributes: CatalogAttribute;
    api?: CatalogCommonAttributeApi;
}
/**
 * Api common attribute level properties for auto generation of API endpoints.
 */
export interface CatalogCommonAttributeApi {
    /**
     * Include the attribute in APIs.
     */
    includeInApis?: string[];
}
/**
 * A unique name that defines a complex attribute.
 */
export interface CatalogComplexAttribute {
    [complexAttributeName: string]: CatalogComplexAttributeProps;
}
/**
 * Complex attribute properties.
 */
export interface CatalogComplexAttributeProps {
    /**
     * Attributes within a complex attribute.
     */
    attributes: CatalogAttribute;
    /**
     * Reference attributes that are common across entities by name.
     * Define a set of common attributes and assign them to entities instead of duplicating attributes.
     */
    commonAttributes?: string[];
    /**
     * Relationships (or joins) between entities.
     */
    relationships?: CatalogRelationship;
    /**
     * Entity authorization properties.
     */
    authorization?: CatalogComplexAttributeAuthorization;
    api?: CatalogComplexAttributeApi;
}
/**
 * Fine grained authorization.
 */
export interface CatalogComplexAttributeAuthorization {
    /**
     * Include this entity in the authorization Cedar catalog.
     * Only include entities that are necessary for writing authorization rules.
     */
    includeInCatalog: boolean;
    /**
     * Custom defined labels for use in authorization rules.
     * These labels can guide access control, security policies, and compliance.
     * Common examples:
     * phi: Sensitive health-related data subject to regulations like HIPAA.
     * pii: Data that can be used to identify an individual.
     * encrypted: Indicates that the data must be encrypted.
     * private: Internal data that should not be shared externally.
     */
    labels?: string[];
}
/**
 * Api common attribute level properties for auto generation of API endpoints.
 */
export interface CatalogComplexAttributeApi {
    /**
     * Include the attribute in APIs.
     */
    defaultIncludeInApis?: string[];
}
/**
 * A unique enum name that defines an enum.
 */
export interface CatalogEnum {
    [enumName: string]: CatalogEnumProps;
}
/**
 * Set of properties that defines an enum.
 */
export interface CatalogEnumProps {
    /**
     * Enum description.
     */
    description?: string;
    /**
     * Enum values.
     */
    values: CatalogEnumValue[];
    api?: CatalogEnumApi;
}
/**
 * Api enum level properties for auto generation of API endpoints.
 */
export interface CatalogEnumApi {
    /**
     * Include the attribute in APIs.
     */
    includeInApis?: string[];
}
/**
 * Set of properties that defines an enum.
 */
export interface CatalogEnumValue {
    /**
     * Enum values.
     */
    value: string;
    /**
     * Enum value description.
     */
    description?: string;
}
/**
 * A unique API name that defines a GraphQL API.
 */
export interface CatalogApi {
    [apiName: string]: CatalogApiProps;
}
/**
 * API CRUD operation names.
 */
export type ApiType = 'rest' | 'graphql';
/**
 * Set of properties that defines an API.
 */
export interface CatalogApiProps {
    /**
     * API type e.g. rest, graphql.
     */
    type: ApiType;
    /**
     * Root domain name for the API. e.g. jompx.com
     */
    rootDomain: string;
    /**
     * Subdomain for the API. e.g. 'api' creates 'api.jompx.com'
     */
    subdomain: string;
    /**
     * Optional metadata about the API.
     */
    meta?: CatalogMeta;
}
/**
 * A unique datasource name that defines a datasource.
 */
export interface CatalogDatasource {
    [datasourceName: string]: CatalogDatasourceProps;
}
/**
 * Set of properties that defines a datasource.
 */
export interface CatalogDatasourceProps {
    /**
     * Entities in the data source.
     */
    entities: CatalogEntity;
    /**
     * Data source type e.g. Aurora MySQL, MongoDB, WordPress, Salesforce.
     */
    type?: string;
    /**
     * Datasource specific API properties.
     */
    api?: CatalogDataSourceApi;
    /**
     * Optional metadata about the data source.
     */
    meta?: CatalogMeta;
}
export type ApiPaginationType = 'offset' | 'cursor';
/**
 * API datasource level properties for auto generation of API endpoints.
 */
export interface CatalogDataSourceApi {
    /**
     * API datasource to use for API operations.
     */
    datasourceId: string;
    /**
     * Default pagination type for find operations on datasource entities.
     */
    defaultPaginationType: ApiPaginationType;
}
/**
 * A unique entity name that defines an entity.
 */
export interface CatalogEntity {
    [entityName: string]: CatalogEntityProps;
}
/**
 * Entity properties.
 */
export interface CatalogEntityProps {
    /**
     * Attributes within an entity.
     */
    attributes: CatalogAttribute;
    /**
     * Reference attributes that are common across entities by name.
     * Define a set of common attributes and assign them to entities instead of duplicating attributes.
     */
    commonAttributes?: string[];
    /**
     * Relationships (or joins) between entities.
     */
    relationships?: CatalogRelationship;
    /**
     * Entity datasource index properties.
     */
    indexes?: CatalogEntitySqlIndex[] | CatalogEntityMongodbIndex[] | [CatalogEntityDynamodbIndex[]];
    /**
     * Entity authorization properties.
     */
    authorization?: CatalogEntityAuthorization;
    /**
     * Define validation rules at the entity level using Zod.
     * This function is used in conjunction with Zod's `refine()` or `superRefine()` methods, enabling
     * validation logic that spans multiple attributes within an entity.
     * @param data - Parsed object containing all attributes of the entity.
     * @param ctx - Zod Refinement context. Useful for reporting validation errors and custom error messages.
     * @returns void
     *
     * Example1: Using `refine()` for single field validation:
     * validationRules?: (data, ctx) => {
     *   z.object({
     *     age: z.number().refine((val) => val >= 18, {
     *       message: "Age must be 18 or above",
     *     })
     *   });
     * }
     *
     * Example2: Using `superRefine()` for multi field validation:
     * validationRules?: (data, ctx) => {
     *   z.object({
     *     password: z.string(),
     *     confirmPassword: z.string(),
     *   }).superRefine((data, ctx) => {
     *     if (data.password !== data.confirmPassword) {
     *       ctx.addIssue({
     *         code: z.ZodIssueCode.custom,
     *         message: "Passwords do not match",
     *         path: ["confirmPassword"], // Points to the specific field
     *       });
     *     }
     *   });
     * }
     */
    validationRules?: ((data: any) => void) | ((data: any, ctx: z.RefinementCtx) => void);
    /**
     * Physical name of the entity to use in data operations.
     * Use this if the physical name differs from the logical attribute name.
     */
    physicalName?: string;
    /**
     * Reference the name of another database entity (e.g., table, index, or view) required for operations.
     * For use with: DynamoDB GSI, PostgreSQL materialized view, and Elasticsearch child index.
     */
    compositeEntityName?: string;
    /**
     * Entity specific API properties.
     */
    api?: CatalogEntityApi;
    /**
     * Optional metadata about the entity.
     */
    meta?: CatalogMeta;
}
/**
 * Entity index by datasource type.
 */
/**
 * SQL indexes.
 */
export interface CatalogEntitySqlIndex {
    type: 'primary' | 'unique' | 'index' | 'fulltext';
    attributeNames: string[];
    /**
     * The most common create index options only.
     */
    options?: {
        order?: 'asc' | 'desc';
    };
}
/**
 * MongoDB indexes.
 */
export interface CatalogEntityMongodbIndex {
    type: 1 | -1;
    attributeNames: string[];
    /**
     * The most common create index options only.
     */
    options?: {
        unique?: boolean;
        expireAfterSeconds?: number;
        sparse?: boolean;
    };
}
/**
 * DynamoDB indexes.
 */
export interface CatalogEntityDynamodbIndex {
    type: 'GSI' | 'LSI';
    partitionKey: string;
    sortKey: string;
    options?: {
        projection?: 'ALL' | 'KEYS_ONLY' | 'INCLUDE';
    };
}
/**
 * Fine grained authorization.
 */
export interface CatalogEntityAuthorization {
    /**
     * Include this entity in the authorization Cedar catalog.
     * Only include entities that are necessary for writing authorization rules.
     */
    includeInCatalog: boolean;
    /**
     * Custom defined labels for use in authorization rules.
     * These labels can guide access control, security policies, and compliance.
     * Common examples:
     * phi: Sensitive health-related data subject to regulations like HIPAA.
     * pii: Data that can be used to identify an individual.
     * encrypted: Indicates that the data must be encrypted.
     * private: Internal data that should not be shared externally.
     */
    labels?: string[];
}
/**
 * API entity level properties for auto generation of API endpoints.
 */
export interface CatalogEntityApi {
    /**
     * Prefix to add to an entity name to make it globally unique across all entities.
     * e.g. Used to generate API entity endpoint names.
     */
    entityNamePrefix?: string;
    /**
     * API operations to auto generate.
     */
    operations?: ApiOperation[];
    /**
     * Default value for entity attributes that do not have an explicit includeInApis value.
     */
    defaultIncludeInApis?: string[];
    /**
     * Pagination type for find operations on the entity.
     */
    paginationType?: ApiPaginationType;
}
/**
 * API operation.
 */
export interface ApiOperation {
    /**
     * The type of API operation to auto created.
     */
    type: ApiOperationType;
    /**
     * Provide a reason why the operation is to be deprecated.
     */
    deprecatedReason?: string;
}
/**
 * API CRUD operation names.
 */
export type ApiOperationType = 'find' | 'findOne' | 'insertOne' | 'insertMany' | 'upsertOne' | 'upsertMany' | 'updateOne' | 'updateMany' | 'deleteOne' | 'deleteMany' | 'search';
/**
 * A unique relationship name that defines a relationship between two entities.
 */
export interface CatalogRelationship {
    [relationshipName: string]: CatalogRelationshipProps;
}
/**
 * Defines relationship properties between entities.
 */
export interface CatalogRelationshipProps {
    /**
     * The related entity in the relationship.
     */
    relatedEntity: string;
    /**
     * The datasource that the entity belongs to.
     * If not specified, the foreign entity datasource will be the same as the local entity datasource.
     */
    relatedEntityDatasource?: string;
    /**
     * Specifies the type of relationship between entities. e.g. 1-1, 1-N, N-1.
     * - 1-1: One A to one B.
     * e.g. A **user** has one **profile**, and each profile belongs to one user.
     * - 1-N: One A to many B, each B to one A.
     * e.g.: A **user** can have many **posts**, but each post belongs to one user.
     * - N-1: Many A to one B, each B to many A.
     * e.g. Many **posts** belong to one **user**, but each user can have many posts.
     */
    type: CatalogRelationshipType;
    /**
     * Defines the allowed number of related entities. e.g. 0, 1.
     * - '0': Optional relationship, no related entities required.
     * e.g. A **user** may or may not have multiple **posts**.
     * - '1': Mandatory relationship, exactly one related entity required.
     * e.g. A **post** must have exactly one **user** (author).
     */
    cardinality: CatalogCardinalityType;
    /**
     * Condition governing the relationship (simple or complex expression).
     */
    condition: CatalogRelationshipConditionSimple | CatalogRelationshipConditionComplex;
    /**
     * Attribute authorization properties.
     */
    authorization?: CatalogAttributeAuthorization;
    /**
     * Attribute specific API properties.
     */
    api?: CatalogRelationshipApi;
}
/**
 * Specifies the type of relationship between entities.
 * - '1-1': One-to-One, each entity relates to exactly one other entity.
 * - '1-N': One-to-Many, one entity relates to multiple other entities.
 * - 'N-1': Many-to-One, multiple entities relate to one other entity.
 */
export type CatalogRelationshipType = '1-1' | '1-N' | 'N-1';
/**
 * Defines the number of related entities allowed in a relationship.
 * - '0': Optional relationship, no related entities required.
 * - '1': Mandatory relationship, exactly one related entity required.
 */
export type CatalogCardinalityType = '0' | '1';
/**
 * Simple relationship condition e.g. id = userId
 * e.g. Join movie to movieActor table: localField = id, foreignField = movieId
 */
export interface CatalogRelationshipConditionSimple {
    localField: string;
    foreignField: string;
}
/**
 * Complex relationship condition. e.g. Join movie to movieActor table.
 * let: { mongoDbMovie_id: '$_id' },
 * condition: [
 *   {
 *     $match: {
 *       $expr: {
 *         $eq: ['$movieId', '$$mongoDbMovie_id'],
 *       },
 *     },
 *   },
 * ]
 */
export interface CatalogRelationshipConditionComplex {
    /**
     * MongoDB aggregation pipeline variable syntax.
     * e.g. let: { localVariable: '$localField' },
     */
    let: object;
    /**
     * MongoDB aggregation pipeline syntax.
     * e.g.
     * [
     *   {
     *     $match: {
     *       $expr: {
     *         $eq: ['$movieId', '$$mongoDbMovie_id'],
     *       },
     *     },
     *   },
     * ]
     */
    pipeline: object[];
}
/**
 * Api relationship level properties for auto generation of API endpoints.
 */
export interface CatalogRelationshipApi {
    /**
     * Include the relationship as an entity attribute in APIs.
     */
    includeInApis?: string[];
    /**
     * Provide a reason why the relationship attribute is to be deprecated.
     */
    deprecatedReason?: string;
}
/**
 * A unique attribute name that defines an attribute.
 */
export interface CatalogAttribute {
    [attributeName: string]: CatalogAttributeProps;
}
/**
 * Attribute properties.
 */
export interface CatalogAttributeProps {
    /**
     * Physical name of the attribute to use in data operations.
     */
    physicalName?: string;
    /**
     * Attribute validation policy (for documentation purposes only).
     */
    validationPolicy?: CatalogAttributeValidationPolicy;
    /**
     * Attribute authorization properties.
     */
    authorization?: CatalogAttributeAuthorization;
    /**
     * Define validation rules at the attribute level using Zod.
     *
     * Example: z.string().min(3, "Must be at least 3 characters").max(7, "Must be 7 characters or less")
     */
    validationRules?: z.ZodTypeAny;
    /**
     * Define complex attributes that contain nested attributes and relationships.
     * For use with MongoDB embedded documents, DynamoDB nested attributes, and SQL JSON columns.
     * Example: { name, email, address: { street, city, state, zip } }
     * Usage: An entity attribute can be of type 'inlineComplexAttribute' to represent structured data.
     */
    complexAttribute?: CatalogComplexAttributeProps;
    /**
     * Attribute specific API properties.
     */
    api?: CatalogAttributeApi;
    /**
     * Optional metadata about the attribute.
     */
    meta?: CatalogMeta;
}
/**
 * Fine grained authorization.
 */
export interface CatalogAttributeAuthorization {
    /**
     * Include this attribute in the authorization Cedar catalog.
     * Only include attributes that are necessary for writing authorization rules.
     */
    includeInCatalog: boolean;
    /**
     * Authorization Cedar attribute data type.
     */
    dataType?: string;
    /**
     * Custom defined labels for use in authorization rules.
     * These labels can guide access control, security policies, and compliance.
     * Common examples:
     * phi: Sensitive health-related data subject to regulations like HIPAA.
     * pii: Data that can be used to identify an individual.
     * encrypted: Indicates that the data must be encrypted.
     * private: Internal data that should not be shared externally.
     */
    labels?: string[];
}
/**
 * Authorization Cedar attribute data types.
 */
export type CatalogAuthorizationDataType = 'Bool' | 'String' | 'Long' | 'Set' | 'Record' | 'decimal' | 'ipaddr';
/**
 * API attribute level properties for auto generation of API endpoints.
 */
export interface CatalogAttributeApi {
    /**
     * API attribute data type.
     */
    returnType: CatalogAttributeApiReturnType;
    returnTypeOptions?: ApiReturnTypeOptions;
    isReadOnly?: boolean;
    validationRules?: z.ZodTypeAny;
    /**
     * API default value.
     * There is no attribute level default value because if API defaults the value we don't want the database layer to default the value.
     */
    defaultValue?: CatalogAttributeDefaultValue;
    /**
     * Provide a reason why the attribute is to be deprecated.
     */
    deprecatedReason?: string;
    /**
     * Include the attribute in APIs.
     */
    includeInApis?: string[];
}
/**
 * API return data types.
 */
export type CatalogAttributeApiReturnType = 'id' | 'string' | 'int' | 'float' | 'boolean' | 'date' | 'time' | 'datetime' | 'timestamp' | 'email' | 'json' | 'url' | 'phone' | 'ipaddress' | {
    type: 'enum';
    name: string;
} | {
    type: 'enum';
    name: string;
    definition: CatalogEnum;
} | {
    type: 'complexAttribute';
    name: string;
} | {
    type: 'complexAttribute';
    name: string;
    definition: CatalogComplexAttributeProps;
};
/**
 * Attribute default values.
 */
export interface CatalogAttributeDefaultValue {
    /**
     * Attribute default value on insert.
     * e.g. { $ifNull: ['$$NOW'] }
     */
    onInsert?: object;
    /**
     * Attribute default value on update.
     * { $ifNull: ['$$NOW'] }
     */
    onUpdate?: object;
}
/**
 * API return type options.
 */
export interface ApiReturnTypeOptions {
    /**
     * Is a return value required.
     */
    isRequired?: boolean;
    /**
     * Is return value of type list.
     */
    isList?: boolean;
    /**
     * If return value is of type list is a list value required.
     */
    isRequiredList?: boolean;
}
/**
 * Attribute validation policy.
 * For documentation purposes only.
 * Reference for creating subsequent specific catalog.
 */
export interface CatalogAttributeValidationPolicy {
    /**
     * Generic data type.
     */
    dataType: CatalogAttributeValidationDataType;
    /**
     * Custom documentation rules by key.
     */
    rules: CatalogAttributeValidationPolicyRule[];
}
export type CatalogAttributeValidationDataType = 'string' | 'boolean' | 'integer' | 'decimal' | 'date' | 'datetime' | 'time' | 'array' | 'object' | 'binary';
/**
 * The validation policy document rules that strictly govern the correctness of data values at the point of entry or processing.
 */
export interface CatalogAttributeValidationPolicyRule {
    /**
     * Policy rule type.
     */
    type: CatalogAttributeValidationPolicyType;
    /**
     * Policy rule description.
     */
    description: string;
}
/**
 * allowedValues: Restricts the attribute to a predefined set of acceptable values.
 * compliance: Ensures the attribute meets regulatory, legal, or internal policy requirements.
 * defaultValue: Specifies a value to be automatically assigned if no value is provided.
 * dependency: Imposes conditions or relationships between attributes (e.g., one attribute's value depends on another).
 * encryption: Requires that the attribute's data be encrypted for security purposes.
 * format: Enforces a specific data format, such as email, date, or URL.
 * length: Limits the number of characters or elements for the attribute.
 * range: Restricts the attribute to a defined numerical range, specifying minimum and/or maximum values.
 * regex: Validates the attribute against a regular expression for pattern matching.
 * required: Indicates that the attribute must be present and cannot be omitted.
 * unique: Ensures the attribute's value is distinct and not repeated within a specified context.
 */
export type CatalogAttributeValidationPolicyType = 'allowedValues' | 'compliance' | 'defaultValue' | 'dependency' | 'encryption' | 'format' | 'length' | 'range' | 'regex' | 'required' | 'unique';
