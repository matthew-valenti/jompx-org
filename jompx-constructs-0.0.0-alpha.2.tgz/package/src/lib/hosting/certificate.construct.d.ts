import * as acm from 'aws-cdk-lib/aws-certificatemanager';
import { Construct } from 'constructs';
export interface CertificateProps {
    /**
     * Fully-qualified domain name to request a certificate for. May contain wildcards, such as *.domain.com.
     * Wildcard protects one subdomain level only e.g. *.example.com can protect login.example.com, and test.example.com, but it cannot protect test.login.example.com
     */
    domainName: string;
    enableCloudWatchAlarm?: boolean;
}
/**
 * Crate a wildcard certificate for a domain name.
 *
 * DNS auto validation with zone doesn't work! Dammed if you do, damned if you don't:
 * - Cannot centralize certificates.
 * - Do centralize hosted zones.
 * - Cannot lookup hosted zone from another account.
 * - Certificate must be on same account as resource e.g. AppSync.
 * - Auto DNS validation requires zone.
 * - No choice but do this manually. Deploy certificate. Get DNS from output. Create DNS records (manually or via a stack).
 *
 * Content of DNS Record is: {Name: _74d2edff4499c169c6ff13b790cdaca6.learnsnax.com.,Type: CNAME,Value: _56e06e67946aee886538890ad32ff34a.jkddzztszm.acm-validations.aws.}
 */
export declare class Certificate extends Construct {
    certificate: acm.Certificate;
    constructor(scope: Construct, id: string, props: CertificateProps);
}
