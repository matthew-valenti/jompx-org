import * as cdk from 'aws-cdk-lib';
import * as acm from 'aws-cdk-lib/aws-certificatemanager';
import * as cloudfront from 'aws-cdk-lib/aws-cloudfront';
import * as s3 from 'aws-cdk-lib/aws-s3';
import { Construct } from 'constructs';
export interface IHostingCloudFrontProps {
    organizationName: string;
    domainName: string;
    bucket: s3.Bucket;
    certificate: acm.Certificate;
    cachePolicyQueryStringAllowList: cloudfront.CacheQueryStringBehavior;
}
export declare class HostingCloudFront extends Construct {
    distribution: cdk.aws_cloudfront.Distribution;
    cachePolicy: cloudfront.CachePolicy;
    constructor(scope: Construct, id: string, props: IHostingCloudFrontProps);
}
