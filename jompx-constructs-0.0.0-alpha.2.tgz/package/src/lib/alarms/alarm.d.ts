import * as ltype from './alarm.types';
export declare class Alarm {
    /**
     * Format an alarm description in a standard way across all alarms.
     * Include additional machine parsable and human readable properties
     * @param environmentName - Environment name e.g. prod, test, sandbox1, etc.
     * @param severity - Level of severity.
     * @param message - Message to display.
     * @returns - A standard format alarm description.
     */
    static formatAlarmDescription(environmentName: string, severity: ltype.Severity, message: string): string;
}
