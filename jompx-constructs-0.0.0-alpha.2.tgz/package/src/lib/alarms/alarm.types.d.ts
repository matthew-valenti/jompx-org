export declare enum Severity {
    low = "low",
    high = "high",
    critical = "critical"
}
