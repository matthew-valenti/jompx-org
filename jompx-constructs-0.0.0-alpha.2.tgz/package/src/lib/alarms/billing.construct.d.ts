import * as cloudwatch from 'aws-cdk-lib/aws-cloudwatch';
import * as sns from 'aws-cdk-lib/aws-sns';
import { Construct } from 'constructs';
export interface BillingAlarmProps {
    environmentName: string;
    estimatedMonthlyThreshold: number;
    topicSubscriptions?: sns.ITopicSubscription[];
    alarmDescription?: string;
    topicDisplayName?: string;
}
/**
 * @deprecated This approach works but is no longer considered AWS best practice.
 * Billing alarm.
 * Sends an email notification via SNS when monthly estimated billing exceeds a specific threshold.
 * Deploy to the organization account to track billing across all AWS accounts.
 */
export declare class BillingAlarm extends Construct {
    topic: sns.Topic;
    alarm: cloudwatch.Alarm;
    constructor(scope: Construct, id: string, props: BillingAlarmProps);
}
