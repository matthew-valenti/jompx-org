export interface CedarWhenInterpreterProps {
    operator: string;
    interpreterOperator: string;
    expression: unknown;
}
export interface IsOperator {
    isOperator: boolean;
    baseOperator: string | null;
}
/**
 * Parse a Cedar "when" policy (based on Cedar JSON format) with an interpreter.
 */
export declare class CedarWhenParser {
    private operatorsMap;
    interpreters: Record<string, (props: CedarWhenInterpreterProps) => unknown>;
    constructor(interpreters: Record<string, (props: CedarWhenInterpreterProps) => unknown>);
    interpret(expression: unknown): unknown | null;
    private isOperator;
    private nextOperator;
}
