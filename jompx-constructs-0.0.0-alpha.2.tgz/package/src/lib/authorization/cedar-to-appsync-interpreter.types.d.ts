import * as appsyncUtils from 'awscdk-appsync-utils';
import * as ctype from './cedar.types';
export interface CedarToAppSyncInterpreted {
    objectName: string;
    attributeName?: string;
    actions: string[];
    isGraphqlAccessObject: boolean;
    directives: appsyncUtils.Directive[];
}
export interface Root {
    staticPolicies: Policy[];
}
export interface Policy {
    effect: ctype.Effect;
    principal: Principal;
    action: string[];
    resource: Resource;
}
export interface Principal {
    authorizationType: string;
    props: CognitoGroup | CognitoUser | IAM | ApiKey | OIDC;
}
export interface IAM {
    accountId: string;
}
export interface OIDC {
    accountId: string;
    oidcProviderId: string;
}
export interface ApiKey {
    accountId: string;
    apiId: string;
}
export interface CognitoGroup {
    region: string;
    userPoolId: string;
    groupName: string;
}
export interface CognitoUser {
    region: string;
    userPoolId: string;
    cognitoUserId: string;
}
export interface Resource {
    type: string;
    id?: string;
}
