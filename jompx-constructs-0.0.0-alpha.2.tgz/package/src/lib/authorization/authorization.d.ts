import * as ctype from './cedar.types';
import * as type from './authorization.types';
/**
 * Example Usage: const authorization = await Authorization.create();
 */
export declare class Authorization {
    policies: ctype.CedarPolicySet;
    private constructor();
    /**
     * Creates an Authorization instance with tokenized policies.
     *
     * a. Fail Fast Principle: The constructor will throw an error immediately
     *    if any parameter cannot be replaced, ensuring issues are caught during
     *    initialization rather than runtime.
     * b. Immutable Security State: The constructor will resolve all placeholders
     *    at the point of object creation, ensuring the class operates with a complete,
     *    immutable policy set and preventing runtime inconsistencies or bypasses.
     * c. Auditability and Debugging: Early error detection by the constructor
     *    simplifies identifying and correcting misconfigurations, supporting robust
     *    development and security practices.
     *
     * @param policies - Cedar policies JSON (with placeholders).
     * @param tokens - A list of placeholder/token values.
     * @returns - An Authorization instance with tokenized policies.
     * @throws - If a required token for a placeholder is missing.
     */
    static create(policies: ctype.CedarPolicySet, tokens: type.AuthorizationTokens): Authorization;
    /**
     * Recursivly iterate the policies JSON to get a unique list of placeholders.
     * @param policies - Cedar policies JSON (with placeholders).
     * @returns - A unique set of key/value pairs i.e. placeholder/token pairs with token = undefined.
     */
    static requiredPlaceholders(policies: ctype.CedarPolicySet): Record<string, string | undefined>;
    /**
     * Replaces all placeholders in a policies object with their corresponding token values.
     *
     * @param policies - Cedar policies JSON (with placeholders).
     * @param tokens - A record of placeholder keys and their corresponding token values.
     * @returns - A new Cedar policies JSON object (with tokens).
     * @throws - If a required token for a placeholder is missing.
     */
    replacePlaceholdersWithTokens(policies: ctype.CedarPolicySet, tokens: Record<string, string | undefined>): ctype.CedarPolicySet;
    /**
     * Get a list of all schema attributes used in resources.
     * For use with AppSync coarse grain authorization.
     * @returns
     *
     * Example:
     * [ { entityName: "MysqlMovie", attributeName: "owners" } ]
     */
    getSchemaAttributesFromResources(): Array<{
        entityName: string;
        attributeName: string;
    }>;
    /**
     * Checks whether a Cedar authorization request (principal, action, resource, context, policies, entities) is allowed by a set of policies.
     * If at least one policy permits the request, the decision is "allow".
     * If no policies allow it, the decision is "deny".
     *
     * The policies type is unexpeted i.e. wrapped in an array. This is the correct raw corresponding typescript type:
     * type CedarPolicies = Array<{[policyId: string]: Policy;}>;
     */
    cedarIsAuthorized(request: type.AuthorizationRequest): type.AuthorizationResponse;
    exportPoliciesToFile(filePath: string): Promise<void>;
}
