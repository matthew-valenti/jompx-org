export type RuleProperties = import('json-rules-engine').RuleProperties;
export interface CedarWhenToMongoDbInterpreted {
    fieldNames: string[];
    filter: object;
    condition: object;
}
export interface InterpreterResult {
    filter: object | undefined;
    condition: RuleProperties['conditions'] | undefined;
}
export interface FieldAccessExpression {
    variableReference: string;
    attr: string;
}
