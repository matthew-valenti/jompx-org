export interface CedarInterpreterProps {
    operator: string;
    expression: Record<string, unknown>;
}
export interface IsOperator {
    isOperator: boolean;
    baseOperator: string | null;
}
/**
 * Parse a Cedar policy (based on Cedar JSON format) with an interpreter.
 */
export declare class CedarParser<T extends Record<string, unknown>> {
    interpreters: {
        [K in keyof T]: (props: CedarInterpreterProps) => T[K];
    };
    constructor(interpreters: {
        [K in keyof T]: (props: CedarInterpreterProps) => T[K];
    });
    interpret<K extends keyof T>(expression: T): T[K] | null;
    private isOperator;
    private nextOperator;
}
