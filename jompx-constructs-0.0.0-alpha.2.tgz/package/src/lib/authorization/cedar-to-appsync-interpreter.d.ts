import * as type from './cedar-to-appsync-interpreter.types';
import * as ctype from './cedar.types';
/**
 * Convert Cedar policies to AppSync coarse-grain directives.
 */
export declare class CedarToAppSyncInterpreter {
    interpret(policies: ctype.CedarPolicySet): type.CedarToAppSyncInterpreted[];
}
