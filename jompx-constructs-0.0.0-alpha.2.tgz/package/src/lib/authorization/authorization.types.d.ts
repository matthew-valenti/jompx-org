import * as ctype from './cedar.types';
interface Entity {
    type: string;
    id: string;
}
export interface AuthorizationRequest {
    principal: Entity;
    action: Entity;
    resource: Entity;
    context?: Record<string, unknown>;
    policies?: Array<{
        [policyId: string]: ctype.CedarPolicy;
    }>;
    entities?: Array<{
        uid: ctype.EntityReference;
        attrs: Record<string, ctype.CedarValue> | {};
        parents?: ctype.EntityReference[];
    }>;
}
export interface AuthorizationResponse {
    type: 'success' | 'failure';
    response?: {
        decision: 'allow' | 'deny';
        diagnostics: {
            reason: string[];
            errors: string[];
        };
    };
    warnings: string[];
}
export type AuthorizationTokens = Record<string, string | undefined>;
export interface EntityAttributeNamePair {
    entityName: string;
    attributeName: string;
}
export interface AuthorizationPrincipal {
    [apiname: string]: {
        allowedPrincipalTypes: string[];
        groupNames: string[];
    };
}
export {};
