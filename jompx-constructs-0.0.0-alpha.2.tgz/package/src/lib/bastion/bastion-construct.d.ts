import * as ec2 from 'aws-cdk-lib/aws-ec2';
import * as iam from 'aws-cdk-lib/aws-iam';
import * as ssm from 'aws-cdk-lib/aws-ssm';
import { Construct } from 'constructs';
import { ServiceContractOutput } from '../service-contract-registry/service-contract-output.construct';
export type BastionLifecycle = 'always-on' | 'manual';
export interface BastionProps {
    bastionKey: string;
    vpc: ec2.IVpc;
    /**
     * Optional additional security groups to attach to the bastion instance.
     *
     * Use this when the bastion should join an existing trusted client access group,
     * for example an RDS construct's exposed client security group.
     */
    additionalSecurityGroups?: ec2.ISecurityGroup[];
    /**
     * Bastion placement should target exactly one private subnet with egress.
     * Example: { subnetType: ec2.SubnetType.PRIVATE_WITH_EGRESS }
     */
    vpcSubnets: ec2.SubnetSelection;
    /**
     * Connectivity mode is explicit to avoid ambiguous deployments.
     * - nat: use existing outbound internet access from the selected subnet
     * - private-link: create the minimum SSM interface endpoints in the selected subnet
     */
    connectivity: 'nat' | 'private-link';
    /**
     * The instance type to use.
     *
     * @default t4g.nano
     */
    instanceType?: ec2.InstanceType;
    /**
     * Root volume size in GiB.
     *
     * @default 10
     */
    rootVolumeSizeGiB?: number;
    /**
     * Lifecycle mode for the bastion.
     *
     * - always-on: intended to stay available and receives automatic weekly patch scheduling
     * - manual: consumer is responsible for start/stop and patching behavior
     *
     * Automatic patching requires the instance to be running during the maintenance window.
     *
     * @default always-on
     */
    lifecycle?: BastionLifecycle;
}
/**
 * SSM-only bastion for low-cost administrative access to private resources.
 *
 * Security:
 * - No inbound rules
 * - No SSH or EC2 key pair
 * - IMDSv2 required
 * - Session Manager only
 *
 * Cost:
 * - Defaults to t4g.nano
 * - Can rely on existing NAT or create the minimum SSM PrivateLink endpoints
 */
export declare class Bastion extends Construct {
    readonly instance: ec2.Instance;
    readonly instanceRole: iam.Role;
    readonly securityGroup: ec2.SecurityGroup;
    readonly endpointSecurityGroup?: ec2.SecurityGroup;
    readonly patchingRole?: iam.Role;
    readonly patchingMaintenanceWindow?: ssm.CfnMaintenanceWindow;
    readonly contractOutput: ServiceContractOutput;
    readonly instanceId: string;
    readonly securityGroupId: string;
    constructor(scope: Construct, id: string, props: BastionProps);
}
