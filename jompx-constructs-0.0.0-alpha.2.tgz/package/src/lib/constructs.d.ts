export declare function constructs(): string;
