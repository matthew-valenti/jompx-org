import * as dynamodblib from '@aws-sdk/lib-dynamodb';
import type { ServiceContractRegistryItem } from '../service-contract-registry.types';
import type { AccountRegionContractPath, ContractPath, PutContractRequest } from './contract-registry.types';
export declare class ContractRegistryStore {
    private readonly tableName;
    private readonly gsi1Name;
    private readonly client;
    constructor(tableName: string, gsi1Name: string, client?: dynamodblib.DynamoDBDocumentClient);
    getContract(path: ContractPath): Promise<ServiceContractRegistryItem | undefined>;
    getContractByAccountRegion(path: AccountRegionContractPath): Promise<ServiceContractRegistryItem | undefined>;
    listContracts(): Promise<ServiceContractRegistryItem[]>;
    putContract(request: PutContractRequest): Promise<ServiceContractRegistryItem>;
}
export declare class ContractRegistryError extends Error {
    readonly statusCode: number;
    constructor(statusCode: number, message: string);
}
