import type { ServiceContractRegistryItem } from '../service-contract-registry.types';
export interface ContractPath {
    environmentName: string;
    contractName: string;
    schemaVersion: string;
}
export interface AccountRegionContractPath {
    accountId: string;
    region: string;
    contractName: string;
    schemaVersion: string;
}
export interface PutContractRequest extends ContractPath {
    accountId: string;
    region: string;
    value: Record<string, unknown>;
}
export interface ContractResponse {
    contract: ServiceContractRegistryItem;
}
