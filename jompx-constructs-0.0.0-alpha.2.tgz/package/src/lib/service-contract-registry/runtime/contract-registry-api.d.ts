import type { APIGatewayProxyEvent, APIGatewayProxyResult } from 'aws-lambda';
import { ContractRegistryStore } from './contract-registry-store';
export interface ContractRegistryPublisherAccess {
    publisherAccountIds?: string[];
    publisherRoleArns?: string[];
}
export declare class ContractRegistryApi {
    private readonly store;
    private readonly publisherAccess;
    constructor(store: ContractRegistryStore, publisherAccess?: ContractRegistryPublisherAccess);
    handle(event: APIGatewayProxyEvent): Promise<APIGatewayProxyResult>;
}
export declare function toErrorResponse(error: unknown): APIGatewayProxyResult;
export declare class ValidationError extends Error {
}
