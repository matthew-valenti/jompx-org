import { Construct } from 'constructs';
export interface ServiceContractLookupProps {
    /**
     * Producer AWS account.
     */
    readonly accountId: string;
    /**
     * Producer AWS region.
     */
    readonly region: string;
    /**
     * Published contract name.
     */
    readonly contractName: string;
    /**
     * Contract schema version to read.
     */
    readonly schemaVersion: string;
}
export interface ServiceContractLookupByEnvironmentNameProps {
    /**
     * Published contract environment name.
     */
    readonly environmentName: string;
    /**
     * Published contract name.
     */
    readonly contractName: string;
    /**
     * Contract schema version to read.
     */
    readonly schemaVersion: string;
}
export interface ServiceContractLookupResult<TValue extends object = Record<string, unknown>> {
    readonly environmentName: string;
    readonly contractName: string;
    readonly schemaVersion: string;
    readonly accountId: string;
    readonly region: string;
    readonly value: TValue;
    readonly updatedAt?: string;
}
/**
 * Reads a cached deploy-time contract through CDK context.
 */
export declare class ServiceContractLookup {
    static readonly contextKeyPrefix = "jompx:service-contract";
    static lookup<TValue extends object = Record<string, unknown>>(scope: Construct, props: ServiceContractLookupProps): ServiceContractLookupResult<TValue>;
    static lookupByEnvironmentName<TValue extends object = Record<string, unknown>>(scope: Construct, props: ServiceContractLookupByEnvironmentNameProps): ServiceContractLookupResult<TValue>;
}
