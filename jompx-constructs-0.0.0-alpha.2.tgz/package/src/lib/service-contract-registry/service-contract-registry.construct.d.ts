import * as acm from 'aws-cdk-lib/aws-certificatemanager';
import * as apigateway from 'aws-cdk-lib/aws-apigateway';
import * as dynamodb from 'aws-cdk-lib/aws-dynamodb';
import * as lambdaNodejs from 'aws-cdk-lib/aws-lambda-nodejs';
import * as logs from 'aws-cdk-lib/aws-logs';
import * as route53 from 'aws-cdk-lib/aws-route53';
import { Construct } from 'constructs';
export interface ServiceContractRegistryProps {
    /**
     * Runtime HTTP registry settings.
     */
    api?: ServiceContractRegistryApiProps;
}
export interface ServiceContractRegistryApiProps {
    /**
     * Optional custom domain name, for example contracts-dev.company.com.
     */
    domainName?: string;
    /**
     * Certificate for the custom domain.
     */
    certificate?: acm.ICertificate;
    /**
     * Optional hosted zone used to create an alias record for the custom domain.
     */
    hostedZone?: route53.IHostedZone;
    /**
     * Optional production guardrails. Disabled by default to keep sandbox services lightweight.
     */
    operations?: ServiceContractRegistryOperationsProps;
    /**
     * Optional cross-account API access. Same-account callers can use IAM without this.
     */
    access?: ServiceContractRegistryAccessProps;
}
export interface ServiceContractRegistryAccessProps {
    /**
     * Allow GET calls from principals in this AWS Organization.
     */
    organizationId: string;
    /**
     * Optional AWS accounts whose CI/CD roles are allowed to publish contracts.
     * When omitted together with publisherRoleArns, PUT defaults to org-wide access.
     */
    publisherAccountIds?: string[];
    /**
     * Optional IAM role ARNs allowed to publish contracts for stricter teams.
     * When omitted together with publisherAccountIds, PUT defaults to org-wide access.
     */
    publisherRoleArns?: string[];
}
export interface ServiceContractRegistryOperationsProps {
    /**
     * Enable log retention, throttling, and a basic CloudWatch dashboard.
     */
    enabled: boolean;
    /**
     * Create a simple dashboard for registry operations.
     *
     * @default true
     */
    dashboard?: boolean;
    /**
     * Lambda log retention.
     *
     * @default logs.RetentionDays.ONE_MONTH
     */
    logRetention?: logs.RetentionDays;
    /**
     * API Gateway steady-state requests per second.
     *
     * @default 50
     */
    throttleRateLimit?: number;
    /**
     * API Gateway burst requests.
     *
     * @default 100
     */
    throttleBurstLimit?: number;
}
/**
 * Central runtime registry for independently deployed service contracts.
 *
 * Use this when a service contract crosses a deployment boundary. Same stack/app/lifecycle
 * wiring should still use normal CDK props.
 */
export declare class ServiceContractRegistry extends Construct {
    readonly store: ServiceContractRegistryStore;
    readonly api: ServiceContractRegistryApi;
    constructor(scope: Construct, id: string, props?: ServiceContractRegistryProps);
}
/**
 * Durable storage layer for published service contracts.
 */
export declare class ServiceContractRegistryStore extends Construct {
    static readonly gsi1Name = "gsi1";
    readonly table: dynamodb.Table;
    constructor(scope: Construct, id: string);
}
/**
 * HTTP access boundary for runtime contract resolution.
 *
 * REST API shape:
 * - GET /v1/environments/{environmentName}/contracts/{contractName}/schemaVersions/{schemaVersion}
 * - PUT /v1/environments/{environmentName}/contracts/{contractName}/schemaVersions/{schemaVersion}
 * - GET /v1/accounts/{accountId}/regions/{region}/contracts/{contractName}/schemaVersions/{schemaVersion}
 * - GET /v1/contracts
 */
export declare class ServiceContractRegistryApi extends Construct {
    readonly handler: lambdaNodejs.NodejsFunction;
    readonly restApi: apigateway.RestApi;
    readonly domainName?: apigateway.DomainName;
    readonly aliasRecord?: route53.ARecord;
    readonly baseUrl: string;
    readonly readInvokeArn: string;
    readonly publishInvokeArn: string;
    constructor(scope: Construct, id: string, props: ServiceContractRegistryApiProps & {
        store: ServiceContractRegistryStore;
    });
}
