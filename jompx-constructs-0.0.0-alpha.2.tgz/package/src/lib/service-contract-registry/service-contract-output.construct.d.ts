import * as cdk from 'aws-cdk-lib';
import { Construct } from 'constructs';
export interface ServiceContractOutputProps {
    /**
     * Contract schema version. Bump only when consumers need to opt into a changed contract shape.
     */
    schemaVersion: string;
    /**
     * Contract fields to publish.
     */
    value: Record<string, unknown>;
}
/**
 * Marks deployed values as a service contract.
 */
export declare class ServiceContractOutput extends Construct {
    /**
     * Stable metadata marker used by publishers to discover contract outputs.
     */
    static readonly marker = "ServiceContract";
    static readonly outputKeyPrefix = "ServiceContractOutput";
    static readonly outputKeySeparator = "__";
    static outputKey(schemaVersion: string, fieldName: string): string;
    static outputDescription(schemaVersion: string, fieldName: string): string;
    readonly schemaVersion: string;
    readonly outputs: Record<string, cdk.CfnOutput>;
    constructor(scope: Construct, id: string, props: ServiceContractOutputProps);
}
