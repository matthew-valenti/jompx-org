import * as cdk from 'aws-cdk-lib';
import * as pipelines from 'aws-cdk-lib/pipelines';
import { Construct } from 'constructs';
export interface ServiceContractPublisherProps {
    /**
     * Deployed stage containing services with ServiceContractOutput markers.
     */
    stage: cdk.Stage;
    /**
     * Service contract registry connection details.
     */
    registry: ServiceContractPublisherRegistryProps;
    /**
     * Friendly environment name used to identify an AWS account + region pair e.g. workload-prod.
     */
    environmentName: string;
}
export interface ServiceContractPublisherRegistryProps {
    /**
     * Registry endpoint, for example https://contracts.company.com.
     */
    baseUrl: string;
    /**
     * AWS region where the registry API is deployed. Required for SigV4 signing.
     */
    region: string;
    /**
     * Execute API ARN this publisher can call.
     */
    invokeArn: string;
}
/**
 * Pipeline helper that publishes all ServiceContractOutput markers in a deployed stage.
 */
export declare class ServiceContractPublisher extends Construct {
    static readonly REGISTRY_BASE_URL_ENV_VAR = "SERVICE_CONTRACT_REGISTRY_BASE_URL";
    static readonly REGISTRY_REGION_ENV_VAR = "SERVICE_CONTRACT_REGISTRY_REGION";
    static readonly CONTRACTS_ENV_VAR = "SERVICE_CONTRACTS";
    readonly step: pipelines.CodeBuildStep;
    constructor(scope: Construct, id: string, props: ServiceContractPublisherProps);
    addPostTo(stageDeployment: pipelines.StageDeployment): pipelines.StageDeployment;
    addPreTo(stageDeployment: pipelines.StageDeployment): pipelines.StageDeployment;
}
