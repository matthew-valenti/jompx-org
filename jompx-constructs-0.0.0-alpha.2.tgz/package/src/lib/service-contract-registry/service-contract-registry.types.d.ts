export interface ServiceContractRegistryKey {
    accountId: string;
    region: string;
    contractName: string;
    schemaVersion: string;
}
export interface ServiceContractRegistryItem extends ServiceContractRegistryKey {
    pk: string;
    sk: string;
    gsi1pk: string;
    gsi1sk: string;
    environmentName: string;
    value: Record<string, unknown>;
    schemaVersion: string;
    updatedAt: string;
}
export interface ServiceContractRegistryValue {
    environmentName: string;
    accountId: string;
    region: string;
    contractName: string;
    schemaVersion: string;
    value: Record<string, unknown>;
}
