import * as budgets from 'aws-cdk-lib/aws-budgets';
import { Construct } from 'constructs';
export interface BudgetAlarmProps {
    budgetLimit: budgets.CfnBudget.SpendProperty;
    emailSubscribers?: string[];
    phoneSubscribers?: string[];
}
/**
 * Billing and cost control.
 * Sends an email/sms notification via AWS SNS when:
 *  - A monthly estimated billing exceeds a specific threshold.
 * Deploy to the organization account to track billing across all AWS accounts.
 * TODO: Add cost anomaly detection construct when feature available in CDK.
 */
export declare class BudgetAlarm extends Construct {
    costBudget: budgets.CfnBudget;
    constructor(scope: Construct, id: string, props: BudgetAlarmProps);
}
