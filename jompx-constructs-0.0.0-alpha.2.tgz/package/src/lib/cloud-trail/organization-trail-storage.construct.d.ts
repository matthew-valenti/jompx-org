import * as glue from '@aws-cdk/aws-glue-alpha';
import * as athena from 'aws-cdk-lib/aws-athena';
import * as cdk from 'aws-cdk-lib';
import { Construct } from 'constructs';
export interface OrganizationTrailStorageProps {
    bucketName: string;
    accountId: string;
    region: string;
    organizationAccount: string;
    organizationRegion: string;
    organizationId: string;
    athenaQueryResultsS3Url: string;
    projection: {
        accountIds: string[];
        regions: string[];
        timestampRange: string;
    };
    /**
     * S3 CloudTrail logs expiration. Default value is 1 year.
     */
    expiration?: cdk.Duration;
    trailName?: string;
}
/**
 * Create an organization_trail s3 bucket.
 * Best practice is to store logs in a central AWS account e.g. security or logs.
 */
export declare class OrganizationTrailStorage extends Construct {
    bucket: cdk.aws_s3.Bucket;
    database: glue.Database;
    table: glue.S3Table;
    workGroup: athena.CfnWorkGroup;
    query: athena.CfnNamedQuery;
    constructor(scope: Construct, id: string, props: OrganizationTrailStorageProps);
}
