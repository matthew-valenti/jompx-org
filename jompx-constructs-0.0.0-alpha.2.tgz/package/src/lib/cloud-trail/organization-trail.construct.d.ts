import * as cdk from 'aws-cdk-lib';
import { Construct } from 'constructs';
export interface OrganizationTrailProps {
    bucketName: string;
    trailName?: string;
}
/**
 * Create an organization_trail and store CloudWatch management event logs in S3 for all accounts and regions. Use Athena to query logs.
 * https://docs.aws.amazon.com/awscloudtrail/latest/userguide/creating-trail-organization.html
 * https://docs.aws.amazon.com/athena/latest/ug/cloudtrail-logs.html
 * https://dev.to/noyonict/how-to-store-multiple-organizations-cloudtrail-logs-into-an-s3-bucket-of-a-separate-account-eoa
 *
 * An organization trail can only be deployed to the management account where AWS organizations is setup.
 *
 * Create a Glue table for CloudTrail logs in Athena using partition projection.
 * New data will automatically be available without having to add partitions manually e.g. manual partitioning.
 * The AWS documentation shows a timestamp partition only. Extend this to include account and region to allow queries across accounts and regions.
 *
 * Management events
 * Management events provide information about management operations that are performed on resources in your AWS account. These are also known as control plane operations.
 * By default, a Trail logs all management events.
 * By default, no data events are logged for a Trail.
 *
 * Log File Validation.
 * In order to validate that the CloudTrail log file was not modified after CloudTrail delivered it, CloudTrail provides a digital signature for each file.
 * This is enabled on the Trail construct by default.
 *
 * Multi-Region
 * By default, a Trail is configured to deliver log files from multiple regions to a single S3 bucket for a given account.
 *
 * Global Service Events
 * For global services such as AWS IAM, AWS STS, Amazon CloudFront, Route 53, etc., events are delivered to any trail that includes global services.
 * Events for global services are turned on by default.
 *
 * TODO: Enable CloudTrail Insights.
 * AWS CloudTrail Insights helps AWS users identify and respond to unusual activity associated with API calls and API error rates by continuously analyzing CloudTrail management events.
 *
 * TODO: Send to CloudWatch Logs.
 * Monitor your trail logs and be notified when specific activity occurs.
 *
 * Consider implementing CloudTrail Lake instead (note that pricing is significant). The advantage to using Athena is it can do cross datasource queries -- can CloudTrail Lake?
 */
export declare class OrganizationTrail extends Construct {
    trail: cdk.aws_cloudtrail.Trail;
    constructor(scope: Construct, id: string, props: OrganizationTrailProps);
}
