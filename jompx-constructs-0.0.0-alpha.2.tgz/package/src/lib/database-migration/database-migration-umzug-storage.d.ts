import type { MigrationParams, UmzugStorage } from 'umzug';
import { DatabaseMigrationStore } from './database-migration-store';
export interface DatabaseMigrationUmzugStorageProps {
    targetId: string;
    store: DatabaseMigrationStore;
}
/**
 * Bridges Umzug's executed migration contract to the Jompx DynamoDB state table.
 */
export declare class DatabaseMigrationUmzugStorage<Ctx = unknown> implements UmzugStorage<Ctx> {
    private readonly targetId;
    private readonly store;
    constructor(props: DatabaseMigrationUmzugStorageProps);
    logMigration(params: MigrationParams<Ctx>): Promise<void>;
    unlogMigration(params: MigrationParams<Ctx>): Promise<void>;
    executed(_meta: Pick<MigrationParams<Ctx>, 'context'>): Promise<string[]>;
}
