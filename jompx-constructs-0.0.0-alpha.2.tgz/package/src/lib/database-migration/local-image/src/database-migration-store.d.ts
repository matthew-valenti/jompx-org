export interface DatabaseMigrationStoreProps {
    tableName: string;
    gsi1Name?: string;
    storeRoleArn?: string;
    region?: string;
}
export interface AcquireLockInput {
    targetId: string;
    ownerId: string;
    acquiredAt: string;
    expiresAt: string;
    now?: string;
}
export interface ReleaseLockInput {
    targetId: string;
    ownerId?: string;
}
export interface ApplyMigrationRecordInput {
    targetId: string;
    migrationName: string;
    startedAt: string;
}
export interface DatabaseMigrationRecord {
    migration_name: string;
    started_at: string;
}
export declare class DatabaseMigrationStore {
    private readonly storeRoleArn;
    private readonly tableName;
    private readonly gsi1Name;
    private readonly region;
    private client;
    constructor(props: DatabaseMigrationStoreProps);
    acquireLock(input: AcquireLockInput): Promise<void>;
    releaseLock(input: ReleaseLockInput): Promise<void>;
    listMigrations(targetId: string): Promise<DatabaseMigrationRecord[]>;
    getMigration(targetId: string, migrationName: string): Promise<DatabaseMigrationRecord | undefined>;
    applyMigrationRecord(input: ApplyMigrationRecordInput): Promise<void>;
    removeMigrationRecord(targetId: string, migrationName: string): Promise<void>;
    private targetPk;
    private migrationKey;
    private lockKey;
    private getClient;
    private assumeStoreRole;
}
