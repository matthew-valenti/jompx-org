import { MysqlConnectionSecretValue } from '../../../database-client/mysql-database-client.types';
import { PostgresConnectionSecretValue } from '../../../database-client/postgres-database-client.types';
export type DatabaseMigrationEngine = 'dynamodb' | 'mysql_5.7.x' | 'mysql_8.0.x' | 'postgres_18.x' | 'sqlite_3.x';
export type DatabaseMigrationDirection = 'up' | 'down';
export interface DatabaseMigrationMetadataStoreConfig {
    tableName: string;
    gsi1Name: string;
    storeRoleArn?: string;
}
export interface DatabaseMigrationRunnerConfig {
    metadataStore: DatabaseMigrationMetadataStoreConfig;
    targetId: string;
    engine: DatabaseMigrationEngine;
    direction: DatabaseMigrationDirection;
    artifactBucketName: string;
    artifactObjectKey: string;
    secretName?: string;
    region?: string;
}
export interface SqlMigrationContext {
    query: (sql: string, values?: unknown[]) => Promise<void>;
    close: () => Promise<void>;
}
export type DatabaseMigrationContext = object;
export declare class DatabaseMigrationContextFactory {
    private readonly config;
    private readonly readConnectionSecret;
    constructor(config: DatabaseMigrationRunnerConfig, readConnectionSecret: (secretName: string) => Promise<MysqlConnectionSecretValue | PostgresConnectionSecretValue>);
    create(): Promise<DatabaseMigrationContext>;
}
