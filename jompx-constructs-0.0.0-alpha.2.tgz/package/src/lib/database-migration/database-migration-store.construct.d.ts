import * as dynamodb from 'aws-cdk-lib/aws-dynamodb';
import * as iam from 'aws-cdk-lib/aws-iam';
import * as s3 from 'aws-cdk-lib/aws-s3';
import { Construct } from 'constructs';
import { ServiceContractOutput } from '../service-contract-registry/service-contract-output.construct';
import { DatabaseMigrationStoreConfig } from './database-migration.types';
export interface DatabaseMigrationStoreProps {
    accessRoleAssumedBy?: iam.IPrincipal;
}
/**
 * Store for database migration artifacts, state, and Store-level access.
 *
 * Creates:
 * - an S3 bucket for migration artifacts
 * - a DynamoDB table for migration state and locks
 * - a Store role that Executor workloads assume to access Store-managed resources
 *
 * Publishes:
 * - Store config as a ServiceContractOutput
 */
export declare class DatabaseMigrationStore extends Construct {
    readonly table: dynamodb.Table;
    readonly bucket: s3.Bucket;
    readonly gsi1Name = "gsi1";
    readonly config: DatabaseMigrationStoreConfig;
    readonly writerRole: iam.Role;
    readonly contractOutput: ServiceContractOutput;
    constructor(scope: Construct, id: string, props?: DatabaseMigrationStoreProps);
}
