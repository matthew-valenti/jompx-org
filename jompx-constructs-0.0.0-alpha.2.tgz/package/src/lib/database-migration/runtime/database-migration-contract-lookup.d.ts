import { DatabaseMigrationExecutorConfig } from '../database-migration.types';
export declare function handler(): Promise<DatabaseMigrationExecutorConfig>;
