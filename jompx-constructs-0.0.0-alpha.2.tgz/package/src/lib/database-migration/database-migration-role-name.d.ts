export declare function buildDatabaseMigrationExecutorStartBuildRoleName(targetId: string): string;
export declare function buildDatabaseMigrationOrchestratorStateMachineRoleName(executorRoleArn: string): string;
