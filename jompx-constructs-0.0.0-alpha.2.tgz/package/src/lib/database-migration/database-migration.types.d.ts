import * as cdk from 'aws-cdk-lib';
import * as codebuild from 'aws-cdk-lib/aws-codebuild';
export type DatabaseMigrationExecutionMode = 'sync' | 'async';
export type DatabaseMigrationEngine = 'dynamodb' | 'mysql_5.7.x' | 'mysql_8.0.x' | 'postgres_17.x' | 'sqlite_3.x';
export interface DatabaseMigrationStoreConfig {
    bucketName: string;
    tableName: string;
    gsi1Name: string;
    roleArn: string;
}
export interface DatabaseMigrationExecutorConfig {
    roleArn: string;
    projectArn: string;
    projectName: string;
    targetId: string;
}
export interface DatabaseMigrationOrchestratorConfig {
    roleArn: string;
    stateMachineRoleArn: string;
    stateMachineArn: string;
}
export interface DatabaseMigrationContractReference {
    /**
     * Friendly environment name for the account/region that published the contract.
     */
    environmentName: string;
    /**
     * Published contract name. For stack-output publishing, this is the producer stack name.
     */
    contractName: string;
    /**
     * Contract schema version to read.
     */
    schemaVersion: string;
}
export interface DatabaseMigrationPublishedContract<TValue> extends DatabaseMigrationContractReference {
    value: TValue;
}
export interface DatabaseMigrationPropsRuntime {
    /**
     * CodeBuild image that runs the migration runner.
     *
     * @default LinuxBuildImage.STANDARD_7_0
     */
    buildImage?: codebuild.IBuildImage;
    /**
     * Compute size for the migration runner build.
     *
     * @default SMALL
     */
    computeType?: codebuild.ComputeType;
    /**
     * Maximum CodeBuild runtime for a single migration execution.
     *
     * @default 8 hours
     */
    timeout?: cdk.Duration;
    /**
     * How long the migration lock remains active before another runner may take it.
     *
     * @default 9 hours
     */
    lockTtl?: cdk.Duration;
}
export interface DatabaseMigrationWorkflowProps {
    executionMode?: DatabaseMigrationExecutionMode;
    taskTimeout?: cdk.Duration;
    stateMachineTimeout?: cdk.Duration;
}
