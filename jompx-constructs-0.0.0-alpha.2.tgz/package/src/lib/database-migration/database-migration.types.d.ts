import * as cdk from 'aws-cdk-lib';
export type DatabaseMigrationExecutionMode = 'sync' | 'async';
export type DatabaseMigrationEngine = 'dynamodb' | 'mysql_5.7.x' | 'mysql_8.0.x' | 'postgres_18.x' | 'sqlite_3.x';
export interface DatabaseMigrationStoreConfig {
    bucketName: string;
    tableName: string;
    gsi1Name: string;
    roleArn: string;
}
export interface DatabaseMigrationExecutorConfig {
    roleArn: string;
    clusterArn: string;
    taskDefinitionArn: string;
    containerName: string;
    subnetIds: string[];
}
export interface DatabaseMigrationOrchestratorConfig {
    roleArn: string;
    stateMachineArn: string;
}
export interface DatabaseMigrationContractRegistryConfig {
    /**
     * Base URL for the Service Contract Registry API.
     */
    baseUrl: string;
    /**
     * AWS region where the registry API is deployed. Used for SigV4 signing.
     */
    region: string;
    /**
     * execute-api ARN that allows runtime contract reads.
     */
    readInvokeArn: string;
}
export interface DatabaseMigrationContractReference {
    /**
     * Friendly environment name for the account/region that published the contract.
     */
    environmentName: string;
    /**
     * Published contract name. For stack-output publishing, this is the producer stack name.
     */
    contractName: string;
    /**
     * Contract schema version to read.
     */
    schemaVersion: string;
}
export interface DatabaseMigrationPropsRuntime {
    /**
     * Database migration runner image tag to pull from the framework-managed ECR repository.
     *
     * @default latest
     */
    imageTag?: string;
    /**
     * CPU units for the ECS Fargate task.
     *
     * @default 256
     */
    cpu?: number;
    /**
     * Memory limit in MiB for the ECS Fargate task.
     *
     * @default 512
     */
    memoryLimitMiB?: number;
    /**
     * ECS container name for the database migration runner.
     *
     * @default database-migration-runner
     */
    containerName?: string;
}
export interface DatabaseMigrationWorkflowProps {
    executionMode?: DatabaseMigrationExecutionMode;
    taskTimeout?: cdk.Duration;
    stateMachineTimeout?: cdk.Duration;
}
