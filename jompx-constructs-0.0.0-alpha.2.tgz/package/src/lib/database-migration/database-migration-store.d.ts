import { DynamoDBDocumentClient } from '@aws-sdk/lib-dynamodb';
export type DatabaseMigrationDirection = 'up' | 'down';
export type DatabaseMigrationLockStatus = 'active' | 'released';
export interface DatabaseMigrationStoreProps {
    tableName: string;
    gsi1Name?: string;
    region?: string;
    storeRoleArn?: string;
    client?: DynamoDBDocumentClient;
}
export interface DatabaseMigrationRecord {
    pk: string;
    sk: string;
    target_id: string;
    migration_name: string;
    started_at: string;
    gsi1pk: string;
    gsi1sk: string;
}
export interface DatabaseMigrationLock {
    pk: string;
    sk: string;
    target_id: string;
    status: DatabaseMigrationLockStatus;
    owner_id?: string;
    acquired_at?: string;
    expires_at?: string;
}
export interface AcquireLockInput {
    targetId: string;
    ownerId: string;
    acquiredAt: string;
    expiresAt: string;
    now?: string;
}
export interface ReleaseLockInput {
    targetId: string;
    ownerId?: string;
}
export interface ApplyMigrationRecordInput {
    targetId: string;
    migrationName: string;
    startedAt: string;
}
export interface GetMigrationInput {
    targetId: string;
    migrationName: string;
}
export interface ListMigrationsInput {
    targetId: string;
    migrationName?: string;
    limit?: number;
    newestFirst?: boolean;
}
/**
 * Centralizes database migration state access for the one-table DynamoDB design.
 * Public methods speak in migration/lock terms instead of exposing DynamoDB command details.
 */
export declare class DatabaseMigrationStore {
    private readonly providedClient;
    private readonly tableName;
    private readonly gsi1Name;
    private readonly region;
    private readonly storeRoleArn;
    private client;
    constructor(props: DatabaseMigrationStoreProps);
    acquireLock(input: AcquireLockInput): Promise<void>;
    releaseLock(input: ReleaseLockInput): Promise<void>;
    getLock(targetId: string): Promise<DatabaseMigrationLock | undefined>;
    getMigration(input: GetMigrationInput): Promise<DatabaseMigrationRecord | undefined>;
    listMigrations(input: ListMigrationsInput): Promise<DatabaseMigrationRecord[]>;
    applyMigrationRecord(input: ApplyMigrationRecordInput): Promise<void>;
    removeMigrationRecord(input: GetMigrationInput): Promise<void>;
    private targetPk;
    private migrationKey;
    private lockKey;
    private getClient;
    private assumeStoreRole;
}
