import { DynamoDBDocumentClient } from '@aws-sdk/lib-dynamodb';
export type DatabaseMigrationDirection = 'up' | 'down';
export type DatabaseMigrationLockStatus = 'active' | 'released';
export type DatabaseMigrationSubmissionStatus = 'upload_created' | 'upload_completed' | 'run_started';
export interface DatabaseMigrationStoreProps {
    tableName: string;
    gsi1Name?: string;
    region?: string;
    storeRoleArn?: string;
    client?: DynamoDBDocumentClient;
}
export interface DatabaseMigrationRecord {
    pk: string;
    sk: string;
    target_id: string;
    migration_name: string;
    started_at: string;
    gsi1pk: string;
    gsi1sk: string;
}
export interface DatabaseMigrationLock {
    pk: string;
    sk: string;
    target_id: string;
    status: DatabaseMigrationLockStatus;
    owner_id?: string;
    acquired_at?: string;
    expires_at?: string;
}
export interface AcquireLockInput {
    targetId: string;
    ownerId: string;
    acquiredAt: string;
    expiresAt: string;
    now?: string;
}
export interface ReleaseLockInput {
    targetId: string;
    ownerId?: string;
}
export interface ApplyMigrationRecordInput {
    targetId: string;
    migrationName: string;
    startedAt: string;
}
export interface GetMigrationInput {
    targetId: string;
    migrationName: string;
}
export interface ListMigrationsInput {
    targetId: string;
    migrationName?: string;
    limit?: number;
    newestFirst?: boolean;
}
export interface DatabaseMigrationSubmissionContractReference {
    accountId: string;
    region: string;
    contractName: string;
    schemaVersion: string;
}
export interface DatabaseMigrationSubmissionRecord {
    pk: string;
    sk: string;
    submission_id: string;
    artifact_bucket_name: string;
    artifact_object_key: string;
    multipart_upload_id: string;
    database_name: string;
    direction: DatabaseMigrationDirection;
    status: DatabaseMigrationSubmissionStatus;
    contract_account_id: string;
    contract_region: string;
    contract_name: string;
    contract_schema_version: string;
    content_length_bytes: number;
    part_size_bytes: number;
    part_count: number;
    created_at: string;
    completed_at?: string;
    execution_arn?: string;
}
export interface CreateSubmissionInput {
    submissionId: string;
    artifactBucketName: string;
    artifactObjectKey: string;
    multipartUploadId: string;
    databaseName: string;
    direction: DatabaseMigrationDirection;
    contract: DatabaseMigrationSubmissionContractReference;
    contentLengthBytes: number;
    partSizeBytes: number;
    partCount: number;
    createdAt: string;
}
export interface CompleteSubmissionInput {
    submissionId: string;
    completedAt: string;
}
export interface StartSubmissionRunInput {
    submissionId: string;
    executionArn: string;
}
/**
 * Centralizes database migration state access for the one-table DynamoDB design.
 * Public methods speak in migration/lock terms instead of exposing DynamoDB command details.
 */
export declare class DatabaseMigrationStore {
    private readonly providedClient;
    private readonly tableName;
    private readonly gsi1Name;
    private readonly region;
    private readonly storeRoleArn;
    private client;
    constructor(props: DatabaseMigrationStoreProps);
    acquireLock(input: AcquireLockInput): Promise<void>;
    releaseLock(input: ReleaseLockInput): Promise<void>;
    getLock(targetId: string): Promise<DatabaseMigrationLock | undefined>;
    getMigration(input: GetMigrationInput): Promise<DatabaseMigrationRecord | undefined>;
    listMigrations(input: ListMigrationsInput): Promise<DatabaseMigrationRecord[]>;
    applyMigrationRecord(input: ApplyMigrationRecordInput): Promise<void>;
    removeMigrationRecord(input: GetMigrationInput): Promise<void>;
    createSubmission(input: CreateSubmissionInput): Promise<void>;
    getSubmission(submissionId: string): Promise<DatabaseMigrationSubmissionRecord | undefined>;
    completeSubmission(input: CompleteSubmissionInput): Promise<void>;
    startSubmissionRun(input: StartSubmissionRunInput): Promise<void>;
    private targetPk;
    private migrationKey;
    private lockKey;
    private submissionKey;
    private getClient;
}
