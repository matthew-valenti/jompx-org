import * as codebuild from 'aws-cdk-lib/aws-codebuild';
import * as ec2 from 'aws-cdk-lib/aws-ec2';
import * as iam from 'aws-cdk-lib/aws-iam';
import * as s3assets from 'aws-cdk-lib/aws-s3-assets';
import { Construct } from 'constructs';
import { ServiceContractOutput } from '../service-contract-registry/service-contract-output.construct';
import { DatabaseMigrationEngine, DatabaseMigrationExecutorConfig, DatabaseMigrationPropsRuntime, DatabaseMigrationPublishedContract, DatabaseMigrationStoreConfig } from './database-migration.types';
export interface DatabaseMigrationExecutorProps {
    /**
     * VPC where the migration runner build runs.
     */
    vpc: ec2.IVpc;
    /**
     * Subnets where the migration runner build runs.
     */
    vpcSubnets: ec2.SubnetSelection;
    /**
     * AWS organization allowed to assume this Executor build role.
     */
    organizationId: string;
    /**
     * Published Store contract. Pass the full lookup result directly.
     */
    storeContract: DatabaseMigrationPublishedContract<DatabaseMigrationStoreConfig>;
    /**
     * Stable database target database identifier for this Executor.
     */
    targetId: string;
    /**
     * Stable database engine for this Executor.
     */
    engine: DatabaseMigrationEngine;
    /**
     * Security groups the Executor uses when connecting to the target database.
     */
    securityGroupIds: string[];
    /**
     * Connection secret used by the Executor for engines that require credentials.
     */
    secretName?: string;
    /**
     * Asset folder that contains the migration runner source at main.ts.
     */
    assetPath: string;
    /**
     * Optional CodeBuild runtime overrides for the migration runner.
     */
    runtime?: DatabaseMigrationPropsRuntime;
}
/**
 * Executor for database migration workloads.
 *
 * Creates:
 * - the CodeBuild project that runs the packaged migration runner
 * - an Executor role that Orchestrators assume to start and inspect Executor workloads
 *
 * Consumes:
 * - Store config passed directly at construct time
 *
 * Publishes:
 * - Executor config as a ServiceContractOutput
 */
export declare class DatabaseMigrationExecutor extends Construct {
    readonly runnerSourceAsset: s3assets.Asset;
    readonly project: codebuild.Project;
    readonly startBuildRole: iam.Role;
    readonly config: DatabaseMigrationExecutorConfig;
    readonly contractOutput: ServiceContractOutput;
    constructor(scope: Construct, id: string, props: DatabaseMigrationExecutorProps);
}
