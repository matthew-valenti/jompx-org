import * as ec2 from 'aws-cdk-lib/aws-ec2';
import * as ecr from 'aws-cdk-lib/aws-ecr';
import * as ecs from 'aws-cdk-lib/aws-ecs';
import * as iam from 'aws-cdk-lib/aws-iam';
import * as logs from 'aws-cdk-lib/aws-logs';
import { Construct } from 'constructs';
import { ServiceContractOutput } from '../service-contract-registry/service-contract-output.construct';
import { DatabaseMigrationContractReference, DatabaseMigrationContractRegistryConfig, DatabaseMigrationExecutorConfig, DatabaseMigrationPropsRuntime } from './database-migration.types';
export interface DatabaseMigrationExecutorProps {
    /**
     * VPC where migration runner tasks are launched.
     */
    vpc: ec2.IVpc;
    /**
     * Subnets used by migration runner tasks.
     */
    vpcSubnets: ec2.SubnetSelection;
    /**
     * Registry connection details used by the runner to resolve Store config.
     */
    contractRegistry: DatabaseMigrationContractRegistryConfig;
    /**
     * Pointer to the Store contract published by DatabaseMigrationStore.
     */
    storeContractReference: DatabaseMigrationContractReference;
    /**
     * Store roles this Executor is allowed to assume after resolving Store config.
     */
    assumableStoreRoleArns: string[];
    runtime?: DatabaseMigrationPropsRuntime;
}
/**
 * Executor for database migration workloads.
 *
 * Creates:
 * - the ECS resources that run migration workloads
 * - an Executor role that Orchestrators assume to start and inspect Executor workloads
 *
 * Consumes:
 * - Store config from the service contract registry at task runtime
 *
 * Publishes:
 * - Executor config as a ServiceContractOutput
 */
export declare class DatabaseMigrationExecutor extends Construct {
    readonly cluster: ecs.Cluster;
    readonly repository: ecr.Repository;
    readonly taskDefinition: ecs.FargateTaskDefinition;
    readonly container: ecs.ContainerDefinition;
    readonly logGroup: logs.LogGroup;
    readonly subnetIds: string[];
    readonly containerName: string;
    readonly runTaskRole: iam.Role;
    readonly config: DatabaseMigrationExecutorConfig;
    readonly contractOutput: ServiceContractOutput;
    constructor(scope: Construct, id: string, props: DatabaseMigrationExecutorProps);
}
