import * as iam from 'aws-cdk-lib/aws-iam';
import * as lambdaNodejs from 'aws-cdk-lib/aws-lambda-nodejs';
import * as sfn from 'aws-cdk-lib/aws-stepfunctions';
import * as tasks from 'aws-cdk-lib/aws-stepfunctions-tasks';
import { Construct } from 'constructs';
import { ServiceContractOutput } from '../service-contract-registry/service-contract-output.construct';
import { DatabaseMigrationContractReference, DatabaseMigrationContractRegistryConfig, DatabaseMigrationOrchestratorConfig, DatabaseMigrationWorkflowProps } from './database-migration.types';
export interface DatabaseMigrationOrchestratorProps {
    /**
     * Registry connection details used by the workflow to resolve Executor config.
     */
    contractRegistry: DatabaseMigrationContractRegistryConfig;
    /**
     * Pointer to the Executor contract published by DatabaseMigrationExecutor.
     */
    executorContractReference: DatabaseMigrationContractReference;
    /**
     * Executor roles this Orchestrator is allowed to assume when starting migration tasks.
     */
    assumableExecutorRoleArns: string[];
    workflow?: DatabaseMigrationWorkflowProps;
}
/**
 * Orchestrator for database migration executions.
 *
 * Creates:
 * - the Step Functions state machine that validates input and invokes the Executor
 * - an Orchestrator role that callers assume to start Orchestrator executions
 *
 * Consumes:
 * - Executor config from the service contract registry during each workflow execution
 *
 * Publishes:
 * - Orchestrator config as a ServiceContractOutput
 */
export declare class DatabaseMigrationOrchestrator extends Construct {
    readonly stateMachine: sfn.StateMachine;
    readonly validateInput: sfn.Choice;
    readonly lookupExecutorConfig: tasks.LambdaInvoke;
    readonly lookupExecutorConfigFunction: lambdaNodejs.NodejsFunction;
    readonly runTask: sfn.CustomState;
    readonly invalidInput: sfn.Fail;
    readonly success: sfn.Succeed;
    readonly fail: sfn.Fail;
    readonly invokeRole: iam.Role;
    readonly config: DatabaseMigrationOrchestratorConfig;
    readonly contractOutput: ServiceContractOutput;
    constructor(scope: Construct, id: string, props: DatabaseMigrationOrchestratorProps);
}
