import * as iam from 'aws-cdk-lib/aws-iam';
import * as sfn from 'aws-cdk-lib/aws-stepfunctions';
import { Construct } from 'constructs';
import { ServiceContractOutput } from '../service-contract-registry/service-contract-output.construct';
import { DatabaseMigrationExecutorConfig, DatabaseMigrationOrchestratorConfig, DatabaseMigrationPublishedContract, DatabaseMigrationWorkflowProps } from './database-migration.types';
export interface DatabaseMigrationOrchestratorProps {
    executorContract: DatabaseMigrationPublishedContract<DatabaseMigrationExecutorConfig>;
    /**
     * AWS organization allowed to start this Orchestrator.
     */
    organizationId: string;
    workflow?: DatabaseMigrationWorkflowProps;
}
/**
 * Orchestrator for database migration executions.
 *
 * Creates:
 * - the Step Functions state machine that validates input and invokes the Executor
 * - an Orchestrator role that callers assume to start Orchestrator executions
 *
 * Consumes:
 * - Executor config passed directly at construct time
 *
 * Publishes:
 * - Orchestrator config as a ServiceContractOutput
 */
export declare class DatabaseMigrationOrchestrator extends Construct {
    readonly stateMachine: sfn.StateMachine;
    readonly stateMachineRole: iam.Role;
    readonly validateInput: sfn.Choice;
    readonly startBuild: sfn.CustomState;
    readonly defaultDownSteps: sfn.Pass;
    readonly invalidInput: sfn.Fail;
    readonly success: sfn.Succeed;
    readonly fail: sfn.Fail;
    readonly invokeRole: iam.Role;
    readonly config: DatabaseMigrationOrchestratorConfig;
    readonly contractOutput: ServiceContractOutput;
    constructor(scope: Construct, id: string, props: DatabaseMigrationOrchestratorProps);
}
