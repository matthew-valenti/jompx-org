import * as pg from 'pg';
import { PostgresDatabaseClientProps } from './postgres-database-client.types';
export declare class PostgresDatabaseClient {
    private readonly props;
    private pool;
    private client;
    constructor(props: PostgresDatabaseClientProps);
    getPool(): Promise<pg.Pool>;
    getClient(): Promise<pg.Client>;
    createPool(): Promise<pg.Pool>;
    createClient(): Promise<pg.Client>;
    close(): Promise<void>;
    private assertSecret;
}
