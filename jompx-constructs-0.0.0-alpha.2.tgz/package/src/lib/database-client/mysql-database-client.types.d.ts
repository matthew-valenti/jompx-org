export interface MysqlConnectionSecretValue {
    host: string;
    port: number;
    username: string;
    password: string;
    database: string;
}
export interface MysqlDatabaseClientPoolOptions {
    /**
     * Maximum number of connections in the client pool.
     */
    max?: number;
    /**
     * How long an idle connection may remain in the client pool before being closed.
     */
    idleTimeoutMs?: number;
    /**
     * Maximum time to wait when establishing a new database connection before failing.
     */
    connectionTimeoutMs?: number;
}
export interface MysqlDatabaseClientProps {
    secret: MysqlConnectionSecretValue;
    pool?: MysqlDatabaseClientPoolOptions;
}
