export interface DatabaseMigrationGeneratorSchema {
  name: string;
  importPath: string;
}
