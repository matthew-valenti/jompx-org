// rollup.config.cjs
//
// Purpose
//   Build migration assets into dist/libs/database-migration/lib.
//   - .sql files are copied as-is
//   - each migration .ts becomes its own .mjs
//   - helper .ts, npm package, and JSON imports used by that migration are
//     bundled into that one output file
//
// Why not @nx/rollup's withNx()
//   withNx() is oriented around one primary module graph. This migration
//   build needs many independent entry points, custom output naming, and
//   SQL copy behavior that matches the source tree exactly. This file keeps
//   those rules explicit and local.
//
// Supported source shapes
//   case 1: <target>/<timestamp>_<name>.up.sql + .down.sql
//   case 2: <target>/<timestamp>_<name>.ts
//   case 3: <target>/<timestamp>_<name>/migration.ts + local helpers
//   case 4: case 3 plus nested helper folders
//   case 5: case 3 plus shared .ts imports elsewhere in the same target
//   case 6: case 2 or 3 plus bundled npm package or JSON imports
//
// Test hook
//   Set DATABASE_MIGRATION_TEST_EMPTY=1 to force the zero-TypeScript path.
//   This exists so we can exercise the SQL-only build branch through Nx.
//
// Structure
//   Every directory directly under src/lib (e.g. app-sandbox1-db,
//   app-dbadmin, examples) is a target. For TypeScript, this config
//   recognizes:
//   - flat <name>.ts
//   - folder <name>/migration.ts
//   Each matched file becomes one output file at:
//   dist/libs/database-migration/lib/<target>/<name>.mjs.
const fs = require('node:fs/promises');
const { builtinModules } = require('node:module');
const { readdirSync } = require('node:fs');
const path = require('node:path');
const commonjs = require('@rollup/plugin-commonjs');
const { sync: globSync } = require('glob');
const json = require('@rollup/plugin-json');
const { nodeResolve } = require('@rollup/plugin-node-resolve');
const { transform } = require('@swc/core');

const projectRoot = __dirname;
const workspaceRoot = path.resolve(projectRoot, '../..');
const srcDir = path.join(projectRoot, 'src/lib');
const distDir = path.join(workspaceRoot, 'dist', path.relative(workspaceRoot, projectRoot));
const outDir = path.join(distDir, 'lib');
const emptyEntryName = '__sql_only__';
const emptyEntryFile = path.join(projectRoot, 'rollup.empty-entry.mjs');
const migrationEntryPatterns = ['*.ts', '*/migration.ts'];
const forceEmptyEntries = process.env.DATABASE_MIGRATION_TEST_EMPTY === '1';
const builtinModuleIds = new Set([...builtinModules, ...builtinModules.map((id) => `node:${id}`)]);

// Keep only Node built-ins external. npm packages and JSON imports are
// bundled into each migration so the runtime only needs the emitted .mjs.
function external(id) {
  return builtinModuleIds.has(id);
}

// Derives the "<target>/<name>" output key from a source path — collapses
// the `<name>/migration.ts` folder shape down to just `<name>`, matching
// the flat `<name>.ts` shape, so both produce the same output filename.
function entryName(file) {
  const [target, nameOrFolder, fileName] = path.relative(srcDir, file).split(path.sep);

  const name = fileName === 'migration.ts' ? nameOrFolder : path.basename(file, '.ts');

  return `${target}/${name}`;
}

// Copies every .sql file from src/lib to outDir at the same relative path.
// Rollup only touches .ts imports, so .sql assets need this separate pass.
function copySqlFiles() {
  const sqlFiles = globSync('**/*.sql', { cwd: srcDir, nodir: true });

  return Promise.all(
    sqlFiles.map(async (rel) => {
      const from = path.join(srcDir, rel);
      const to = path.join(outDir, rel);

      await fs.mkdir(path.dirname(to), { recursive: true });
      await fs.copyFile(from, to);
    })
  );
}

// Transforms .ts source with swc directly (config passed inline, not via
// .swcrc) so this build stays independent of the lib's normal TS toolchain.
function typescriptMigrationPlugin() {
  return {
    name: 'typescript-migrations',

    async transform(code, filename) {
      if (!filename.endsWith('.ts')) {
        return null;
      }

      return transform(code, {
        filename,
        jsc: {
          parser: {
            syntax: 'typescript',
          },
          target: 'es2022',
        },
        module: {
          type: 'es6',
        },
        sourceMaps: false,
      });
    },
  };
}

// Single plugin covering the build's non-Rollup-default lifecycle steps.
// This is one config/one build now (see module.exports below), so unlike
// the old per-entry array, these hooks each run exactly once.
function outputPlugin(entryCount) {
  return {
    name: 'migration-output',

    // Clear stale output before this build writes new files.
    async buildStart() {
      await fs.rm(outDir, { recursive: true, force: true });
    },

    // With one shared Rollup input containing all migrations, Rollup could
    // in principle factor a helper imported by two migrations into a
    // shared chunk. That would break the "each .mjs is self-contained"
    // guarantee migrations rely on, so treat it as a build error instead.
    async generateBundle(_options, bundle) {
      const sharedChunks = Object.values(bundle).filter((item) => item.type === 'chunk' && !item.isEntry);

      if (sharedChunks.length) {
        this.error(
          `Migration outputs must stay self-contained. Shared chunks emitted: ${sharedChunks
            .map((chunk) => chunk.fileName)
            .join(', ')}`
        );
      }
    },

    // Copy .sql assets once real output exists. When there are no
    // TypeScript entries, Rollup still emitted the placeholder empty entry
    // (see `input` below) purely to satisfy "at least one input" — delete
    // it here so it doesn't leak into dist as a fake migration.
    async writeBundle() {
      await copySqlFiles();

      if (!entryCount) {
        await fs.rm(path.join(outDir, `${emptyEntryName}.mjs`), {
          force: true,
        });
      }
    },

    closeBundle() {
      console.log(`Built ${entryCount} TypeScript migrations.`);
    },
  };
}

// Every top-level directory under src/lib is a target (e.g. app-sandbox1-db,
// app-dbadmin, examples). New targets need no config change here; they are
// picked up automatically by this directory scan.
const targetRoots = readdirSync(srcDir, { withFileTypes: true })
  .filter((entry) => entry.isDirectory())
  .map((entry) => entry.name);

// All migration source files across every target, matching either the flat
// or folder shape (migrationEntryPatterns) — the full set of Rollup inputs.
const discoveredEntries = targetRoots
  .flatMap((target) =>
    migrationEntryPatterns.flatMap((pattern) =>
      globSync(path.posix.join(target, pattern), {
        cwd: srcDir,
        absolute: true,
      })
    )
  )
  .sort((left, right) => left.localeCompare(right));

const entries = forceEmptyEntries ? [] : discoveredEntries;

// Rollup requires at least one input, so the SQL-only branch uses a tiny
// empty module and then deletes its emitted file after copying SQL assets.
const input = entries.length
  ? Object.fromEntries(entries.map((file) => [entryName(file), file]))
  : { [emptyEntryName]: emptyEntryFile };

module.exports = {
  input,
  logLevel: 'silent',
  output: {
    dir: outDir,
    entryFileNames: '[name].mjs',
    format: 'esm',
    sourcemap: false,
  },
  external,
  plugins: [
    typescriptMigrationPlugin(),
    nodeResolve({
      extensions: ['.mjs', '.js', '.json', '.node', '.ts'],
      preferBuiltins: true,
    }),
    commonjs(),
    json(),
    outputPlugin(entries.length),
  ],
};
