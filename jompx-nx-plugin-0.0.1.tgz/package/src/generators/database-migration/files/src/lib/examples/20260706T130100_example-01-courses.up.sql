create table if not exists public.courses (
    id uuid primary key,
    slug text not null unique,
    title text not null
);
