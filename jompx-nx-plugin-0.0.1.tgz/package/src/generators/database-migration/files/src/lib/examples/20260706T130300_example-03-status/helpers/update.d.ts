export declare function updateUsers(status: 'active' | 'pending'): string;
