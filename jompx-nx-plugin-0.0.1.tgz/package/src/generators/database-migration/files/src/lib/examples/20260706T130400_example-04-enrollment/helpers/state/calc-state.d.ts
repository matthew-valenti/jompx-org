export declare function calculateEnrollmentState(completedLessons: number, totalLessons: number): 'not-started' | 'in-progress' | 'completed';
