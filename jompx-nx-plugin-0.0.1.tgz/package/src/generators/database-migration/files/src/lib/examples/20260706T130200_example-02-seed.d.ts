export declare function up(context: unknown): Promise<void>;
export declare function down(context: unknown): Promise<void>;
