export declare function buildActionName(direction: 'up' | 'down'): string;
