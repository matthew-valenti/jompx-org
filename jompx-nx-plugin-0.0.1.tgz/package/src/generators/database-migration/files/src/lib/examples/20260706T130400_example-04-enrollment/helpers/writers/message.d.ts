export declare function buildUpdateMessage(state: 'not-started' | 'in-progress' | 'completed'): string;
