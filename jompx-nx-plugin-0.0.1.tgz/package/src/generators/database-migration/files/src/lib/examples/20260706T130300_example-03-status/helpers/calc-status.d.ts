export declare function calculateStatus(score: number): 'active' | 'pending';
