export declare function formatAuditMessage(action: string): string;
