drop table if exists public.courses;
