"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.databaseMigrationGenerator = databaseMigrationGenerator;
const tslib_1 = require("tslib");
const path = require("path");
const devkit_1 = require("@nx/devkit");
const js_1 = require("@nx/js");
function databaseMigrationGenerator(tree, options) {
    return tslib_1.__awaiter(this, void 0, void 0, function* () {
        var _a, _b;
        // Configure the project.
        const projectRoot = `libs/${options.name}`;
        // e.g. '@learnsnax/database-migration' > ['@learnsnax', 'database-migration']
        // Boolean: remove empty strings in case of bad input.
        const [scope, name] = options.importPath.split('/').filter(Boolean);
        if (options.name !== name) {
            throw new Error(`importPath '${options.importPath}' does not match name '${options.name}'. Did you mean '${scope}/${options.name}'?`);
        }
        // Generate the lib using the built-in Nx library generator (not the typical addProjectConfiguration).
        // This auto creates a best practice Nx lib that we can customize.
        yield (0, js_1.libraryGenerator)(tree, {
            name: options.name,
            directory: `./libs/${options.name}`,
            // TODO: Better practice is to derive the scope from root package.json and not require importPath.
            importPath: options.importPath, // e.g. '@learnsnax/config'
            buildable: true,
            publishable: false,
            bundler: 'rollup', // for cjs/esm
            linter: 'none', // no eslint. developer can add.
            unitTestRunner: 'none', // no jest. developer can add.
            setParserOptionsProject: false,
            skipFormat: true,
            strict: true, // Adds strict and a collection of other tsconfig.json options.
        });
        // Get config and manually update with targets.
        const config = (0, devkit_1.readProjectConfiguration)(tree, options.name);
        config.tags = ['domain:database-migration', 'platform:server'];
        // The libraryGenerator auto creates targets so keep them.
        config.targets = Object.assign(Object.assign({}, config.targets), { 
            // Bug Nx (v20.x+): known Rollup generator bug. Does not generate build. Fix by adding it manually.
            build: {
                executor: '@nx/rollup:rollup',
                outputs: ['{options.outputPath}'],
                options: {
                    main: '{projectRoot}/src/index.ts',
                    outputPath: 'dist/{projectRoot}',
                    tsConfig: '{projectRoot}/tsconfig.lib.json',
                    rollupConfig: '{projectRoot}/rollup.config.cjs',
                    format: ['esm', 'cjs'],
                    generateExportsField: true,
                    useLegacyTypescriptPlugin: false,
                    skipTypeCheck: true, // Skip the redundant type check pass that triggers duplicate .d.ts warnings.
                },
            }, create: {
                executor: '@jompx/nx-plugin:database-migration-create',
            }, up: {
                executor: '@jompx/nx-plugin:database-migration-up',
            }, down: {
                executor: '@jompx/nx-plugin:database-migration-down',
            } });
        // Set lib to dual esm/cjs.
        config.targets.build.options = Object.assign(Object.assign({}, config.targets.build.options), { format: ['esm', 'cjs'], generateExportsField: true });
        config.targets.build = Object.assign(Object.assign({}, config.targets.build), { 
            // Nx’s libraryGenerator sets Rollup but defaults to single-format builds.
            // We patch here to enable dual (CJS+ESM) output and proper package.json exports.
            options: Object.assign(Object.assign({}, config.targets.build.options), { format: ['esm', 'cjs'], generateExportsField: true }) });
        (0, devkit_1.updateProjectConfiguration)(tree, options.name, config);
        // End manually update the config with targets.
        // Generate files based on configuration.
        (0, devkit_1.generateFiles)(tree, path.join(__dirname, 'files'), projectRoot, { tmpl: '' });
        // rollup.config.cjs
        // Add property to withNx( -> useLegacyTypescriptPlugin: false
        // This uses the new official Nx TypeScript plugin and surpreses the warning.
        const rollupConfigPath = `libs/${options.name}/rollup.config.cjs`;
        if (tree.exists(rollupConfigPath)) {
            const content = tree.read(rollupConfigPath, 'utf-8');
            if (!content.includes('useLegacyTypescriptPlugin')) {
                const updated = content.replace(/withNx\(\s*\{([\s\S]*?)\},/, (m) => m.replace(/\},/, `  useLegacyTypescriptPlugin: false,\n},`));
                tree.write(rollupConfigPath, updated);
            }
        }
        // tsconfig.json
        const tsconfigPath = `${projectRoot}/tsconfig.json`;
        if (tree.exists(tsconfigPath)) {
            const tsconfig = tree.read(tsconfigPath, 'utf-8');
            const tsconfigJson = JSON.parse(tsconfig);
            tsconfigJson.compilerOptions.composite = true;
            tsconfigJson.compilerOptions.declaration = true;
            tree.write(tsconfigPath, JSON.stringify(tsconfigJson, null, 2));
        }
        // Fix Nx limitation. Libs require relative paths to be prefixed with ./ in tsconfig.base.json.
        // Remove when Nx provides a way to create an esm library in libraryGenerator.
        const tsconfigBasePath = 'tsconfig.base.json';
        if (tree.exists(tsconfigBasePath)) {
            const tsconfigBaseRaw = tree.read(tsconfigBasePath, 'utf-8');
            const tsconfigBase = JSON.parse(tsconfigBaseRaw);
            if ((_b = (_a = tsconfigBase.compilerOptions) === null || _a === void 0 ? void 0 : _a.paths) === null || _b === void 0 ? void 0 : _b[options.importPath]) {
                tsconfigBase.compilerOptions.paths[options.importPath] = tsconfigBase.compilerOptions.paths[options.importPath].map((p) => (p.startsWith('./') ? p : `./${p}`));
                tree.write(tsconfigBasePath, JSON.stringify(tsconfigBase, null, 2));
            }
        }
        yield (0, devkit_1.formatFiles)(tree);
    });
}
exports.default = databaseMigrationGenerator;
//# sourceMappingURL=database-migration.js.map