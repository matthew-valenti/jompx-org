"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.databaseMigrationGenerator = databaseMigrationGenerator;
const tslib_1 = require("tslib");
const path = require("path");
const devkit_1 = require("@nx/devkit");
const js_1 = require("@nx/js");
const defaultDatabaseMigrationConfigPath = 'database-migration.config.json';
function databaseMigrationGenerator(tree, options) {
    return tslib_1.__awaiter(this, void 0, void 0, function* () {
        var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m, _o, _p;
        const projectRoot = `libs/${options.name}`;
        const rootPackageJson = (0, devkit_1.readJson)(tree, 'package.json');
        const swcCoreVersion = (_d = (_b = (_a = rootPackageJson.devDependencies) === null || _a === void 0 ? void 0 : _a['@swc/core']) !== null && _b !== void 0 ? _b : (_c = rootPackageJson.dependencies) === null || _c === void 0 ? void 0 : _c['@swc/core']) !== null && _d !== void 0 ? _d : '^1.5.0';
        const rollupVersion = (_h = (_f = (_e = rootPackageJson.devDependencies) === null || _e === void 0 ? void 0 : _e.rollup) !== null && _f !== void 0 ? _f : (_g = rootPackageJson.dependencies) === null || _g === void 0 ? void 0 : _g.rollup) !== null && _h !== void 0 ? _h : '^4.0.0';
        const globVersion = (_m = (_k = (_j = rootPackageJson.devDependencies) === null || _j === void 0 ? void 0 : _j.glob) !== null && _k !== void 0 ? _k : (_l = rootPackageJson.dependencies) === null || _l === void 0 ? void 0 : _l.glob) !== null && _m !== void 0 ? _m : '^10.4.5';
        // e.g. '@learnsnax/database-migration' > ['@learnsnax', 'database-migration']
        // Boolean: remove empty strings in case of bad input.
        const [scope, name] = options.importPath.split('/').filter(Boolean);
        if (options.name !== name) {
            throw new Error(`importPath '${options.importPath}' does not match name '${options.name}'. Did you mean '${scope}/${options.name}'?`);
        }
        // Use Nx for the base library scaffold, then replace build behavior below.
        yield (0, js_1.libraryGenerator)(tree, {
            name: options.name,
            directory: `./libs/${options.name}`,
            // TODO: Better practice is to derive the scope from root package.json and not require importPath.
            importPath: options.importPath,
            buildable: true,
            publishable: false,
            bundler: 'tsc', // scaffold only. build is replaced below with raw Rollup.
            linter: 'none',
            unitTestRunner: 'none',
            setParserOptionsProject: false,
            skipFormat: true,
            strict: true,
        });
        // Delete Nx auto generated file: database-migration.ts
        tree.delete((0, devkit_1.joinPathFragments)(projectRoot, `src/lib/${options.name}.ts`));
        const config = (0, devkit_1.readProjectConfiguration)(tree, options.name);
        config.tags = ['domain:database-migration', 'platform:server'];
        config.targets = Object.assign(Object.assign({}, config.targets), { build: {
                executor: 'nx:run-commands',
                cache: true,
                inputs: [
                    'production',
                    '^production',
                    '{projectRoot}/src/**/*.ts',
                    '{projectRoot}/src/**/*.sql',
                    '{projectRoot}/rollup.config.cjs',
                    '{projectRoot}/.swcrc',
                    '{projectRoot}/tsconfig.json',
                    '{projectRoot}/tsconfig.lib.json',
                    '{projectRoot}/package.json',
                    '{projectRoot}/database-migration.config.json',
                ],
                outputs: ['{workspaceRoot}/dist/{projectRoot}'],
                options: {
                    command: `node ./node_modules/rollup/dist/bin/rollup -c ${projectRoot}/rollup.config.cjs --silent`,
                    cwd: '{workspaceRoot}',
                },
            }, create: {
                executor: '@jompx/nx-plugin:database-migration-create',
            }, up: {
                executor: '@jompx/nx-plugin:database-migration-up',
                options: {
                    configPath: defaultDatabaseMigrationConfigPath,
                },
            }, down: {
                executor: '@jompx/nx-plugin:database-migration-down',
                options: {
                    configPath: defaultDatabaseMigrationConfigPath,
                },
            } });
        (0, devkit_1.updateProjectConfiguration)(tree, options.name, config);
        (0, devkit_1.addDependenciesToPackageJson)(tree, {}, {
            '@swc/core': swcCoreVersion,
            glob: globVersion,
            rollup: rollupVersion,
        });
        (0, devkit_1.generateFiles)(tree, path.join(__dirname, 'files'), projectRoot, { tmpl: '', name: options.name });
        const configPath = `${projectRoot}/${defaultDatabaseMigrationConfigPath}`;
        if (!tree.exists(configPath)) {
            (0, devkit_1.generateFiles)(tree, path.join(__dirname, 'config-files'), projectRoot, { tmpl: '' });
        }
        const tsconfigPath = `${projectRoot}/tsconfig.json`;
        if (tree.exists(tsconfigPath)) {
            const tsconfig = tree.read(tsconfigPath, 'utf-8');
            const tsconfigJson = JSON.parse(tsconfig);
            tsconfigJson.compilerOptions.composite = true;
            tsconfigJson.compilerOptions.declaration = true;
            tree.write(tsconfigPath, JSON.stringify(tsconfigJson, null, 2));
        }
        // Fix Nx limitation. Libs require relative paths to be prefixed with ./ in tsconfig.base.json.
        const tsconfigBasePath = 'tsconfig.base.json';
        if (tree.exists(tsconfigBasePath)) {
            const tsconfigBaseRaw = tree.read(tsconfigBasePath, 'utf-8');
            const tsconfigBase = JSON.parse(tsconfigBaseRaw);
            if ((_p = (_o = tsconfigBase.compilerOptions) === null || _o === void 0 ? void 0 : _o.paths) === null || _p === void 0 ? void 0 : _p[options.importPath]) {
                tsconfigBase.compilerOptions.paths[options.importPath] = tsconfigBase.compilerOptions.paths[options.importPath].map((filePath) => (filePath.startsWith('./') ? filePath : `./${filePath}`));
                tree.write(tsconfigBasePath, JSON.stringify(tsconfigBase, null, 2));
            }
        }
        yield (0, devkit_1.formatFiles)(tree);
    });
}
exports.default = databaseMigrationGenerator;
//# sourceMappingURL=database-migration.js.map