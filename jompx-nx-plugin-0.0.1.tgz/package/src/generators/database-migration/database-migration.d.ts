import { Tree } from '@nx/devkit';
import { DatabaseMigrationGeneratorSchema } from './schema';
export declare function databaseMigrationGenerator(tree: Tree, options: DatabaseMigrationGeneratorSchema): Promise<void>;
export default databaseMigrationGenerator;
