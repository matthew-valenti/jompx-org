import { Tree } from '@nx/devkit';
import { OrgFormationGeneratorSchema } from './schema';
export declare function orgFormationGenerator(tree: Tree, options: OrgFormationGeneratorSchema): Promise<void>;
export default orgFormationGenerator;
