"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.orgFormationGenerator = orgFormationGenerator;
const tslib_1 = require("tslib");
const devkit_1 = require("@nx/devkit");
const path = require("path");
function orgFormationGenerator(tree, options) {
    return tslib_1.__awaiter(this, void 0, void 0, function* () {
        // Configure the project.
        const projectRoot = `apps/${options.name}`;
        (0, devkit_1.addProjectConfiguration)(tree, options.name, {
            root: projectRoot,
            projectType: 'application',
            sourceRoot: `${projectRoot}/src`,
            // Registers all custom Nx commands (executors) for this project.
            targets: {
                help: {
                    executor: '@jompx/nx-plugin:org-formation',
                    options: {},
                },
                'create-acm-certificates': {
                    executor: '@jompx/nx-plugin:org-formation-create-acm-certificates',
                    options: {
                        file: 'acm-certificates.yml',
                    },
                },
                'create-route53-subdomains': {
                    executor: '@jompx/nx-plugin:org-formation-create-route53-subdomains',
                    options: {
                        file: 'route53-subdomains.yml',
                    },
                },
                'create-change-set': {
                    executor: '@jompx/nx-plugin:org-formation-create-change-set',
                    options: {
                        file: 'organization.yml',
                    },
                },
                'execute-change-set': {
                    executor: '@jompx/nx-plugin:org-formation-execute-change-set',
                },
                init: {
                    executor: '@jompx/nx-plugin:org-formation-init',
                    options: {
                        file: 'organization.yml',
                    },
                },
                update: {
                    executor: '@jompx/nx-plugin:org-formation-update',
                    options: {
                        file: 'organization.yml',
                    },
                },
            },
        });
        // Add npm packages.
        (0, devkit_1.addDependenciesToPackageJson)(tree, {}, { 'aws-organization-formation': '1.0.16' });
        // Generate files based on configuration.
        (0, devkit_1.generateFiles)(tree, path.join(__dirname, 'files'), projectRoot, Object.assign(Object.assign({}, options), { tmpl: '' }));
        yield (0, devkit_1.formatFiles)(tree);
    });
}
exports.default = orgFormationGenerator;
//# sourceMappingURL=org-formation.js.map