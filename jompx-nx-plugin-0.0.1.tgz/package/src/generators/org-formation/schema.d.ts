export interface OrgFormationGeneratorSchema {
  name: string;
}
