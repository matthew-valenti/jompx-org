"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.bastionGenerator = bastionGenerator;
const tslib_1 = require("tslib");
const devkit_1 = require("@nx/devkit");
const path = require("path");
function bastionGenerator(tree, options) {
    return tslib_1.__awaiter(this, void 0, void 0, function* () {
        const projectRoot = `libs/${options.name}`;
        (0, devkit_1.addProjectConfiguration)(tree, options.name, {
            root: projectRoot,
            projectType: 'library',
            sourceRoot: `${projectRoot}/src`,
            targets: {
                start: {
                    executor: '@jompx/nx-plugin:bastion-start',
                    options: {
                        configPath: 'bastion.config.json',
                    },
                },
                stop: {
                    executor: '@jompx/nx-plugin:bastion-stop',
                    options: {
                        configPath: 'bastion.config.json',
                    },
                },
                patch: {
                    executor: '@jompx/nx-plugin:bastion-patch',
                    options: {
                        configPath: 'bastion.config.json',
                    },
                },
                connect: {
                    executor: '@jompx/nx-plugin:bastion-connect',
                    options: {
                        configPath: 'bastion.config.json',
                    },
                },
            },
        });
        if (!tree.exists('bastion.config.json')) {
            (0, devkit_1.generateFiles)(tree, path.join(__dirname, 'files'), '', { tmpl: '' });
        }
        yield (0, devkit_1.formatFiles)(tree);
    });
}
exports.default = bastionGenerator;
//# sourceMappingURL=bastion.js.map