import { Tree } from '@nx/devkit';
import { BastionGeneratorSchema } from './schema';
export declare function bastionGenerator(tree: Tree, options: BastionGeneratorSchema): Promise<void>;
export default bastionGenerator;
