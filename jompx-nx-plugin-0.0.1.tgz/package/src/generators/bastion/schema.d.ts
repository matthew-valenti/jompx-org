export interface BastionGeneratorSchema {
  name: string;
}
