import { Tree } from '@nx/devkit';
import { AuthorizationGeneratorSchema } from './schema';
export declare function authorizationGenerator(tree: Tree, options: AuthorizationGeneratorSchema): Promise<void>;
export default authorizationGenerator;
