export interface AuthorizationGeneratorSchema {
  name: string;
  importPath: string;
}
