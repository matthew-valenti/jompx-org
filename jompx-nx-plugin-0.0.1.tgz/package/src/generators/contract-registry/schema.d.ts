export interface ContractRegistryGeneratorSchema {
  name: string;
  baseUrl: string;
  region: string;
  registryContextPaths: string;
}
