import { Tree } from '@nx/devkit';
import { ContractRegistryGeneratorSchema } from './schema';
export declare function contractRegistryGenerator(tree: Tree, options: ContractRegistryGeneratorSchema): Promise<void>;
export default contractRegistryGenerator;
