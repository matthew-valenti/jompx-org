"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.contractRegistryGenerator = contractRegistryGenerator;
const tslib_1 = require("tslib");
const devkit_1 = require("@nx/devkit");
function contractRegistryGenerator(tree, options) {
    return tslib_1.__awaiter(this, void 0, void 0, function* () {
        const projectRoot = `libs/${options.name}`;
        const registryContextPaths = options.registryContextPaths
            .split(',')
            .map((registryContextPath) => registryContextPath.trim())
            .filter(Boolean);
        (0, devkit_1.addProjectConfiguration)(tree, options.name, {
            root: projectRoot,
            projectType: 'library',
            sourceRoot: `${projectRoot}/src`,
            targets: {
                publish: {
                    executor: '@jompx/nx-plugin:contract-registry-publish',
                    options: {
                        registryBaseUrl: options.baseUrl,
                        registryRegion: options.region,
                    },
                },
                sync: {
                    executor: '@jompx/nx-plugin:contract-registry-sync',
                    options: {
                        registryBaseUrl: options.baseUrl,
                        registryRegion: options.region,
                        registryContextPaths,
                    },
                },
            },
        });
        yield (0, devkit_1.formatFiles)(tree);
    });
}
exports.default = contractRegistryGenerator;
//# sourceMappingURL=contract-registry.js.map