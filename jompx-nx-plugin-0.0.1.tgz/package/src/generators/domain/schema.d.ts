export interface DomainGeneratorSchema {
  name: string;
  importPath: string;
}
