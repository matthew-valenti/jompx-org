import { Tree } from '@nx/devkit';
import { DomainGeneratorSchema } from './schema';
export declare function domainGenerator(tree: Tree, options: DomainGeneratorSchema): Promise<void>;
export default domainGenerator;
