"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.jgraphqlGenerator = jgraphqlGenerator;
const tslib_1 = require("tslib");
const path = require("path");
const devkit_1 = require("@nx/devkit");
const js_1 = require("@nx/js");
function jgraphqlGenerator(tree, options) {
    return tslib_1.__awaiter(this, void 0, void 0, function* () {
        var _a, _b;
        // Configure the project.
        const projectRoot = `libs/${options.name}`;
        // e.g. '@learnsnax/jgraphql' > ['@learnsnax', 'jgraphql']
        // Boolean: remove empty strings in case of bad input.
        const [scope, name] = options.importPath.split('/').filter(Boolean);
        if (options.name !== name) {
            throw new Error(`importPath '${options.importPath}' does not match name '${options.name}'. Did you mean '${scope}/${options.name}'?`);
        }
        // Generate the lib using the built-in Nx library generator (not the typical addProjectConfiguration).
        // This auto creates a best practice Nx lib that we can customize.
        yield (0, js_1.libraryGenerator)(tree, {
            name: options.name,
            directory: `./libs/${options.name}`,
            // TODO: Better practice is to derive the scope from root package.json and not require importPath.
            importPath: options.importPath, // e.g. '@learnsnax/config'
            buildable: true,
            publishable: false,
            bundler: 'rollup', // for cjs/esm
            linter: 'none', // no eslint. developer can add.
            unitTestRunner: 'none', // no jest. developer can add.
            setParserOptionsProject: false,
            skipFormat: true,
            strict: true, // Adds strict and a collection of other tsconfig.json options.
        });
        // Delete Nx auto generated file: jgraphql.ts
        tree.delete((0, devkit_1.joinPathFragments)(projectRoot, `src/lib/${options.name}.ts`));
        // Get config and manually update with targets.
        const config = (0, devkit_1.readProjectConfiguration)(tree, options.name);
        config.tags = ['domain:graphql-tools'];
        // The libraryGenerator auto creates targets so keep them.
        config.targets = Object.assign(Object.assign({}, config.targets), { 
            // Bug Nx (v20.x+): known Rollup generator bug. Does not generate build. Fix by adding it manually.
            build: {
                executor: '@nx/rollup:rollup',
                outputs: ['{options.outputPath}'],
                options: {
                    main: '{projectRoot}/src/index.ts',
                    outputPath: 'dist/{projectRoot}',
                    tsConfig: '{projectRoot}/tsconfig.lib.json',
                    rollupConfig: '{projectRoot}/rollup.config.cjs',
                    format: ['esm', 'cjs'],
                    generateExportsField: true,
                    useLegacyTypescriptPlugin: false,
                    skipTypeCheck: true, // Skip the redundant type check pass that triggers duplicate .d.ts warnings.
                },
            }, gen: {
                executor: `@jompx/nx-plugin:${options.name}-gen`,
                options: {
                    catalogJsonFile: 'libs/catalog/src/lib/generated/catalog.json',
                    cedarPolicyJsonFile: 'libs/authorization/src/lib/generated/combined-policies.json',
                    principalJsonFile: 'libs/authorization/src/lib/principal.json',
                    outputSchemaFile: 'src/lib/api/schema/schema.graphql',
                },
            }, extract: {
                executor: `@jompx/nx-plugin:${options.name}-extract`,
                options: {
                    catalogJsonFile: 'libs/catalog/src/lib/generated/catalog.json',
                    cedarPolicyJsonFile: 'libs/authorization/src/lib/generated/combined-policies.json',
                    principalJsonFile: 'libs/authorization/src/lib/principal.json',
                    outputSchemaFile: 'src/lib/api/schema/schema.graphql',
                },
            }, codegen: {
                executor: 'nx:run-commands',
                options: {
                    cwd: 'libs/jgraphql',
                    command: 'graphql-codegen --config codegen.yml',
                },
            } });
        // Set lib to dual esm/cjs.
        config.targets.build.options = Object.assign(Object.assign({}, config.targets.build.options), { format: ['esm', 'cjs'], generateExportsField: true });
        config.targets.build = Object.assign(Object.assign({}, config.targets.build), { 
            // Nx’s libraryGenerator sets Rollup but defaults to single-format builds.
            // We patch here to enable dual (CJS+ESM) output and proper package.json exports.
            options: Object.assign(Object.assign({}, config.targets.build.options), { format: ['esm', 'cjs'], generateExportsField: true }) });
        (0, devkit_1.updateProjectConfiguration)(tree, options.name, config);
        // End manually update the config with targets.
        // Generate files based on configuration.
        (0, devkit_1.generateFiles)(tree, path.join(__dirname, 'files'), projectRoot, { tmpl: '' });
        // Add npm packages.
        (0, devkit_1.addDependenciesToPackageJson)(tree, {}, {
            '@graphql-eslint/eslint-plugin': '^4.4.0', // GraphQL ESLint plugin
            graphql: '^16.12.0', // Core GraphQL implementation
            '@graphql-codegen/cli': '^5.0.7', // Main GraphQL Codegen CLI
            '@graphql-codegen/typescript': '^5.0.4', // TS types for schema
            '@graphql-codegen/typescript-operations': '^5.0.2', // TS types for operations
            '@graphql-codegen/typed-document-node': '^6.0.2', // Fully typed document nodes
            '@graphql-codegen/introspection': '^5.0.0', // Introspection schema JSON
        });
        // Create a .gitignore in the schema folder to ensure that generated files are never committed to git.
        // We must do this programmatically after files are generated becuase .gitignore files are not copied by generateFiles().
        // Do NOT put the schema.graphql file in the same folder as codegen generated files.
        tree.write((0, devkit_1.joinPathFragments)(projectRoot, 'src/lib/api/schema/.gitignore'), '*\n!.gitignore\n');
        // Create a .gitignore in the generated folder to ensure that generated files are never committed to git.
        // We must do this programmatically after files are generated becuase .gitignore files are not copied by generateFiles().
        tree.write((0, devkit_1.joinPathFragments)(projectRoot, 'src/lib/api/generated/.gitignore'), '*\n!.gitignore\n');
        // rollup.config.cjs
        // Add property to withNx( -> useLegacyTypescriptPlugin: false
        // This uses the new official Nx TypeScript plugin and surpreses the warning.
        const rollupConfigPath = `libs/${options.name}/rollup.config.cjs`;
        if (tree.exists(rollupConfigPath)) {
            const content = tree.read(rollupConfigPath, 'utf-8');
            if (!content.includes('useLegacyTypescriptPlugin')) {
                const updated = content.replace(/withNx\(\s*\{([\s\S]*?)\},/, (m) => m.replace(/\},/, `  useLegacyTypescriptPlugin: false,\n},`));
                tree.write(rollupConfigPath, updated);
            }
        }
        // tsconfig.json
        const tsconfigPath = `${projectRoot}/tsconfig.json`;
        if (tree.exists(tsconfigPath)) {
            const tsconfig = tree.read(tsconfigPath, 'utf-8');
            const tsconfigJson = JSON.parse(tsconfig);
            tsconfigJson.compilerOptions.composite = true;
            tsconfigJson.compilerOptions.declaration = true;
            tree.write(tsconfigPath, JSON.stringify(tsconfigJson, null, 2));
        }
        // tsconfig.lib.json
        const tsconfigLibPath = `${projectRoot}/tsconfig.lib.json`;
        if (tree.exists(tsconfigLibPath)) {
            const tsconfigLib = tree.read(tsconfigLibPath, 'utf-8');
            const tsconfigLibJson = JSON.parse(tsconfigLib);
            // tsconfigLibJson.include.push('src/**/*.json');
            tsconfigLibJson.include = Array.isArray(tsconfigLibJson.include) ? tsconfigLibJson.include : [];
            tsconfigLibJson.include.push('src/**/*.json');
            tree.write(tsconfigLibPath, JSON.stringify(tsconfigLibJson, null, 2));
        }
        // Fix Nx limitation. Libs require relative paths to be prefixed with ./ in tsconfig.base.json.
        // Remove when Nx provides a way to create an esm library in libraryGenerator.
        const tsconfigBasePath = 'tsconfig.base.json';
        if (tree.exists(tsconfigBasePath)) {
            const tsconfigBaseRaw = tree.read(tsconfigBasePath, 'utf-8');
            const tsconfigBase = JSON.parse(tsconfigBaseRaw);
            if ((_b = (_a = tsconfigBase.compilerOptions) === null || _a === void 0 ? void 0 : _a.paths) === null || _b === void 0 ? void 0 : _b[options.importPath]) {
                tsconfigBase.compilerOptions.paths[options.importPath] = tsconfigBase.compilerOptions.paths[options.importPath].map((p) => (p.startsWith('./') ? p : `./${p}`));
                tree.write(tsconfigBasePath, JSON.stringify(tsconfigBase, null, 2));
            }
        }
        // Add eslint graphql configuration to root eslint.config.mjs.
        const eslintConfigPath = 'eslint.config.mjs';
        if (tree.exists(eslintConfigPath)) {
            let eslintConfigRaw = tree.read(eslintConfigPath, 'utf-8');
            if (!eslintConfigRaw.includes("files: ['**/*.graphql']")) {
                const config = `{
        files: ['**/*.graphql'],
        plugins: {
          '@graphql-eslint': require('@graphql-eslint/eslint-plugin'),
        },
        languageOptions: {
          parser: require('@graphql-eslint/eslint-plugin'),
          parserOptions: {
            schema: 'src/schema.graphql',
            documents: ['src/**/*.graphql'],
          },
        },
        extends: [
          'plugin:@graphql-eslint/schema-recommended',
          'plugin:@graphql-eslint/operations-recommended',
        ],
        rules: {
          '@graphql-eslint/no-deprecated': 'warn',
          '@graphql-eslint/no-unused-fragments': 'error'
        },
      },`;
                // Insert before the closing array bracket.
                eslintConfigRaw = eslintConfigRaw.replace(/\]\s*;?\s*$/, `${config}\n];`);
                tree.write(eslintConfigPath, eslintConfigRaw);
            }
        }
        // TODO: Do we need this or is it best practice and does it belong here?
        // Create .graphqlrc.yml with monorepo-wide globs.
        // Centralizes GraphQL schema/doc locations for various tools.
        //   tree.write(
        //     '.graphqlrc.yml',
        //     `# projects:
        // #   api1:
        // #     schema: "apps/api1/schema.graphql"
        // #     documents: "apps/api1/src/**/*.graphql"
        // #
        // #   api2:
        // #     schema: "apps/api2/schema.graphql"
        // #     documents: "apps/api2/src/**/*.graphql"
        // `
        //   );
        tree.write((0, devkit_1.joinPathFragments)(projectRoot, 'codegen.yml'), `# Example Codegen config with 2 completely independent APIs (separate schemas).

generates:

  ./src/lib/api/generated/api.schema.types.ts:
    schema: ./src/lib/api/schema/api.schema.graphql
    # documents: apps/infra/graphql/**/*.{ts,tsx,graphql}
    plugins:
      - typescript
      - typescript-operations
      - typed-document-node

  ./src/lib/api/generated/api.schema.introspection.json:
    schema: ./src/lib/api/schema/api.schema.graphql
    plugins:
      - introspection

  ./src/lib/api/generated/api.schema.directives.json:
    schema: ./src/lib/api/schema/api.schema.graphql
    plugins:
      - "@jompx/nx-plugin/src/codegen/directives-sidecar.js"
    config:
      includeIntrospectionTypes: false
      sort: true

  # ./src/lib/admin/generated/admin.schema.types.ts:
  #   schema: ./src/lib/admin/schema/admin.schema.graphql
  #   # documents: apps/infra/graphql/**/*.{ts,tsx,graphql}
  #   plugins:
  #     - typescript
  #     - typescript-operations
  #     - typed-document-node

  # ./src/lib/admin/generated/admin.schema.introspection.json:
  #   schema: ./src/lib/admin/schema/admin.schema.graphql
  #   plugins:
  #     - introspection

  # ./src/lib/api2/generated/api2.schema.directives.json:
  #   schema: ./src/lib/api2/schema/api2.schema.graphql
  #   plugins:
  #     - "@jompx/nx-plugin/src/codegen/directives-sidecar.js"
  #   config:
  #     includeIntrospectionTypes: false
  #     sort: true
`);
        yield (0, devkit_1.formatFiles)(tree);
    });
}
exports.default = jgraphqlGenerator;
//# sourceMappingURL=jgraphql.js.map