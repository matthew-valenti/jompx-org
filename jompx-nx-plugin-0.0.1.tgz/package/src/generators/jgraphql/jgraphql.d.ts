import { Tree } from '@nx/devkit';
import { JgraphqlGeneratorSchema } from './schema';
export declare function jgraphqlGenerator(tree: Tree, options: JgraphqlGeneratorSchema): Promise<void>;
export default jgraphqlGenerator;
