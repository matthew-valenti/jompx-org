export interface JgraphqlGeneratorSchema {
  name: string;
  importPath: string;
}
