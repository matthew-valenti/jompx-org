export interface CatalogGeneratorSchema {
  name: string;
  importPath: string;
}
