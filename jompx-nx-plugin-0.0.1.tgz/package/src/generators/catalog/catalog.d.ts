import { Tree } from '@nx/devkit';
import { CatalogGeneratorSchema } from './schema';
export declare function catalogGenerator(tree: Tree, options: CatalogGeneratorSchema): Promise<void>;
export default catalogGenerator;
