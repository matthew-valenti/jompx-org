import { Tree } from '@nx/devkit';
import { PresetGeneratorSchema } from './schema';
export declare function presetGenerator(tree: Tree, options: PresetGeneratorSchema): Promise<void>;
export default presetGenerator;
