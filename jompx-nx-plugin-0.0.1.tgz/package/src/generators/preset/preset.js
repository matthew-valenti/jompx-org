"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.presetGenerator = presetGenerator;
const tslib_1 = require("tslib");
const devkit_1 = require("@nx/devkit");
const path = require("path");
const devkit_2 = require("@nx/devkit");
const devkit_3 = require("@nx/devkit");
//
function presetGenerator(tree, options) {
    return tslib_1.__awaiter(this, void 0, void 0, function* () {
        var _a, _b;
        const jestVersion = '29.7.0';
        // Get nx npm package version. @nx/js and @nx/jest will use the same version.
        const rootPackageJson = (0, devkit_3.readJson)(tree, 'package.json');
        const nxVersion = ((_a = rootPackageJson.devDependencies) === null || _a === void 0 ? void 0 : _a.nx) || ((_b = rootPackageJson.dependencies) === null || _b === void 0 ? void 0 : _b.nx);
        // Add Nx plugin packages: https://nx.dev/plugin-registry
        // Will call addProjectConfiguration (to create the new nx workspace).
        (0, devkit_2.addDependenciesToPackageJson)(tree, {}, {
            '@nx/js': nxVersion,
            jest: jestVersion,
            '@nx/jest': nxVersion,
            '@nx/eslint': nxVersion,
            '@nx/eslint-plugin': nxVersion,
            'typescript-eslint': '^8.0.0',
        });
        // Unfortunately, an nx preset cannot install an npm package and then subsequently call a CLI command.
        // We can install our custom plugins here but they suffer from the same limitation.
        // Instead, users will need to install each custom plugin manually.
        // This is currently nx best practice.
        // import { jompxGenerator } from '../jompx/generator';
        // await jompxGenerator(tree, { name: 'jompx' });
        // Create project directories.
        //   tree.write('apps/.gitkeep', '');
        //   tree.write('libs/.gitkeep', '');
        // Copy root workspace files.
        // We cannot run Jest setup against the schema folder without a root tsconfig.json.
        // And best practice is not to create a nx/js library but rather copy files.
        (0, devkit_1.generateFiles)(tree, path.join(__dirname, 'files/root'), '.', Object.assign(Object.assign({}, options), { tmpl: '' }));
        // TODO: Add custom excludes to .gitignore
        // *.tsbuildinfo
        // Delete default workspace lib if it was created.
        // This is an nx default folder with the same name as the new nx workspace. It's confusing and is not needed.
        tree.delete(`libs/${options.name}`);
        yield (0, devkit_1.formatFiles)(tree);
    });
}
exports.default = presetGenerator;
//# sourceMappingURL=preset.js.map