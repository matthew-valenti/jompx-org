"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.jompxGenerator = jompxGenerator;
const tslib_1 = require("tslib");
const devkit_1 = require("@nx/devkit");
const devkit_2 = require("@nx/devkit");
function jompxGenerator(tree, options) {
    return tslib_1.__awaiter(this, void 0, void 0, function* () {
        // Configure the project.
        const projectRoot = `libs/${options.name}`;
        (0, devkit_1.addProjectConfiguration)(tree, options.name, {
            root: projectRoot,
            projectType: 'library',
            sourceRoot: `${projectRoot}/src`,
            // Registers all custom Nx commands (executors) for this project.
            targets: {
                help: {
                    executor: '@jompx/nx-plugin:jompx',
                    options: {},
                },
                identity: {
                    executor: '@jompx/nx-plugin:jompx-identity',
                    options: {},
                },
                login: {
                    executor: '@jompx/nx-plugin:jompx-login',
                    options: {},
                },
            },
        });
        // Add npm packages.
        (0, devkit_2.addDependenciesToPackageJson)(tree, { '@aws-sdk/client-sso-admin': '3.830.0' }, {});
        yield (0, devkit_1.formatFiles)(tree);
    });
}
exports.default = jompxGenerator;
//# sourceMappingURL=jompx.js.map