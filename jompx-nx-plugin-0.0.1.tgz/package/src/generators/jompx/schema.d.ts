export interface JompxGeneratorSchema {
  name: string;
}
