import { Tree } from '@nx/devkit';
import { JompxGeneratorSchema } from './schema';
export declare function jompxGenerator(tree: Tree, options: JompxGeneratorSchema): Promise<void>;
export default jompxGenerator;
