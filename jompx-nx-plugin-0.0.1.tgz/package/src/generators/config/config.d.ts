import { Tree } from '@nx/devkit';
import { ConfigGeneratorSchema } from './schema';
export declare function configGenerator(tree: Tree, options: ConfigGeneratorSchema): Promise<void>;
export default configGenerator;
