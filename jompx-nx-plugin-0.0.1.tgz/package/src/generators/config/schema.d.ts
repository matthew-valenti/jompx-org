export interface ConfigGeneratorSchema {
  name: string;
  importPath: string;
}
