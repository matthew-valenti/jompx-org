"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.configGenerator = configGenerator;
const tslib_1 = require("tslib");
const devkit_1 = require("@nx/devkit");
const path = require("path");
const js_1 = require("@nx/js");
function configGenerator(tree, options) {
    return tslib_1.__awaiter(this, void 0, void 0, function* () {
        var _a, _b;
        // Configure the project.
        const projectRoot = `libs/${options.name}`;
        // e.g. '@learnsnax/config' > ['@learnsnax', 'config']
        // Boolean: remove empty strings in case of bad input.
        const [scope, name] = options.importPath.split('/').filter(Boolean);
        if (options.name !== name) {
            throw new Error(`importPath '${options.importPath}' does not match name '${options.name}'. Did you mean '${scope}/${options.name}'?`);
        }
        // Generate the lib using the built-in Nx library generator (not the typical addProjectConfiguration).
        // This auto creates a best practice Nx lib that we can customize.
        yield (0, js_1.libraryGenerator)(tree, {
            name: options.name,
            directory: `./libs/${options.name}`,
            // TODO: Better practice is to derive the scope from root package.json and not require importPath.
            importPath: options.importPath, // e.g. '@learnsnax/config'
            buildable: true,
            publishable: false,
            bundler: 'rollup', // for cjs/esm
            linter: 'none', // no eslint. developer can add.
            unitTestRunner: 'none', // no jest. developer can add.
            setParserOptionsProject: false,
            skipFormat: true,
            strict: true, // Adds strict and a collection of other tsconfig.json options.
        });
        // Get config and manually update with targets.
        const config = (0, devkit_1.readProjectConfiguration)(tree, options.name);
        config.tags = ['domain:config', 'platform:server'];
        // The libraryGenerator auto creates targets so keep them.
        config.targets = Object.assign(Object.assign({}, config.targets), { 
            // Bug Nx (v20.x+): known Rollup generator bug. Does not generate build. Fix by adding it manually.
            build: {
                executor: '@nx/rollup:rollup',
                outputs: ['{options.outputPath}'],
                options: {
                    main: '{projectRoot}/src/index.ts',
                    outputPath: 'dist/{projectRoot}',
                    tsConfig: '{projectRoot}/tsconfig.lib.json',
                    rollupConfig: '{projectRoot}/rollup.config.cjs',
                    format: ['esm', 'cjs'],
                    generateExportsField: true,
                    useLegacyTypescriptPlugin: false,
                    skipTypeCheck: true, // Skip the redundant type check pass that triggers duplicate .d.ts warnings.
                },
            }, edit: {
                executor: 'nx:run-commands',
                options: {
                    command: 'docker run --rm -it -v $PWD:/sops -w /sops mozilla/sops:latest sops edit {options.file}',
                },
                configurations: {
                    default: {
                        file: `src/${options.name}.schema.ts`,
                    },
                },
            }, gen: {
                executor: '@jompx/nx-plugin:config-gen',
                options: {
                    schemaFile: `config.schema.ts`,
                    configYamlFile: `config.yaml`,
                    rootSchemaName: 'ConfigSchema',
                    outputSchemaFile: 'generated/schema.generated.json',
                    outputConfigFile: `generated/config.generated.ts`,
                },
            } });
        // Set lib to dual esm/cjs.
        config.targets.build.options = Object.assign(Object.assign({}, config.targets.build.options), { format: ['esm', 'cjs'], generateExportsField: true });
        config.targets.build = Object.assign(Object.assign({}, config.targets.build), { 
            // Nx’s libraryGenerator sets Rollup but defaults to single-format builds.
            // We patch here to enable dual (CJS+ESM) output and proper package.json exports.
            options: Object.assign(Object.assign({}, config.targets.build.options), { format: ['esm', 'cjs'], generateExportsField: true }) });
        (0, devkit_1.updateProjectConfiguration)(tree, options.name, config);
        // End manually update the config with targets.
        // Add npm packages.
        (0, devkit_1.addDependenciesToPackageJson)(tree, { yaml: '^2.8.1', ajv: '^8.17.1', 'ajv-formats': '^3.0.1' }, { '@sinclair/typebox': '^0.34.41' });
        // Generate files based on configuration.
        (0, devkit_1.generateFiles)(tree, path.join(__dirname, 'files'), projectRoot, { tmpl: '' });
        // Create a .gitignore in the generated folder to ensure that generated files are never committed to git.
        // We must do this programmatically after files are generated becuase .gitignore files are not copied by generateFiles().
        tree.write((0, devkit_1.joinPathFragments)(projectRoot, 'src/lib/generated/.gitignore'), '*\n!.gitignore\n');
        // rollup.config.cjs
        // Add property to withNx( -> useLegacyTypescriptPlugin: false
        // This uses the new official Nx TypeScript plugin and surpreses the warning.
        const rollupConfigPath = `libs/${options.name}/rollup.config.cjs`;
        if (tree.exists(rollupConfigPath)) {
            const content = tree.read(rollupConfigPath, 'utf-8');
            if (!content.includes('useLegacyTypescriptPlugin')) {
                const updated = content.replace(/withNx\(\s*\{([\s\S]*?)\},/, (m) => m.replace(/\},/, `  useLegacyTypescriptPlugin: false,\n},`));
                tree.write(rollupConfigPath, updated);
            }
        }
        // tsconfig.json
        const tsconfigPath = `${projectRoot}/tsconfig.json`;
        if (tree.exists(tsconfigPath)) {
            const tsconfig = tree.read(tsconfigPath, 'utf-8');
            const tsconfigJson = JSON.parse(tsconfig);
            tsconfigJson.compilerOptions.composite = true;
            tsconfigJson.compilerOptions.declaration = true;
            tree.write(tsconfigPath, JSON.stringify(tsconfigJson, null, 2));
        }
        // // tsconfig.lib.json
        // const tsconfigLibPath = `${projectRoot}/tsconfig.lib.json`;
        // if (tree.exists(tsconfigLibPath)) {
        //   // Rename tsconfig.json to tsconfig.cdk.json and extend from the base tsconfig.
        //   const tsconfigLib = tree.read(tsconfigLibPath, 'utf-8');
        //   const tsconfigLibJson = JSON.parse(tsconfigLib);
        //   tsconfigLibJson.compilerOptions.emitDeclarationOnly = false;
        //   tsconfigLibJson.compilerOptions.noEmit = false;
        //   tree.write(tsconfigLibPath, JSON.stringify(tsconfigLibJson, null, 2));
        // }
        // // package.json
        // const packageJsonPath = `${projectRoot}/package.json`;
        // if (tree.exists(packageJsonPath)) {
        //   const packageJson = tree.read(packageJsonPath, 'utf-8');
        //   const packageJsonObject = JSON.parse(packageJson);
        //   delete packageJsonObject.main;
        //   packageJsonObject.type = 'module';
        //   packageJsonObject.exports = { '.': { import: './dist/index.js', types: './dist/index.d.ts' } };
        //   packageJsonObject.types = './dist/index.d.ts';
        //   tree.write(packageJsonPath, JSON.stringify(packageJsonObject, null, 2));
        // }
        // Fix Nx limitation. Libs require relative paths to be prefixed with ./ in tsconfig.base.json.
        // Remove when Nx provides a way to create an esm library in libraryGenerator.
        const tsconfigBasePath = 'tsconfig.base.json';
        if (tree.exists(tsconfigBasePath)) {
            const tsconfigBaseRaw = tree.read(tsconfigBasePath, 'utf-8');
            const tsconfigBase = JSON.parse(tsconfigBaseRaw);
            if ((_b = (_a = tsconfigBase.compilerOptions) === null || _a === void 0 ? void 0 : _a.paths) === null || _b === void 0 ? void 0 : _b[options.importPath]) {
                tsconfigBase.compilerOptions.paths[options.importPath] = tsconfigBase.compilerOptions.paths[options.importPath].map((p) => (p.startsWith('./') ? p : `./${p}`));
                tree.write(tsconfigBasePath, JSON.stringify(tsconfigBase, null, 2));
            }
        }
        yield (0, devkit_1.formatFiles)(tree);
    });
}
exports.default = configGenerator;
//# sourceMappingURL=config.js.map