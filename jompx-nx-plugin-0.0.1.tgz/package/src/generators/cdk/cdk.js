"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.cdkGenerator = cdkGenerator;
const tslib_1 = require("tslib");
const devkit_1 = require("@nx/devkit");
const path = require("path");
const devkit_2 = require("@nx/devkit");
/**
 * A generator cannot install a package and then run a CLI command.
 * Instead, manually install the AWS CDK to a new folder and then copy to packages\nx-plugin\src\generators\cdk\files\init
 * npx aws-cdk init app --language typescript
 * @param tree
 * @param options
 */
function cdkGenerator(tree, options) {
    return tslib_1.__awaiter(this, void 0, void 0, function* () {
        var _a;
        const projectRoot = `apps/${options.name}`;
        // Configure the project.
        (0, devkit_1.addProjectConfiguration)(tree, options.name, {
            root: projectRoot,
            projectType: 'application',
            sourceRoot: `${projectRoot}/src`,
            targets: {
                help: {
                    executor: '@jompx/nx-plugin:cdk',
                    options: {},
                },
                bootstrap: {
                    executor: '@jompx/nx-plugin:cdk-bootstrap',
                    options: {
                        cloudformationExecutionPolicies: 'arn:aws:iam::aws:policy/AdministratorAccess',
                    },
                },
                build: {
                    executor: '@nx/js:tsc',
                    options: {
                        main: `${projectRoot}/bin/${options.name}.ts`,
                        outputPath: `${projectRoot}/cdk.out`,
                        tsConfig: `${projectRoot}/tsconfig.json`,
                    },
                },
                test: {
                    executor: '@nx/jest:jest',
                    outputs: ['{options.outputPath}'],
                    options: {
                        jestConfig: `${projectRoot}/jest.config.js`,
                        tsConfig: `${projectRoot}/tsconfig.json`,
                        passWithNoTests: true,
                    },
                },
                list: {
                    executor: '@jompx/nx-plugin:cdk-list',
                },
                synth: {
                    executor: '@jompx/nx-plugin:cdk-synth',
                },
                deploy: {
                    executor: '@jompx/nx-plugin:cdk-deploy',
                },
                destroy: {
                    executor: '@jompx/nx-plugin:cdk-destroy',
                },
                diff: {
                    executor: '@jompx/nx-plugin:cdk-diff',
                },
            },
        });
        // Add CDK related npm packages.
        (0, devkit_2.addDependenciesToPackageJson)(tree, {
            'aws-cdk-lib': '2.201.0',
            constructs: '10.4.2',
        }, { 'aws-cdk': '2.1019.1', 'tsconfig-paths': '4.2.0' });
        // Generate files based on configuration.
        const n = (0, devkit_1.names)(options.name);
        (0, devkit_1.generateFiles)(tree, path.join(__dirname, 'files/init'), projectRoot, { tmpl: '', name: options.name, n });
        const tsconfigPath = `${projectRoot}/tsconfig.json`;
        if (tree.exists(tsconfigPath)) {
            // Rename tsconfig.json to tsconfig.cdk.json and extend from the base tsconfig.
            const tsconfig = tree.read(tsconfigPath, 'utf-8');
            const tsconfigJson = JSON.parse(tsconfig);
            tsconfigJson.extends = '../../tsconfig.base.json';
            tree.write(`${projectRoot}/tsconfig.cdk.json`, JSON.stringify(tsconfigJson, null, 2));
            // Create a new tsconfig.json that in inherits from tsconfig.cdk.json (that developers can modify).
            const newTsconfig = {
                // Extend from the original CDK tsconfig and override properties safely here.
                extends: './tsconfig.cdk.json',
                compilerOptions: {
                    // Required to recognize paths in base.
                    baseUrl: '../../',
                    // Required to use NodeJS global types e.g. console.log
                    types: ['node'],
                    // Do not emit CDK build dist files to disk. There is no need for them.
                    noEmit: true,
                    // Get types from the root node_modules folder.
                    typeRoots: ['../../node_modules/@types'],
                },
                // Required for VSCode Intellisense to recognize lib imports.
                references: [], // e.g. [{ path: '../../libs/domain' }, { path: '../../libs/config' }]
                // Developer to add references to Nx libs manually (as needed) here. e.g.
                // "references": [
                //   { "path": "../../libs/domain" },
                //   { "path": "../../libs/config" }
                // ]
                // Keeps compilation scoped to the CDK source but links to libs correctly.
                include: ['bin/**/*.ts', 'lib/**/*.ts'],
            };
            tree.write(tsconfigPath, JSON.stringify(newTsconfig, null, 2));
        }
        // cdk.json
        // Enable TypeScript paths. In cdk.json add: -r tsconfig-paths/register
        // Use ts-node with tsconfig-paths so Nx lib aliases resolve based on paths in base.tsconfig.json.
        const cdkJsonPath = `${projectRoot}/cdk.json`;
        if (tree.exists(cdkJsonPath)) {
            const cdkJsonObject = tree.read(cdkJsonPath, 'utf-8');
            const cdkJson = JSON.parse(cdkJsonObject);
            // 'npx ts-node' spawns an extra Node process, causing CDK to evaluate the app twice (hence duplicate stacks).
            // Using Node preloads keeps ts-node and tsconfig-paths in the same process so CDK executes the program once.
            // This ensures early loader hooks, correct path alias resolution, and a single CDK synth pass.
            cdkJson.app = `node -r ts-node/register/transpile-only -r tsconfig-paths/register bin/${options.name}.ts`;
            // Old approach results in double CDK outputs (because CDK runs the app twice).
            // cdkJson.app = `${cdkJson.app} -r tsconfig-paths/register`;
        }
        // Each Nx app in a monorepo needs a package.json to define metadata, scripts, or publishing info for build tools.
        // package.json
        const packageJsonPath = `${projectRoot}/package.json`;
        if (tree.exists(packageJsonPath)) {
            const packageJsonObject = JSON.parse('{}');
            packageJsonObject.name = options.name;
            packageJsonObject.private = true;
            tree.write(packageJsonPath, JSON.stringify(packageJsonObject, null, 2));
        }
        // Add apps\infra\contracts.context.json to .gitignore.
        const gitignorePath = `${projectRoot}/.gitignore`;
        if (tree.exists(gitignorePath)) {
            const gitignore = (_a = tree.read(gitignorePath, 'utf-8')) !== null && _a !== void 0 ? _a : '';
            const entries = ['contracts.context.json'];
            const missingEntries = entries.filter((entry) => !gitignore.split(/\r?\n/).includes(entry));
            if (missingEntries.length) {
                tree.write(gitignorePath, `${gitignore.trimEnd()}\n${missingEntries.join('\n')}\n`);
            }
        }
        // Delete unnecessary package.json file. Use the root Nx package.json instead.
        // const packagePath = `${projectRoot}/package.json`;
        // if (tree.exists(packagePath)) {
        //   tree.delete(packagePath);
        // }
        // Nx best practice is to have a jest.config.js in each app.
        // Allow test files to be side-by-side with source files io lib folder.
        // Change:
        //  roots: ['<rootDir>/test'],
        // To:
        //   roots: ['<rootDir>/test', '<rootDir>/lib'],
        // TODO: Unfortunately, do manually for now. This is programatically overly complicated because this file is not JSON format.
        yield (0, devkit_1.formatFiles)(tree);
    });
}
exports.default = cdkGenerator;
//# sourceMappingURL=cdk.js.map