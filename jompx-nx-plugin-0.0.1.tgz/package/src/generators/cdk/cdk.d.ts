import { Tree } from '@nx/devkit';
import { CdkGeneratorSchema } from './schema';
/**
 * A generator cannot install a package and then run a CLI command.
 * Instead, manually install the AWS CDK to a new folder and then copy to packages\nx-plugin\src\generators\cdk\files\init
 * npx aws-cdk init app --language typescript
 * @param tree
 * @param options
 */
export declare function cdkGenerator(tree: Tree, options: CdkGeneratorSchema): Promise<void>;
export default cdkGenerator;
