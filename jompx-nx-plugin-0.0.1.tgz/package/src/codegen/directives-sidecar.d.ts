/**
 * GraphQL Codegen Plugin — Directive Sidecar Generator
 *
 * Why this exists:
 * GraphQL introspection (and the standard Codegen `introspection` plugin)
 * does NOT include applied custom directives on types or fields.
 * That means metadata like:
 *
 *   @physicalName
 *   @lookup
 *   @datasource
 *
 * cannot be recovered from an introspection JSON file.
 *
 * To preserve that metadata, we must read the schema SDL (AST) directly
 * during code generation and emit our own artifact.
 *
 * What this plugin does:
 * - Traverses OBJECT and INTERFACE types
 * - Merges directives from type definitions + extensions
 * - Collects directives applied to:
 *     • types
 *     • fields
 * - Correctly coerces directive argument values
 * - Special-cases JSON scalars (e.g. AWSJSON / JSON)
 * - Emits a deterministic JSON file:
 *
 *   [
 *     {
 *       "name": "TypeName",
 *       "directives": [...],
 *       "fields": [...]
 *     }
 *   ]
 *
 * This file acts as a "directive sidecar" and is consumed by
 * downstream tooling (resolvers, schema mappers, auth layers, etc.).
 *
 * This is the only reliable way to make applied custom directives
 * available outside the GraphQL server runtime.
 */
import type { PluginFunction } from '@graphql-codegen/plugin-helpers';
type Config = {
    /** default: false */
    includeIntrospectionTypes?: boolean;
    /** default: true */
    sort?: boolean;
    /** default: ["AWSJSON","JSON"] */
    jsonScalarNames?: string[];
};
export declare const plugin: PluginFunction<Config>;
export default plugin;
