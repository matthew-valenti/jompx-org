"use strict";
/**
 * GraphQL Codegen Plugin — Directive Sidecar Generator
 *
 * Why this exists:
 * GraphQL introspection (and the standard Codegen `introspection` plugin)
 * does NOT include applied custom directives on types or fields.
 * That means metadata like:
 *
 *   @physicalName
 *   @lookup
 *   @datasource
 *
 * cannot be recovered from an introspection JSON file.
 *
 * To preserve that metadata, we must read the schema SDL (AST) directly
 * during code generation and emit our own artifact.
 *
 * What this plugin does:
 * - Traverses OBJECT and INTERFACE types
 * - Merges directives from type definitions + extensions
 * - Collects directives applied to:
 *     • types
 *     • fields
 * - Correctly coerces directive argument values
 * - Special-cases JSON scalars (e.g. AWSJSON / JSON)
 * - Emits a deterministic JSON file:
 *
 *   [
 *     {
 *       "name": "TypeName",
 *       "directives": [...],
 *       "fields": [...]
 *     }
 *   ]
 *
 * This file acts as a "directive sidecar" and is consumed by
 * downstream tooling (resolvers, schema mappers, auth layers, etc.).
 *
 * This is the only reliable way to make applied custom directives
 * available outside the GraphQL server runtime.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.plugin = void 0;
const graphql_1 = require("graphql");
// --- helpers
const unwrapNamed = (t) => {
    let cur = t;
    let isList = false;
    while ((0, graphql_1.isNonNullType)(cur) || (0, graphql_1.isListType)(cur)) {
        if ((0, graphql_1.isListType)(cur))
            isList = true;
        cur = cur.ofType;
    }
    if (!(0, graphql_1.isNamedType)(cur)) {
        throw new Error('Unexpected non-named input type while unwrapping directive argument type');
    }
    return { named: cur.name, isList };
};
const buildDirectiveArgTypeIndex = (schema) => {
    // directiveName -> (argName -> namedTypeName)
    const idx = new Map();
    for (const d of schema.getDirectives()) {
        const m = new Map();
        for (const a of d.args) {
            m.set(a.name, unwrapNamed(a.type).named);
        }
        idx.set(d.name, m);
    }
    return idx;
};
const tryParseJson = (v) => {
    if (typeof v !== 'string')
        return v;
    try {
        return JSON.parse(v);
    }
    catch (_a) {
        return v;
    }
};
const normalizeJsonValue = (v) => {
    const parsed = tryParseJson(v);
    if (Array.isArray(parsed))
        return parsed.map((item) => normalizeJsonValue(item));
    if (parsed && typeof parsed === 'object') {
        const out = {};
        for (const [k, child] of Object.entries(parsed))
            out[k] = normalizeJsonValue(child);
        return out;
    }
    return parsed;
};
const toOutDirective = (node, argTypeIndex, jsonScalarNames) => {
    var _a, _b;
    const name = node.name.value;
    const argNodes = (_a = node.arguments) !== null && _a !== void 0 ? _a : [];
    if (!argNodes.length)
        return { name, arguments: [] };
    const typesForDir = (_b = argTypeIndex.get(name)) !== null && _b !== void 0 ? _b : new Map();
    // Coerce values with GraphQL util (handles lists/objects/enums/null)
    const raw = {};
    for (const a of argNodes) {
        const argName = a.name.value;
        const v = (0, graphql_1.valueFromASTUntyped)(a.value);
        const typeName = typesForDir.get(argName);
        raw[argName] = typeName && jsonScalarNames.has(typeName) ? normalizeJsonValue(v) : v;
    }
    // Keep your existing “packed JSON string” convention when any arg is JSON-typed
    // Emit standard args in structured form.
    return {
        name,
        arguments: Object.entries(raw).map(([k, v]) => ({ name: k, value: v })),
    };
};
const mergeDirectives = (primary, extensions) => {
    const out = [];
    if (primary === null || primary === void 0 ? void 0 : primary.length)
        out.push(...primary);
    if (extensions === null || extensions === void 0 ? void 0 : extensions.length) {
        for (const d of extensions)
            if (d === null || d === void 0 ? void 0 : d.length)
                out.push(...d);
    }
    return out;
};
const sortByName = (arr) => [...arr].sort((a, b) => a.name.localeCompare(b.name));
// --- plugin
const plugin = (schema, _docs, config) => {
    var _a, _b, _c, _d, _e, _f;
    const includeIntrospectionTypes = (_a = config.includeIntrospectionTypes) !== null && _a !== void 0 ? _a : false;
    const doSort = (_b = config.sort) !== null && _b !== void 0 ? _b : true;
    const jsonScalarNames = new Set((_c = config.jsonScalarNames) !== null && _c !== void 0 ? _c : ['AWSJSON', 'JSON']);
    const argTypeIndex = buildDirectiveArgTypeIndex(schema);
    const out = [];
    for (const [typeName, gqlType] of Object.entries(schema.getTypeMap())) {
        if (!includeIntrospectionTypes && typeName.startsWith('__'))
            continue;
        if (!((0, graphql_1.isObjectType)(gqlType) || (0, graphql_1.isInterfaceType)(gqlType)))
            continue;
        const entityType = gqlType;
        const astNode = entityType.astNode;
        const extNodes = ((_d = entityType.extensionASTNodes) !== null && _d !== void 0 ? _d : []);
        // Type directives: ast + extensions
        const typeDirectives = mergeDirectives(astNode === null || astNode === void 0 ? void 0 : astNode.directives, extNodes === null || extNodes === void 0 ? void 0 : extNodes.map((e) => e.directives)).map((d) => toOutDirective(d, argTypeIndex, jsonScalarNames));
        // Fields: merge by field name across ast + extensions (preserve empties)
        const fieldMap = new Map();
        const addField = (f) => {
            var _a, _b;
            const n = f.name.value;
            const existing = (_a = fieldMap.get(n)) !== null && _a !== void 0 ? _a : [];
            const merged = existing.concat((_b = f.directives) !== null && _b !== void 0 ? _b : []);
            fieldMap.set(n, merged);
        };
        for (const f of (_e = astNode === null || astNode === void 0 ? void 0 : astNode.fields) !== null && _e !== void 0 ? _e : [])
            addField(f);
        for (const e of extNodes !== null && extNodes !== void 0 ? extNodes : [])
            for (const f of (_f = e.fields) !== null && _f !== void 0 ? _f : [])
                addField(f);
        const fields = [];
        for (const [fname, dirs] of fieldMap.entries()) {
            fields.push({
                name: fname,
                directives: (dirs !== null && dirs !== void 0 ? dirs : []).map((d) => toOutDirective(d, argTypeIndex, jsonScalarNames)),
            });
        }
        out.push({ name: typeName, directives: typeDirectives, fields });
    }
    const finalOut = doSort
        ? sortByName(out).map((t) => (Object.assign(Object.assign({}, t), { directives: sortByName(t.directives), fields: sortByName(t.fields).map((f) => (Object.assign(Object.assign({}, f), { directives: sortByName(f.directives) }))) })))
        : out;
    return JSON.stringify(finalOut, null, 4) + '\n';
};
exports.plugin = plugin;
exports.default = exports.plugin;
//# sourceMappingURL=directives-sidecar.js.map