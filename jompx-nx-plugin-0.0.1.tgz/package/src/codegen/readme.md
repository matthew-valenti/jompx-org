# Codegen Plugins

AppSync resolvers need access to directives. Unfortunately, the introspection.json produced by Codegen cannot contain directives. So we're forced to generate a separate file. But we can use Codegen if we create our own custom plugin. Where should that source code live (and it needs to be compiled from .ts)? There's nothing Nx that helps us here.

However, to keep it super simple we can add Codegen plugin files in a custom folder here:
packages\nx-plugin\src\codegen

No package.json changes are required and a compiled .js is output to dist here: dist\packages\nx-plugin\src\codegen

It's a bit of a hack but when we reference our plugin in Codegen we can specify the src folder like this.

plugins: - "@jompx/nx-plugin/src/codegen/directives-sidecar.js"

If we want to go an extra step and change package.json we can probably add this to package.json -- but is it really worth the additional complexity.

```
{
  "exports": {
    "./codegen/directives-sidecar.js": "./dist/codegen/directives-sidecar.js"
  }
}
```
