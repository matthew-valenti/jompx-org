export interface GenExecutorSchema {
  catalogFile: string;
  cedarSchemaFile: string;
  cedarPolicyFilePattern: string;
  outputCombinedCedarPolicyFile: string;
  outputCombinedCedarPolicyJsonFile: string;
}
