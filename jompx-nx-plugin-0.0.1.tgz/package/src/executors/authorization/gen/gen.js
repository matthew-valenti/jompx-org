"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tslib_1 = require("tslib");
const changeCase = require("change-case");
const promises_1 = require("node:fs/promises");
const child_process_1 = require("child_process");
const fg = require("fast-glob");
const path = require("path");
const util_1 = require("util");
const execPromise = (0, util_1.promisify)(child_process_1.exec);
/**
 * A fluent builder for generating structured entity definitions with proper indentation.
 *
 * - Automatically manages indentation levels.
 * - Supports nested blocks for attributes and relationships.
 * - Provides a chainable API for readability and maintainability.
 *
 * Ideal for generating structured text output like Cedar schema, JSON-like schemas, or configuration files.
 */
class EntityFormatter {
    constructor() {
        this.lines = [];
        this.indent = 0;
    }
    indentUp() {
        this.indent++;
        return this;
    }
    indentDown() {
        this.indent--;
        return this;
    }
    add(line) {
        if (Array.isArray(line)) {
            line.forEach((l) => this.lines.push(`${'  '.repeat(this.indent)}${l}`));
        }
        else {
            this.lines.push(`${'  '.repeat(this.indent)}${line}`);
        }
        return this;
    }
    addBlock(header, options = {}, callback) {
        const { addDelimiter = false, addLineSpace = false } = options;
        this.add(`${header} {`).indentUp();
        callback(this);
        this.indentDown().add(`}${addDelimiter ? ';' : ''}`);
        if (addLineSpace) {
            this.lines.push(''); // Adds a blank line after the block
        }
        return this;
    }
    toString() {
        return this.lines.join('\n');
    }
}
const runExecutor = (options, context) => tslib_1.__awaiter(void 0, void 0, void 0, function* () {
    const projectRoot = path.join(context.root, context.projectsConfigurations.projects[context.projectName].root);
    const catalogFile = path.resolve(projectRoot, options.catalogFile);
    const cedarSchemaFile = path.resolve(projectRoot, options.cedarSchemaFile);
    const cedarPolicyFilePattern = path.join(projectRoot, options.cedarPolicyFilePattern);
    const outputCombinedCedarPolicyFile = path.resolve(projectRoot, options.outputCombinedCedarPolicyFile);
    const outputCombinedCedarPolicyJsonFile = path.resolve(projectRoot, options.outputCombinedCedarPolicyJsonFile);
    // Combine policy files.
    const cedarPolicyFilePatternForwardSlashes = cedarPolicyFilePattern.replace(/\\/g, '/');
    const entries = yield fg(cedarPolicyFilePatternForwardSlashes);
    yield mergeFiles(entries, outputCombinedCedarPolicyFile);
    const entriesFilePaths = entries.map((entry) => path.relative(projectRoot, entry));
    console.log(`Found ${entries.length} Cedar policy file(s): ${entriesFilePaths.join(', ')}`);
    // Generate Cedar schema and update the generated section of the Cedar schema file.
    // const { schema }: { schema: jompx.Catalog } = await import(schemaFile);
    const catalog = JSON.parse(yield (0, promises_1.readFile)(catalogFile, 'utf8'));
    const generatedCedarSchema = generateCedarSchema(catalog);
    yield updateCedarSchemaFileAndPreserveSections(generatedCedarSchema, cedarSchemaFile);
    // Validate Cedar policies against Cedar schema.
    const validateCommand = `cedar validate --schema ${cedarSchemaFile} --policies ${outputCombinedCedarPolicyFile} --error-format json`;
    console.log('Validating combined Cedar policies against Cedar schema.');
    try {
        const result = yield execPromise(validateCommand);
        if (result.stdout) {
            console.log('Validation successful:', result.stdout);
        }
    }
    catch (error) {
        console.error('Validation failed:', error);
        return { success: false };
    }
    // Convert Cedar policies to JSON.
    const translatePolicyCommand = `cedar translate-policy --direction cedar-to-json --policies ${outputCombinedCedarPolicyFile} --error-format human`;
    console.log('Converting combined Cedar policies to JSON.');
    try {
        const result = yield execPromise(translatePolicyCommand);
        if (result.stdout) {
            yield (0, promises_1.writeFile)(outputCombinedCedarPolicyJsonFile, JSON.stringify(JSON.parse(result.stdout), null, 2), 'utf-8');
            console.log(`Conversion successful: ${outputCombinedCedarPolicyJsonFile}`);
        }
    }
    catch (error) {
        console.error('Conversion failed:', error);
        return { success: false };
    }
    return {
        success: true,
    };
});
exports.default = runExecutor;
function generateCedarSchema(catalog) {
    var _a, _b;
    const data = [];
    const allEntityNames = new Set([]);
    const operationsForAllEntities = {};
    let formatter;
    // Generate static authorization entities.
    // Match user properties to AppSync Lambda event identiy properties. ' // node_modules@typesaws-lambda\triggerappsync-resolver.d.ts
    formatter = new EntityFormatter();
    formatter
        .add('entity Provider;')
        .add('') // blank line
        .add('entity ApiKey in Provider;')
        .add('') // blank line
        .addBlock('entity IAM in Provider', { addDelimiter: true, addLineSpace: true }, (f) => {
        f.add('"accountId": String,')
            .add('"cognitoIdentityPoolId": String,')
            .add('"cognitoIdentityId": String,')
            .add('"sourceIp": Set<String>,')
            .add('"username": String,')
            .add('"userArn": String,')
            .add('"cognitoIdentityAuthType": String,')
            .add('"cognitoIdentityAuthProvider": String');
    })
        .addBlock('entity CognitoGroup in Provider', { addDelimiter: true, addLineSpace: true }, (f) => {
        f.add('"groupName": String');
    })
        .addBlock('entity CognitoUser in Provider', { addDelimiter: true, addLineSpace: true }, (f) => {
        f.add('"sub": String,')
            .add('"issuer": String,')
            .add('"username": String,')
            .add('"sourceIp": Set<String>,')
            .add('"defaultAuthStrategy": String,')
            .add('"groups": Set<String>');
    })
        .addBlock('entity OIDC in Provider', { addDelimiter: true }, (f) => {
        f.add('"sub": String,').add('"issuer": String');
    })
        .add(''); // blank line
    data.push(formatter.toString());
    // Generate Cedar entities from catalog entities.
    Object.entries((_a = catalog === null || catalog === void 0 ? void 0 : catalog.datasources) !== null && _a !== void 0 ? _a : {}).forEach(([datasourceName, datasourceProps]) => {
        Object.entries(datasourceProps.entities).forEach(([entityName, entityProps]) => {
            var _a, _b, _c, _d, _e, _f, _g;
            // Generally include all entities that are in an AppSync API. Jompx requires at least one AppSync auth directive on every entity.
            if (((_a = entityProps === null || entityProps === void 0 ? void 0 : entityProps.authorization) === null || _a === void 0 ? void 0 : _a.includeInCatalog) || ((_b = entityProps === null || entityProps === void 0 ? void 0 : entityProps.api) === null || _b === void 0 ? void 0 : _b.defaultIncludeInApis.length) > 0) {
                const entityNamePascalCase = `${changeCase.pascalCase((_d = (_c = entityProps === null || entityProps === void 0 ? void 0 : entityProps.api) === null || _c === void 0 ? void 0 : _c.entityNamePrefix) !== null && _d !== void 0 ? _d : '')}${changeCase.pascalCase(entityName)}`;
                const attributes = [];
                // Collect standard attributes.
                Object.entries(entityProps.attributes).forEach(([attributeName, attributeProps]) => {
                    var _a, _b, _c, _d;
                    if ((_a = attributeProps === null || attributeProps === void 0 ? void 0 : attributeProps.authorization) === null || _a === void 0 ? void 0 : _a.includeInCatalog) {
                        const dataType = (_c = (_b = attributeProps === null || attributeProps === void 0 ? void 0 : attributeProps.authorization) === null || _b === void 0 ? void 0 : _b.dataType) !== null && _c !== void 0 ? _c : convertAppSyncDataTypeToCedarDataType((_d = attributeProps === null || attributeProps === void 0 ? void 0 : attributeProps.api) === null || _d === void 0 ? void 0 : _d.returnType);
                        attributes.push({ name: attributeName, dataType });
                    }
                });
                const relationships = [];
                // Collect relationships as attributes.
                Object.entries((_e = entityProps.relationships) !== null && _e !== void 0 ? _e : {}).forEach(([_, relationshipProps]) => {
                    var _a, _b, _c, _d;
                    if ((_a = relationshipProps === null || relationshipProps === void 0 ? void 0 : relationshipProps.authorization) === null || _a === void 0 ? void 0 : _a.includeInCatalog) {
                        const relatedEntityName = relationshipProps.relatedEntity;
                        const relatedEntityDatasource = (_b = relationshipProps.relatedEntityDatasource) !== null && _b !== void 0 ? _b : datasourceName;
                        const relatedEntity = catalog.datasources[relatedEntityDatasource].entities[relatedEntityName];
                        const relatedEntityNameWithPrefix = `${(_d = (_c = relatedEntity === null || relatedEntity === void 0 ? void 0 : relatedEntity.api) === null || _c === void 0 ? void 0 : _c.entityNamePrefix) !== null && _d !== void 0 ? _d : ''}${changeCase.pascalCase(relatedEntityName)}`;
                        const relatedEntityNameWithPrefixPascalCase = changeCase.pascalCase(relatedEntityNameWithPrefix);
                        const relationshipDataType = relationshipProps.type === '1-N'
                            ? `Set<${relatedEntityNameWithPrefixPascalCase}>`
                            : relatedEntityNameWithPrefixPascalCase;
                        relationships.push({ name: relatedEntityNameWithPrefix, dataType: relationshipDataType });
                    }
                });
                formatter = new EntityFormatter();
                formatter.addBlock(`entity ${entityNamePascalCase}`, { addDelimiter: true, addLineSpace: true }, (f) => {
                    attributes.forEach(({ name, dataType }) => f.add(`"${name}": ${dataType},`));
                    relationships.forEach(({ name, dataType }) => f.add(`"${name}": ${dataType},`));
                    f.addBlock('"auth":', {}, (authBlock) => {
                        authBlock.add(`"labels": Set<String>,`);
                    });
                });
                data.push(formatter.toString());
                // Entity
                allEntityNames.add(entityNamePascalCase);
                // Output operations per entity.
                const operations = (_g = (_f = entityProps === null || entityProps === void 0 ? void 0 : entityProps.api) === null || _f === void 0 ? void 0 : _f.operations) === null || _g === void 0 ? void 0 : _g.map((o) => changeCase.pascalCase(o.type));
                operations === null || operations === void 0 ? void 0 : operations.forEach((operation) => {
                    (operationsForAllEntities[operation] || (operationsForAllEntities[operation] = [])).push(entityNamePascalCase);
                });
            }
        });
    });
    // Generate Cedar entities from complex attributes.
    Object.entries((_b = catalog === null || catalog === void 0 ? void 0 : catalog.complexAttributes) !== null && _b !== void 0 ? _b : {}).forEach(([complexAttributeName, complexAttributeProps]) => {
        var _a, _b, _c;
        // Generally include all entities that are in an AppSync API. Jompx requires at least one AppSync auth directive on every entity.
        if (((_a = complexAttributeProps === null || complexAttributeProps === void 0 ? void 0 : complexAttributeProps.authorization) === null || _a === void 0 ? void 0 : _a.includeInCatalog) ||
            ((_b = complexAttributeProps === null || complexAttributeProps === void 0 ? void 0 : complexAttributeProps.api) === null || _b === void 0 ? void 0 : _b.defaultIncludeInApis.length) > 0) {
            const entityNamePascalCase = changeCase.pascalCase(complexAttributeName);
            const attributes = [];
            // Collect standard attributes.
            Object.entries(complexAttributeProps.attributes).forEach(([attributeName, attributeProps]) => {
                var _a, _b, _c, _d;
                if ((_a = attributeProps === null || attributeProps === void 0 ? void 0 : attributeProps.authorization) === null || _a === void 0 ? void 0 : _a.includeInCatalog) {
                    const dataType = (_c = (_b = attributeProps === null || attributeProps === void 0 ? void 0 : attributeProps.authorization) === null || _b === void 0 ? void 0 : _b.dataType) !== null && _c !== void 0 ? _c : convertAppSyncDataTypeToCedarDataType((_d = attributeProps === null || attributeProps === void 0 ? void 0 : attributeProps.api) === null || _d === void 0 ? void 0 : _d.returnType);
                    attributes.push({ name: attributeName, dataType });
                }
            });
            const relationships = [];
            // Collect relationships as attributes.
            Object.entries((_c = complexAttributeProps.relationships) !== null && _c !== void 0 ? _c : {}).forEach(([_, relationshipProps]) => {
                var _a, _b, _c;
                if ((_a = relationshipProps === null || relationshipProps === void 0 ? void 0 : relationshipProps.authorization) === null || _a === void 0 ? void 0 : _a.includeInCatalog) {
                    const relatedEntityName = relationshipProps.relatedEntity;
                    const relatedEntityDatasource = relationshipProps.relatedEntityDatasource; // No fall back to current datasource (for a complex attribute).
                    const relatedEntity = catalog.datasources[relatedEntityDatasource].entities[relatedEntityName];
                    const relatedEntityNamePascalCase = `${(_c = (_b = relatedEntity === null || relatedEntity === void 0 ? void 0 : relatedEntity.api) === null || _b === void 0 ? void 0 : _b.entityNamePrefix) !== null && _c !== void 0 ? _c : ''}${changeCase.pascalCase(relatedEntityName)}`;
                    const relationshipDataType = relationshipProps.type === '1-N' ? `Set<${relatedEntityNamePascalCase}>` : relatedEntityNamePascalCase;
                    relationships.push({ name: relatedEntityNamePascalCase, dataType: relationshipDataType });
                }
            });
            formatter = new EntityFormatter();
            formatter.addBlock(`entity ${entityNamePascalCase}`, { addDelimiter: true, addLineSpace: true }, (f) => {
                attributes.forEach(({ name, dataType }) => f.add(`"${name}": ${dataType},`));
                relationships.forEach(({ name, dataType }) => f.add(`"${name}": ${dataType},`));
                f.addBlock('"auth":', {}, (authBlock) => {
                    authBlock.add(`"labels": Set<String>,`);
                });
            });
            data.push(formatter.toString());
            // Entity
            allEntityNames.add(entityNamePascalCase);
        }
    });
    const contextFormatter = new EntityFormatter();
    contextFormatter.addBlock('context:', {}, (f) => {
        f.add(`"api": String,`);
    });
    const context = contextFormatter.toString().split('\n'); // Split into an array of lines
    // Add action GraphQLObjectAccess to control access on GraphQL objects.
    data.push('// Control access to GraphQL objects.');
    formatter = new EntityFormatter();
    formatter.addBlock('action GraphQLObjectAccess appliesTo', { addDelimiter: true, addLineSpace: true }, (f) => {
        f.add(`principal: [CognitoUser, CognitoGroup, IAM, ApiKey, OIDC],`)
            .add(`resource: [SchemaEntity, ${[...allEntityNames].join(', ')}],`)
            .add(context);
    });
    data.push(formatter.toString());
    // Add action GraphQLFieldAccess to control access on GraphQL object fields.
    data.push('// Control access to GraphQL object fields.');
    formatter = new EntityFormatter();
    formatter.addBlock('action GraphQLFieldAccess appliesTo', { addDelimiter: true, addLineSpace: true }, (f) => {
        f.add('principal: [CognitoUser, CognitoGroup, IAM, ApiKey, OIDC],')
            .add('resource: [SchemaAttribute],')
            .add(context);
    });
    data.push(formatter.toString());
    // Cedar allow one action defintion only. So output an action for each operation and the list of all entities it applies to.
    formatter = new EntityFormatter();
    Object.entries(operationsForAllEntities).forEach(([operation, entityNames]) => {
        formatter = new EntityFormatter();
        formatter.addBlock(`action ${operation} appliesTo`, { addDelimiter: true, addLineSpace: true }, (f) => {
            f.add('principal: [CognitoUser, CognitoGroup, IAM, ApiKey, OIDC],')
                .add(`resource: [SchemaEntity, ${[...entityNames].join(', ')}],`)
                .add(context);
        });
        data.push(formatter.toString());
    });
    return data.join('\n');
}
function convertAppSyncDataTypeToCedarDataType(appSyncDataType) {
    let cedarDataType = 'String';
    switch (appSyncDataType) {
        case 'id':
        case 'string':
        case 'date':
        case 'datetime':
        case 'time':
        case 'timestamp':
        case 'json':
        case 'email':
        case 'url':
        case 'phone':
            cedarDataType = 'String';
            break;
        case 'int':
            cedarDataType = 'Long';
            break;
        case 'float':
            cedarDataType = 'decimal';
            break;
        case 'boolean':
            cedarDataType = 'Bool';
            break;
        case 'ipaddress':
            cedarDataType = 'ipaddr';
            break;
        default:
            cedarDataType = 'String';
        // TODO: Handle type vs enum e.g. cedarDataType = appSyncDataType as jompx.CatalogAuthorizationDataType;
    }
    return cedarDataType;
}
function mergeFiles(files, outputFile) {
    return tslib_1.__awaiter(this, void 0, void 0, function* () {
        const mergedContent = yield Promise.all(files.map((file) => tslib_1.__awaiter(this, void 0, void 0, function* () { return yield (0, promises_1.readFile)(file, 'utf-8'); })));
        yield (0, promises_1.writeFile)(outputFile, mergedContent.join('\n'), 'utf-8');
    });
}
/**
 * The Cedar CLI supports one Cedar schema file only.
 * Allow generated and custom schema to co-exist in the same file.
 * We can't use multiple schema files and merge them because the VSCode Cedar plugin only validates against one schema file.
 * Important: The schema file must have comment sections exactly as specified below.
 *
 * // AUTO-GENERATED CODE - DO NOT EDIT
 * // ...
 * // END AUTO-GENERATED CODE
 *
 * // CUSTOM CODE START - SAFE TO EDIT
 * // ...
 * // CUSTOM CODE END
 *
 * @param generatedCedarSchema
 * @param cedarSchemaFile
 */
function updateCedarSchemaFileAndPreserveSections(generatedCedarSchema, cedarSchemaFile) {
    return tslib_1.__awaiter(this, void 0, void 0, function* () {
        try {
            // Read the file content
            const fileContent = yield (0, promises_1.readFile)(cedarSchemaFile, 'utf8');
            // Verify start and end comment blocks
            const autoGeneratedStart = '// AUTO-GENERATED CODE - DO NOT EDIT';
            const autoGeneratedEnd = '// END AUTO-GENERATED CODE';
            const customCodeStart = '// CUSTOM CODE START - SAFE TO EDIT';
            const customCodeEnd = '// CUSTOM CODE END';
            if (!fileContent.includes(autoGeneratedStart) ||
                !fileContent.includes(autoGeneratedEnd) ||
                !fileContent.includes(customCodeStart) ||
                !fileContent.includes(customCodeEnd)) {
                throw new Error('Cedar schema file does not contain the required comment blocks.');
            }
            // Extract the sections of the file
            const beforeAutoGeneratedBlock = fileContent.split(autoGeneratedStart)[0];
            const afterAutoGeneratedBlock = fileContent.split(autoGeneratedEnd)[1];
            // Construct the updated file content
            const updatedFileContent = `${beforeAutoGeneratedBlock.trim()}\n${autoGeneratedStart}\n${generatedCedarSchema.trim()}\n${autoGeneratedEnd}\n\n${afterAutoGeneratedBlock.trim()}`;
            // Write the updated content back to the original file
            yield (0, promises_1.writeFile)(cedarSchemaFile, updatedFileContent.trim(), 'utf8');
            console.log('Cedar entities file updated successfully!');
        }
        catch (error) {
            throw new Error(`Error updating Cedar schema file: ${error.message}`);
        }
    });
}
//# sourceMappingURL=gen.js.map