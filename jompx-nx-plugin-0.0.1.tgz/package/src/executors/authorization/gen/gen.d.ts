import { PromiseExecutor } from '@nx/devkit';
import { GenExecutorSchema } from './schema';
declare const runExecutor: PromiseExecutor<GenExecutorSchema>;
export default runExecutor;
