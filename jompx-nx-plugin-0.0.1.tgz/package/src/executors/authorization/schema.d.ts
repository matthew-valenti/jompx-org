export interface AuthorizationExecutorSchema {} // eslint-disable-line
