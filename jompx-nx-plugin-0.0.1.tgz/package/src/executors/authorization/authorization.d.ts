import { PromiseExecutor } from '@nx/devkit';
import { AuthorizationExecutorSchema } from './schema';
declare const runExecutor: PromiseExecutor<AuthorizationExecutorSchema>;
export default runExecutor;
