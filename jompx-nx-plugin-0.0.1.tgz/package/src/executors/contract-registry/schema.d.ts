export interface ContractRegistryExecutorSchema {} // eslint-disable-line
