import { PromiseExecutor } from '@nx/devkit';
import { SyncExecutorSchema } from './schema';
declare const runExecutor: PromiseExecutor<SyncExecutorSchema>;
export default runExecutor;
