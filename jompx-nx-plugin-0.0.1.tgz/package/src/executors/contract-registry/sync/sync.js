"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tslib_1 = require("tslib");
const credential_providers_1 = require("@aws-sdk/credential-providers");
const promises_1 = require("node:fs/promises");
const node_path_1 = require("node:path");
const devkit_1 = require("@nx/devkit");
const client_service_contract_registry_1 = require("@jompx/client-service-contract-registry");
function countUniqueContractRows(contextData) {
    return new Set(Object.values(contextData)
        .flatMap((contracts) => contracts)
        .map((contract) => JSON.stringify([
        contract.accountId,
        contract.region,
        contract.environmentName,
        contract.contractName,
        contract.schemaVersion,
    ]))).size;
}
const runExecutor = (options, context) => tslib_1.__awaiter(void 0, void 0, void 0, function* () {
    const registryContextPaths = options.registryContextPaths.map((registryContextPath) => (0, node_path_1.resolve)(context.root, registryContextPath));
    const contextData = yield client_service_contract_registry_1.ServiceContractCdkContext.getContext({
        registry: Object.assign({ baseUrl: options.registryBaseUrl, region: options.registryRegion }, (options.profile ? { credentialsProvider: (0, credential_providers_1.fromIni)({ profile: options.profile }) } : {})),
    });
    yield Promise.all(registryContextPaths.map((registryContextPath) => (0, promises_1.writeFile)(registryContextPath, `${JSON.stringify(contextData, null, 2)}\n`, {
        encoding: 'utf-8',
        flag: 'w',
    })));
    devkit_1.logger.info(`Synchronized ${countUniqueContractRows(contextData)} contract context entries to ${registryContextPaths.join(', ')}.`);
    return {
        success: true,
    };
});
exports.default = runExecutor;
//# sourceMappingURL=sync.js.map