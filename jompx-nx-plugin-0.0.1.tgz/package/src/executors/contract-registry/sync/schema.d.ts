export interface SyncExecutorSchema {
  registryBaseUrl: string;
  registryRegion: string;
  registryContextPaths: string[];
  profile: string;
} // eslint-disable-line
