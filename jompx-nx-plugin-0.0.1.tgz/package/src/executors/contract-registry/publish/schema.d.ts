export interface PublishExecutorSchema {
  accountId: string;
  region: string;
  environmentName: string;
  stackName: string;
  registryBaseUrl: string;
  registryRegion: string;
  profile?: string;
} // eslint-disable-line
