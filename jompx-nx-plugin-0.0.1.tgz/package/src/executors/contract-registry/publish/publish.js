"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tslib_1 = require("tslib");
const devkit_1 = require("@nx/devkit");
const child_process_1 = require("child_process");
const client_service_contract_registry_1 = require("@jompx/client-service-contract-registry");
const credential_providers_1 = require("@aws-sdk/credential-providers");
const serviceContractMarkers = new Set(['ServiceContract', 'ServiceContractOutput']);
function parseServiceContractOutputValue(rawValue) {
    const value = rawValue !== null && rawValue !== void 0 ? rawValue : '';
    try {
        return JSON.parse(value);
    }
    catch (error) {
        return value;
    }
}
const runExecutor = (options, context) => tslib_1.__awaiter(void 0, void 0, void 0, function* () {
    var _a, _b, _c, _d;
    const projectRoot = context.projectsConfigurations.projects[context.projectName].root;
    const describeStacksJson = (0, child_process_1.execFileSync)('aws', [
        'cloudformation',
        'describe-stacks',
        '--stack-name',
        options.stackName,
        '--region',
        options.region,
        ...(options.profile ? ['--profile', options.profile] : []),
    ], {
        encoding: 'utf8',
        cwd: projectRoot,
        shell: true,
    });
    const stack = (_a = JSON.parse(describeStacksJson).Stacks) === null || _a === void 0 ? void 0 : _a[0];
    const groups = {};
    for (const output of (_b = stack === null || stack === void 0 ? void 0 : stack.Outputs) !== null && _b !== void 0 ? _b : []) {
        const rawDescription = (_c = output.Description) !== null && _c !== void 0 ? _c : '';
        let description;
        try {
            description = JSON.parse(rawDescription || '{}');
        }
        catch (error) {
            if (rawDescription.includes('ServiceContract')) {
                throw new Error(`Invalid JSON in ServiceContract output description for ${output.OutputKey}`);
            }
            continue;
        }
        if (!description.jompx || !serviceContractMarkers.has(description.jompx)) {
            continue;
        }
        if (!description.schemaVersion || !description.fieldName) {
            throw new Error(`Invalid ServiceContract output description for ${output.OutputKey}`);
        }
        const key = description.schemaVersion;
        (_d = groups[key]) !== null && _d !== void 0 ? _d : (groups[key] = {
            schemaVersion: description.schemaVersion,
            value: {},
        });
        groups[key].value[description.fieldName] = parseServiceContractOutputValue(output.OutputValue);
    }
    const contracts = new client_service_contract_registry_1.ServiceContractRegistryClient(Object.assign({ baseUrl: options.registryBaseUrl, region: options.registryRegion }, (options.profile ? { credentialsProvider: (0, credential_providers_1.fromIni)({ profile: options.profile }) } : {})));
    let publishedContractProperties = 0;
    const publishedContractPropertyNames = [];
    for (const group of Object.values(groups)) {
        const propertyNames = Object.keys(group.value);
        yield contracts.put({
            accountId: String(options.accountId),
            region: options.region,
            environmentName: options.environmentName,
            contractName: options.stackName,
            schemaVersion: group.schemaVersion,
            value: group.value,
        });
        publishedContractProperties += propertyNames.length;
        publishedContractPropertyNames.push(...propertyNames);
    }
    devkit_1.logger.info(`Published ${publishedContractProperties} service contract ${publishedContractProperties === 1 ? 'property' : 'properties'}${publishedContractPropertyNames.length ? `: ${publishedContractPropertyNames.join(', ')}` : ''}.`);
    return {
        success: true,
    };
});
exports.default = runExecutor;
//# sourceMappingURL=publish.js.map