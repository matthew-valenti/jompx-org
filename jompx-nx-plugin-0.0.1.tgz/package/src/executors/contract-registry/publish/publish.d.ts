import { PromiseExecutor } from '@nx/devkit';
import { PublishExecutorSchema } from './schema';
declare const runExecutor: PromiseExecutor<PublishExecutorSchema>;
export default runExecutor;
