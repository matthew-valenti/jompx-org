import { PromiseExecutor } from '@nx/devkit';
import { ContractRegistryExecutorSchema } from './schema';
declare const runExecutor: PromiseExecutor<ContractRegistryExecutorSchema>;
export default runExecutor;
