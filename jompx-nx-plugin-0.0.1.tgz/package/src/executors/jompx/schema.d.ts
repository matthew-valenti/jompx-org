export interface JompxExecutorSchema {} // eslint-disable-line
