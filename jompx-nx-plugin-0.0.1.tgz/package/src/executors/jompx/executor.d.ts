import { PromiseExecutor } from '@nx/devkit';
import { JompxExecutorSchema } from './schema';
declare const runExecutor: PromiseExecutor<JompxExecutorSchema>;
export default runExecutor;
