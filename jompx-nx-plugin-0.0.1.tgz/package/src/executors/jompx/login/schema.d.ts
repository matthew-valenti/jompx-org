export interface CdkExecutorSchema {
  profile: string;
}
