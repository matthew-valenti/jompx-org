"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tslib_1 = require("tslib");
const child_process_1 = require("child_process");
const runExecutor = (options, context) => tslib_1.__awaiter(void 0, void 0, void 0, function* () {
    const projectRoot = context.projectsConfigurations.projects[context.projectName].root;
    (0, child_process_1.execFileSync)('aws', ['sts', 'get-caller-identity', '--profile', options.profile], {
        stdio: 'inherit',
        cwd: projectRoot,
        shell: true,
    });
    return {
        success: true,
    };
});
exports.default = runExecutor;
//# sourceMappingURL=executor.js.map