export interface IdentityExecutorSchema {
  profile: string;
}
