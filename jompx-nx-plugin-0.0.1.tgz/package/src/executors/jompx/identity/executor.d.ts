import { PromiseExecutor } from '@nx/devkit';
import { IdentityExecutorSchema } from './schema';
declare const runExecutor: PromiseExecutor<IdentityExecutorSchema>;
export default runExecutor;
