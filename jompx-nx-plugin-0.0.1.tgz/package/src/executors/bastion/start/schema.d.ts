export interface StartExecutorSchema {
  key: string;
  configPath?: string;
  profile: string;
} // eslint-disable-line
