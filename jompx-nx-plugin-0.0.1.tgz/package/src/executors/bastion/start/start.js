"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tslib_1 = require("tslib");
const devkit_1 = require("@nx/devkit");
const shared_1 = require("../shared");
const runExecutor = (options, context) => tslib_1.__awaiter(void 0, void 0, void 0, function* () {
    const config = yield (0, shared_1.loadBastionConfig)(context.root, options.configPath);
    const bastion = (0, shared_1.createClientBastion)(config, options.profile);
    devkit_1.logger.info(`Starting bastion "${options.key}"...`);
    yield bastion.start((0, shared_1.resolveBastionReference)(config, options.key));
    devkit_1.logger.info(`Bastion "${options.key}" is running and SSM is online.`);
    return {
        success: true,
    };
});
exports.default = runExecutor;
//# sourceMappingURL=start.js.map