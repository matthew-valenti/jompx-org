import { PromiseExecutor } from '@nx/devkit';
import { StartExecutorSchema } from './schema';
declare const runExecutor: PromiseExecutor<StartExecutorSchema>;
export default runExecutor;
