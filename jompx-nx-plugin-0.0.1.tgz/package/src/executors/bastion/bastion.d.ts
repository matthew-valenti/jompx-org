import { PromiseExecutor } from '@nx/devkit';
import { BastionExecutorSchema } from './schema';
declare const runExecutor: PromiseExecutor<BastionExecutorSchema>;
export default runExecutor;
