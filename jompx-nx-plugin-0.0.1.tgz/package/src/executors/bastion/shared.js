"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.defaultBastionConfigPath = void 0;
exports.loadBastionConfig = loadBastionConfig;
exports.createClientBastion = createClientBastion;
exports.resolveBastionReference = resolveBastionReference;
exports.getBastionConfigEntry = getBastionConfigEntry;
const tslib_1 = require("tslib");
const promises_1 = require("node:fs/promises");
const node_path_1 = require("node:path");
const client_bastion_1 = require("@jompx/client-bastion");
exports.defaultBastionConfigPath = 'bastion.config.json';
function loadBastionConfig(root, configPath) {
    return tslib_1.__awaiter(this, void 0, void 0, function* () {
        var _a;
        const resolvedConfigPath = (0, node_path_1.resolve)(root, configPath !== null && configPath !== void 0 ? configPath : exports.defaultBastionConfigPath);
        let fileContent;
        try {
            fileContent = yield (0, promises_1.readFile)(resolvedConfigPath, 'utf-8');
        }
        catch (error) {
            if (error.code === 'ENOENT') {
                throw new Error(`Bastion config file not found at ${resolvedConfigPath}.`);
            }
            throw error;
        }
        let config;
        try {
            config = JSON.parse(fileContent);
        }
        catch (error) {
            throw new Error(`Bastion config file contains invalid JSON at ${resolvedConfigPath}.`);
        }
        if (!config.bastions || typeof config.bastions !== 'object') {
            throw new Error(`Bastion config file must contain a bastions object at ${resolvedConfigPath}.`);
        }
        for (const [bastion, entry] of Object.entries(config.bastions)) {
            if (!entry || typeof entry !== 'object') {
                throw new Error(`Bastion "${bastion}" must be an object in ${resolvedConfigPath}.`);
            }
            if (entry.mode !== 'shell' && entry.mode !== 'port-forward') {
                throw new Error(`Bastion "${bastion}" must define mode as "shell" or "port-forward" in ${resolvedConfigPath}.`);
            }
            if (entry.mode === 'port-forward' && (!entry.host || entry.remotePort === undefined || entry.localPort === undefined)) {
                throw new Error(`Bastion "${bastion}" must define host, remotePort, and localPort when mode is "port-forward" in ${resolvedConfigPath}.`);
            }
            if ((entry.instanceId && !entry.region) || (!entry.instanceId && entry.region)) {
                throw new Error(`Bastion "${bastion}" must define both instanceId and region in ${resolvedConfigPath}.`);
            }
            if (!entry.instanceId && !entry.region && (!((_a = config.registry) === null || _a === void 0 ? void 0 : _a.baseUrl) || !config.registry.region)) {
                throw new Error(`Bastion "${bastion}" requires registry.baseUrl and registry.region when instanceId and region are not provided in ${resolvedConfigPath}.`);
            }
        }
        return config;
    });
}
function createClientBastion(config, profile) {
    const props = {
        profile,
    };
    if (config.registry) {
        props.registry = {
            baseUrl: config.registry.baseUrl,
            region: config.registry.region,
        };
    }
    if (config.awsCliCommand) {
        props.awsCliCommand = config.awsCliCommand;
    }
    if (config.pollIntervalMs !== undefined) {
        props.pollIntervalMs = config.pollIntervalMs;
    }
    if (config.instanceReadyTimeoutMs !== undefined) {
        props.instanceReadyTimeoutMs = config.instanceReadyTimeoutMs;
    }
    if (config.ssmReadyTimeoutMs !== undefined) {
        props.ssmReadyTimeoutMs = config.ssmReadyTimeoutMs;
    }
    if (config.patchTimeoutMs !== undefined) {
        props.patchTimeoutMs = config.patchTimeoutMs;
    }
    return new client_bastion_1.ClientBastion(props);
}
function resolveBastionReference(config, key) {
    const entry = getBastionConfigEntry(config, key);
    if (entry.instanceId && entry.region) {
        return {
            instanceId: entry.instanceId,
            region: entry.region,
        };
    }
    return key;
}
function getBastionConfigEntry(config, key) {
    const entry = config.bastions[key];
    if (!entry) {
        throw new Error(`Bastion "${key}" not found in bastion config.`);
    }
    return entry;
}
//# sourceMappingURL=shared.js.map