import { BastionReference, ClientBastion, ClientBastionProps } from '@jompx/client-bastion';
export declare const defaultBastionConfigPath = "bastion.config.json";
interface BastionConfigEntry {
    mode: 'shell' | 'port-forward';
    host?: string;
    remotePort?: number;
    localPort?: number;
    instanceId?: string;
    region?: string;
}
interface BastionConfigFile {
    registry?: ClientBastionProps['registry'];
    awsCliCommand?: string;
    pollIntervalMs?: number;
    instanceReadyTimeoutMs?: number;
    ssmReadyTimeoutMs?: number;
    patchTimeoutMs?: number;
    bastions: Record<string, BastionConfigEntry>;
}
export declare function loadBastionConfig(root: string, configPath?: string): Promise<BastionConfigFile>;
export declare function createClientBastion(config: BastionConfigFile, profile: string): ClientBastion;
export declare function resolveBastionReference(config: BastionConfigFile, key: string): BastionReference;
export declare function getBastionConfigEntry(config: BastionConfigFile, key: string): BastionConfigEntry;
export {};
