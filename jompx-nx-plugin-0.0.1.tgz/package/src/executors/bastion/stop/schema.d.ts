export interface StopExecutorSchema {
  key: string;
  configPath?: string;
  profile: string;
} // eslint-disable-line
