import { PromiseExecutor } from '@nx/devkit';
import { StopExecutorSchema } from './schema';
declare const runExecutor: PromiseExecutor<StopExecutorSchema>;
export default runExecutor;
