export interface BastionExecutorSchema {} // eslint-disable-line
