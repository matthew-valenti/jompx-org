"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tslib_1 = require("tslib");
const devkit_1 = require("@nx/devkit");
const shared_1 = require("../shared");
const runExecutor = (options, context) => tslib_1.__awaiter(void 0, void 0, void 0, function* () {
    var _a, _b, _c, _d;
    const config = yield (0, shared_1.loadBastionConfig)(context.root, options.configPath);
    const bastion = (0, shared_1.createClientBastion)(config, options.profile);
    const entry = (0, shared_1.getBastionConfigEntry)(config, options.key);
    const mode = (_a = options.mode) !== null && _a !== void 0 ? _a : entry.mode;
    devkit_1.logger.info(`Connecting to bastion "${options.key}"...`);
    if (mode === 'shell') {
        yield bastion.connect((0, shared_1.resolveBastionReference)(config, options.key), {
            mode: 'shell',
        });
    }
    else {
        if (mode !== 'port-forward') {
            throw new Error(`Bastion "${options.key}" requires mode in the config or executor options.`);
        }
        const host = (_b = options.host) !== null && _b !== void 0 ? _b : entry.host;
        const remotePort = (_c = options.remotePort) !== null && _c !== void 0 ? _c : entry.remotePort;
        const localPort = (_d = options.localPort) !== null && _d !== void 0 ? _d : entry.localPort;
        if (!host) {
            throw new Error(`Bastion "${options.key}" requires host in the config or executor options when mode is "port-forward".`);
        }
        if (remotePort === undefined || localPort === undefined) {
            throw new Error(`Bastion "${options.key}" requires remotePort and localPort in the config or executor options when mode is "port-forward".`);
        }
        yield bastion.connect((0, shared_1.resolveBastionReference)(config, options.key), {
            mode: 'port-forward',
            host,
            remotePort,
            localPort,
        });
    }
    devkit_1.logger.info(`Bastion "${options.key}" connect session ended.`);
    return {
        success: true,
    };
});
exports.default = runExecutor;
//# sourceMappingURL=connect.js.map