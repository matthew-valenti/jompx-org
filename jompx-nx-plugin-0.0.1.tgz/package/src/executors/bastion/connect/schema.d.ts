export interface ConnectExecutorSchema {
  key: string;
  mode?: 'shell' | 'port-forward';
  host?: string;
  remotePort?: number;
  localPort?: number;
  configPath?: string;
  profile: string;
} // eslint-disable-line
