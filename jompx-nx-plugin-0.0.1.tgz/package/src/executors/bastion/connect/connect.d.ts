import { PromiseExecutor } from '@nx/devkit';
import { ConnectExecutorSchema } from './schema';
declare const runExecutor: PromiseExecutor<ConnectExecutorSchema>;
export default runExecutor;
