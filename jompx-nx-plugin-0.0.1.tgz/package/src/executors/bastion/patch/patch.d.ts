import { PromiseExecutor } from '@nx/devkit';
import { PatchExecutorSchema } from './schema';
declare const runExecutor: PromiseExecutor<PatchExecutorSchema>;
export default runExecutor;
