export interface PatchExecutorSchema {
  key: string;
  configPath?: string;
  profile: string;
} // eslint-disable-line
