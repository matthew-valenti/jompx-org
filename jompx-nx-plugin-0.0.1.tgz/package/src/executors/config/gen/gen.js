"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tslib_1 = require("tslib");
const ajv_formats_1 = require("ajv-formats");
const _2020_1 = require("ajv/dist/2020");
const path = require("path");
const node_module_1 = require("node:module");
const promises_1 = require("node:fs/promises");
const yaml_1 = require("yaml");
const node_path_1 = require("node:path");
const devkit_1 = require("@nx/devkit");
// Because this plugin is compiled to CommonJS, TypeScript rewrites `await import(url)` into `require(url)`.
// `require` cannot load ESM modules or file:// URLs. Wrapping `import()` in `new Function` prevents that
// rewrite and guarantees a real dynamic import, which lets Node load the consumer’s ESM schema correctly.
// Leave this function commented out until the plugin is ESM and we've confirmed that we do not need it.
// const dynImport: (u: string) => Promise<any> =
//   // avoid TS → require() transform in CJS builds
//   new Function('u', 'return import(u)') as any;
// Take an in-memory schema (from TypeBox or AJV).
// Serializes it with JSON.stringify(schema, null, 2) -> deterministic, pretty-printed output.
// Return a string that is valid TypeScript source code:
function toGeneratedTs(schema) {
    return `// AUTO-GENERATED. DO NOT EDIT.
  export const config = ${JSON.stringify(schema, null, 2)} as const;
`;
}
const runExecutor = (options, context) => tslib_1.__awaiter(void 0, void 0, void 0, function* () {
    const projectRoot = path.join(context.root, context.projectsConfigurations.projects[context.projectName].root);
    const sourceCodePath = 'src/lib';
    // 1. Get the Typebox schema file source code (not dist) and convert it into JSON schema.
    // We need a compiled version of the schema file. So we can either compile it ourselves here or get the file from the Nx project dist.
    // Dist works but creates a circular dependency i.e. build depends on generator which depends on build.
    // There are two basic approaches that can be used here (ts-node or esbuild-register).
    // The esbuild-register approach is simpler and faster, so we use that here.
    const schemaTsPath = (0, node_path_1.resolve)(projectRoot, sourceCodePath, options.schemaFile);
    // Hook in esbuild-register. The esbuild-register package should be a dependency in the Nx plugin package.json.
    // The Nx project using the plugin will install esbuild-register when the plugin package is installed.
    const { register } = require('esbuild-register/dist/node');
    const { unregister } = register({ target: 'es2020', jsx: 'transform' });
    // Dynamically require the user’s schema TS file using the project’s resolver.
    // Get the configured root export (e.g. "ConfigSchema"); throw if missing.
    // Always call `unregister()` to clean up the esbuild-register hook afterwards.
    let schema;
    try {
        const requireFromProject = (0, node_module_1.createRequire)((0, node_path_1.resolve)(projectRoot, 'package.json'));
        const mod = requireFromProject(schemaTsPath);
        const root = options.rootSchemaName;
        schema = mod[root];
        if (!schema)
            throw new Error(`Export "${root}" not found in ${schemaTsPath}`);
    }
    finally {
        unregister();
    }
    // Output the generated JSON schema.
    const schemaOutPath = (0, node_path_1.resolve)(projectRoot, sourceCodePath, options.outputSchemaFile);
    yield (0, promises_1.mkdir)((0, node_path_1.dirname)(schemaOutPath), { recursive: true });
    yield (0, promises_1.writeFile)(schemaOutPath, JSON.stringify(schema, null, 2), 'utf8');
    devkit_1.logger.info(`✔ Schema generated: ${schemaOutPath}`);
    // Delete this "dist" approach when the above approach is confirmed working!
    // const schemaJsPath = resolve(
    //   workspaceRoot,
    //   'dist',
    //   projectRoot,
    //   sourceCodePath,
    //   options.schemaFile.replace(/\.ts$/, '.js')
    // );
    // await access(schemaJsPath, constants.F_OK).catch(() => {
    //   throw new Error(`Missing built schema: ${schemaJsPath}`);
    // });
    // const url = pathToFileURL(schemaJsPath).href;
    // const mod = await dynImport(url + `?v=${Date.now()}`); // cache-bust for rebuilds
    // const root = options.rootSchemaName;
    // const schema = mod[root];
    // if (!schema) throw new Error(`Export "${root}" not found in ${schemaJsPath}`);
    // Best practice ESM compatible code.
    // Replace the statements above including the dynImport hack and function when this Nx plugin is ESM.
    // const url = pathToFileURL(schemaJsPath).href;
    // const mod = await import(url); // native dynamic import (ESM)
    // const root = options.rootSchemaName;
    // const schema = (mod as Record<string, unknown>)[root];
    // if (!schema) throw new Error(`Export "${root}" not found in ${schemaJsPath}`);
    // const out = resolve(projectRoot, sourceCodePath, options.outputSchemaFile);
    // await mkdir(dirname(out), { recursive: true });
    // await writeFile(out, JSON.stringify(schema, null, 2), 'utf8');
    // logger.info(`✔ Schema generated: ${out}`);
    // 2. Read the YAML config file (possibly sops-encrypted) and validate it against the schema.
    // TODO: SOPS decrypt to plaintext (see commented code).
    const dataPath = (0, node_path_1.resolve)(projectRoot, sourceCodePath, options.configYamlFile);
    const plaintext = yield (0, promises_1.readFile)(dataPath, 'utf8');
    // const plaintext = execFileSync('sops', ['-d', dataPath], { encoding: 'utf8' });
    const data = (0, yaml_1.parse)(plaintext);
    // Validate the config data against the schema using AJV.
    // Ajv best-practice tweaks: keep strict & allErrors; allowUnionTypes helps with hand-authored/TypeBox unions.
    const ajv = new _2020_1.default({
        allErrors: true,
        strict: true,
        allowUnionTypes: true,
    });
    (0, ajv_formats_1.default)(ajv);
    const validate = ajv.compile(schema);
    const ok = validate(data);
    if (!ok) {
        // Detailed structured errors first.
        devkit_1.logger.error(JSON.stringify(validate.errors, null, 2));
        // Then the concise summary.
        devkit_1.logger.error(ajv.errorsText(validate.errors, { separator: '\n' }));
        return { success: false };
    }
    // 3. Generate the TypeScript config file.
    // We've defined a TypeBox schema and use it to validate the YAML config file (that contains config data).
    // Now we generate a TypeScript file that exports the config data as a constant named "config".
    // The config data is strongly typed as "Config" (derived from the TypeBox schema).
    // This way, TS code that imports the config file gets strong typing and autocompletion for free.
    const configOutPath = (0, node_path_1.resolve)(projectRoot, sourceCodePath, options.outputConfigFile);
    yield (0, promises_1.mkdir)((0, node_path_1.dirname)(configOutPath), { recursive: true });
    const ts = `import type { ${options.rootSchemaName} } from '../${options.schemaFile.replace('.ts', '.js')}';
import type { Static } from '@sinclair/typebox';
export type Config = Static<typeof ${options.rootSchemaName}>;
export const config: Config = ${JSON.stringify(data, null, 2)} as const;
`;
    yield (0, promises_1.writeFile)(configOutPath, ts, 'utf8');
    devkit_1.logger.info(`✔ Config generated: ${configOutPath}`);
    return { success: true };
});
exports.default = runExecutor;
//# sourceMappingURL=gen.js.map