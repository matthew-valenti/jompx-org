export interface GenExecutorSchema {
  schemaFile: string;
  configYamlFile: string;
  rootSchemaName: string;
  outputSchemaFile: string;
  outputConfigFile?: string;
}
