"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tslib_1 = require("tslib");
const runExecutor = (options) => tslib_1.__awaiter(void 0, void 0, void 0, function* () {
    console.log(`
    Config Nx Plugin

    Available commands:
    nx run config:edit
    nx run config:validate [--schemaFile <file>] [--configYamlFile <file>] [--rootSchemaName <name>] [--outputSchemaFile <file>]
  `);
    return {
        success: true,
    };
});
exports.default = runExecutor;
//# sourceMappingURL=config.js.map