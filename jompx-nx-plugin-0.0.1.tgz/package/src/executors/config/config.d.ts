import { PromiseExecutor } from '@nx/devkit';
import { ConfigExecutorSchema } from './schema';
declare const runExecutor: PromiseExecutor<ConfigExecutorSchema>;
export default runExecutor;
