export interface DownExecutorSchema {
  targetId: string;
  configPath?: string;
  profile: string;
  downSteps?: number;
} // eslint-disable-line
