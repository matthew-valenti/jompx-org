export interface DownExecutorSchema {
  stateMachineArn: string;
  targetId: string;
  engine: string;
  artifactBucketName: string;
  artifactObjectKey: string;
  secretName: string;
  securityGroupIds?: string[];
  profile?: string;
  region?: string;
} // eslint-disable-line
