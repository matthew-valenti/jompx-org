import { PromiseExecutor } from '@nx/devkit';
import { DownExecutorSchema } from './schema';
declare const runExecutor: PromiseExecutor<DownExecutorSchema>;
export default runExecutor;
