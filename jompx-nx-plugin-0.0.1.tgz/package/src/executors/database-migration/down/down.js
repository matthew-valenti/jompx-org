"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tslib_1 = require("tslib");
const devkit_1 = require("@nx/devkit");
const client_database_migration_1 = require("@jompx/client-database-migration");
const shared_1 = require("../shared");
const runExecutor = (options, context) => tslib_1.__awaiter(void 0, void 0, void 0, function* () {
    devkit_1.logger.info('Starting migration down...');
    const result = yield (0, client_database_migration_1.runDatabaseMigration)(Object.assign(Object.assign({}, (yield (0, shared_1.getRunDatabaseMigrationProps)(options, context, 'down'))), (options.downSteps !== undefined ? { downSteps: options.downSteps } : {})));
    devkit_1.logger.info(JSON.stringify(result, null, 2));
    return {
        success: true,
    };
});
exports.default = runExecutor;
//# sourceMappingURL=down.js.map