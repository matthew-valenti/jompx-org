"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tslib_1 = require("tslib");
const child_process_1 = require("child_process");
const runExecutor = (options, context) => tslib_1.__awaiter(void 0, void 0, void 0, function* () {
    const projectRoot = context.projectsConfigurations.projects[context.projectName].root;
    const input = JSON.stringify({
        targetId: options.targetId,
        engine: options.engine,
        artifactBucketName: options.artifactBucketName,
        artifactObjectKey: options.artifactObjectKey,
        direction: 'down',
        secretName: options.secretName,
        securityGroupIds: options.securityGroupIds,
    });
    (0, child_process_1.execFileSync)('aws', [
        'stepfunctions',
        'start-execution',
        '--state-machine-arn',
        options.stateMachineArn,
        '--input',
        input,
        ...(options.profile ? ['--profile', options.profile] : []),
        ...(options.region ? ['--region', options.region] : []),
    ], {
        stdio: 'inherit',
        cwd: projectRoot,
        shell: true,
    });
    return {
        success: true,
    };
});
exports.default = runExecutor;
//# sourceMappingURL=down.js.map