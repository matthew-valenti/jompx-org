import { PromiseExecutor } from '@nx/devkit';
import { DatabaseMigrationExecutorSchema } from './schema';
declare const runExecutor: PromiseExecutor<DatabaseMigrationExecutorSchema>;
export default runExecutor;
