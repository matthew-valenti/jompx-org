"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getRunDatabaseMigrationProps = getRunDatabaseMigrationProps;
const tslib_1 = require("tslib");
const promises_1 = require("node:fs/promises");
const node_path_1 = require("node:path");
const credential_providers_1 = require("@aws-sdk/credential-providers");
const defaultDatabaseMigrationConfigPath = 'database-migration.config.json';
function loadDatabaseMigrationConfig(root, projectRoot, configPath) {
    return tslib_1.__awaiter(this, void 0, void 0, function* () {
        const resolvedConfigPath = (0, node_path_1.resolve)(root, projectRoot, configPath !== null && configPath !== void 0 ? configPath : defaultDatabaseMigrationConfigPath);
        let fileContent;
        try {
            fileContent = yield (0, promises_1.readFile)(resolvedConfigPath, 'utf-8');
        }
        catch (error) {
            if (error.code === 'ENOENT') {
                throw new Error(`Database migration config file not found at ${resolvedConfigPath}.`);
            }
            throw error;
        }
        let config;
        try {
            config = JSON.parse(fileContent);
        }
        catch (error) {
            throw new Error(`Database migration config file contains invalid JSON at ${resolvedConfigPath}.`);
        }
        if (!config.targets || typeof config.targets !== 'object') {
            throw new Error(`Database migration config file must contain a targets object at ${resolvedConfigPath}.`);
        }
        return config;
    });
}
function getDatabaseMigrationTargetConfig(config, targetId) {
    var _a, _b;
    const target = config.targets[targetId];
    if (!target) {
        throw new Error(`Database migration target "${targetId}" not found in database migration config.`);
    }
    if (!((_a = target.databaseName) === null || _a === void 0 ? void 0 : _a.trim())) {
        throw new Error(`Database migration target "${targetId}" must define databaseName in database migration config.`);
    }
    if (!((_b = target.migrationFilesPath) === null || _b === void 0 ? void 0 : _b.trim())) {
        throw new Error(`Database migration target "${targetId}" must define migrationFilesPath in database migration config.`);
    }
    return target;
}
function getRequiredTargetValue(targetId, fieldName, defaultValue, targetValue) {
    const value = defaultValue || targetValue
        ? Object.assign(Object.assign({}, defaultValue), targetValue) : undefined;
    if (!value || typeof value !== 'object') {
        throw new Error(`Database migration target "${targetId}" must define ${fieldName} either in target config or defaults.`);
    }
    return value;
}
function getRunDatabaseMigrationProps(options, context, direction) {
    return tslib_1.__awaiter(this, void 0, void 0, function* () {
        var _a;
        const projectRoot = context.projectsConfigurations.projects[context.projectName].root;
        const config = yield loadDatabaseMigrationConfig(context.root, projectRoot, options.configPath);
        const target = getDatabaseMigrationTargetConfig(config, options.targetId);
        const defaults = (_a = config.defaults) !== null && _a !== void 0 ? _a : {};
        const credentialsProvider = (0, credential_providers_1.fromIni)({ profile: options.profile });
        const submission = getRequiredTargetValue(options.targetId, 'submission', defaults.submission, target.submission);
        const registry = getRequiredTargetValue(options.targetId, 'registry', defaults.registry, target.registry);
        const orchestratorContract = getRequiredTargetValue(options.targetId, 'orchestratorContract', defaults.orchestratorContract, target.orchestratorContract);
        const executorContract = getRequiredTargetValue(options.targetId, 'executorContract', defaults.executorContract, target.executorContract);
        // Keep the executor aligned with the new client shape while published types catch up.
        return {
            credentialsProvider,
            submission: {
                baseUrl: submission.baseUrl,
                region: submission.region,
            },
            registry: {
                baseUrl: registry.baseUrl,
                region: registry.region,
            },
            orchestratorContract: {
                name: orchestratorContract.name,
                accountId: orchestratorContract.accountId,
                region: orchestratorContract.region,
                schemaVersion: orchestratorContract.schemaVersion,
            },
            executorContract: {
                name: executorContract.name,
                accountId: executorContract.accountId,
                region: executorContract.region,
                schemaVersion: executorContract.schemaVersion,
            },
            databaseName: target.databaseName,
            migrationFilesPath: (0, node_path_1.resolve)(context.root, target.migrationFilesPath),
            direction,
        };
    });
}
//# sourceMappingURL=shared.js.map