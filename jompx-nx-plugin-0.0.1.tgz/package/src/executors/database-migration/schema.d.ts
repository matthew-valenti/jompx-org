export interface DatabaseMigrationExecutorSchema {} // eslint-disable-line
