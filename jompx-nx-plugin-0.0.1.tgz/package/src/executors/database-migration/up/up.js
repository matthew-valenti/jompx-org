"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tslib_1 = require("tslib");
const node_path_1 = require("node:path");
const credential_providers_1 = require("@aws-sdk/credential-providers");
const client_database_migration_1 = require("@jompx/client-database-migration");
const runExecutor = (options, context) => tslib_1.__awaiter(void 0, void 0, void 0, function* () {
    const projectRoot = context.projectsConfigurations.projects[context.projectName].root;
    yield (0, client_database_migration_1.runDatabaseMigration)(Object.assign({ submission: Object.assign({ baseUrl: options.submission.baseUrl, region: options.submission.region }, (options.profile ? { credentialsProvider: (0, credential_providers_1.fromIni)({ profile: options.profile }) } : {})), orchestratorContract: {
            name: options.orchestratorContract.name,
            accountId: options.orchestratorContract.accountId,
            region: options.orchestratorContract.region,
            schemaVersion: options.orchestratorContract.schemaVersion,
        }, executorContract: {
            name: options.executorContract.name,
            accountId: options.executorContract.accountId,
            region: options.executorContract.region,
            schemaVersion: options.executorContract.schemaVersion,
        }, databaseName: options.databaseName, migrationFilesPath: (0, node_path_1.resolve)(context.root, projectRoot, options.migrationFilesPath), direction: 'up' }, (options.profile ? { credentialsProvider: (0, credential_providers_1.fromIni)({ profile: options.profile }) } : {})));
    return {
        success: true,
    };
});
exports.default = runExecutor;
//# sourceMappingURL=up.js.map