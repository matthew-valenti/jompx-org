"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tslib_1 = require("tslib");
const devkit_1 = require("@nx/devkit");
const client_database_migration_1 = require("@jompx/client-database-migration");
const shared_1 = require("../shared");
const runExecutor = (options, context) => tslib_1.__awaiter(void 0, void 0, void 0, function* () {
    devkit_1.logger.info('Starting migration up...');
    const result = yield (0, client_database_migration_1.runDatabaseMigration)(yield (0, shared_1.getRunDatabaseMigrationProps)(options, context, 'up'));
    devkit_1.logger.info(JSON.stringify(result, null, 2));
    return {
        success: true,
    };
});
exports.default = runExecutor;
//# sourceMappingURL=up.js.map