export interface UpExecutorSchema {
  submission: {
    baseUrl: string;
    region: string;
  };
  profile: string;
  orchestratorContract: {
    name: string;
    accountId: string;
    region: string;
    schemaVersion?: string;
  };
  executorContract: {
    name: string;
    accountId: string;
    region: string;
    schemaVersion?: string;
  };
  databaseName: string;
  migrationFilesPath: string;
}
