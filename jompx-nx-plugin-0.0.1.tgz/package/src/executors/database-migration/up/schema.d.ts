export interface UpExecutorSchema {
  targetId: string;
  configPath?: string;
  profile: string;
}
