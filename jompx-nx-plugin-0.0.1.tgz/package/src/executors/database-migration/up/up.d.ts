import { PromiseExecutor } from '@nx/devkit';
import { UpExecutorSchema } from './schema';
declare const runExecutor: PromiseExecutor<UpExecutorSchema>;
export default runExecutor;
