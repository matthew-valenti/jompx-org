import { PromiseExecutor } from '@nx/devkit';
import { CreateExecutorSchema } from './schema';
declare const runExecutor: PromiseExecutor<CreateExecutorSchema>;
export default runExecutor;
