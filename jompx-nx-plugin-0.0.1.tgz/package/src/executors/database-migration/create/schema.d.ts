export interface CreateExecutorSchema {
  description?: string;
  path?: string;
  extension?: string;
} // eslint-disable-line
