"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tslib_1 = require("tslib");
const promises_1 = require("node:fs/promises");
const path = require("path");
const devkit_1 = require("@nx/devkit");
function formatTimestamp(date = new Date()) {
    const year = date.getUTCFullYear();
    const month = String(date.getUTCMonth() + 1).padStart(2, '0');
    const day = String(date.getUTCDate()).padStart(2, '0');
    const hours = String(date.getUTCHours()).padStart(2, '0');
    const minutes = String(date.getUTCMinutes()).padStart(2, '0');
    const seconds = String(date.getUTCSeconds()).padStart(2, '0');
    return `${year}${month}${day}T${hours}${minutes}${seconds}`;
}
const runExecutor = (options, context) => tslib_1.__awaiter(void 0, void 0, void 0, function* () {
    var _a, _b, _c, _d, _e;
    const projectRoot = path.resolve(context.root, context.projectsConfigurations.projects[context.projectName].root);
    const targetPath = path.join(projectRoot, 'src', 'lib', (0, devkit_1.normalizePath)((_a = options.path) !== null && _a !== void 0 ? _a : '.'));
    const extension = ((_b = options.extension) !== null && _b !== void 0 ? _b : 'sql').replace(/^\./, '').toLowerCase();
    const baseName = `${formatTimestamp()}_${(0, devkit_1.names)((_c = options.description) !== null && _c !== void 0 ? _c : 'description').fileName}`;
    // Keep path simple and project-relative.
    if (path.isAbsolute((_d = options.path) !== null && _d !== void 0 ? _d : '') || (0, devkit_1.normalizePath)((_e = options.path) !== null && _e !== void 0 ? _e : '.').includes('..')) {
        throw new Error(`Invalid path "${options.path}". Use a simple project-relative path.`);
    }
    // Use Umzug's two file up/down convention for sql files.
    if (extension === 'sql') {
        const upFilePath = path.join(targetPath, `${baseName}.up.sql`);
        const downFilePath = path.join(targetPath, `${baseName}.down.sql`);
        yield (0, promises_1.mkdir)(targetPath, { recursive: true });
        yield (0, promises_1.writeFile)(upFilePath, '-- TODO: Write migration.\n', { encoding: 'utf8', flag: 'wx' });
        yield (0, promises_1.writeFile)(downFilePath, '-- TODO: Write rollback.\n', { encoding: 'utf8', flag: 'wx' });
        devkit_1.logger.info(`Created ${path.relative(context.root, upFilePath)}`);
        devkit_1.logger.info(`Created ${path.relative(context.root, downFilePath)}`);
    }
    else {
        // Create a single file for other extensions (e.g. .ts).
        const filePath = path.join(targetPath, `${baseName}.${extension}`);
        // Standard Umzug Typescript template.
        const tsMigrationFile = `import type { Migration } from 'umzug';

export const up: Migration = async ({ context }) => {
  // apply change
};

export const down: Migration = async ({ context }) => {
  // revert change
};
`;
        const content = extension === 'ts' ? tsMigrationFile : '';
        yield (0, promises_1.mkdir)(targetPath, { recursive: true });
        yield (0, promises_1.writeFile)(filePath, content, { encoding: 'utf8', flag: 'wx' });
        devkit_1.logger.info(`Created ${path.relative(context.root, filePath)}`);
    }
    return {
        success: true,
    };
});
exports.default = runExecutor;
//# sourceMappingURL=create.js.map