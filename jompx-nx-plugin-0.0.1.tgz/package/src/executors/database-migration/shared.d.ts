import { ExecutorContext } from '@nx/devkit';
import { runDatabaseMigration } from '@jompx/client-database-migration';
type DatabaseMigrationRunExecutorSchema = {
    targetId: string;
    configPath?: string;
    profile: string;
    downSteps?: number;
};
type RunDatabaseMigrationProps = Parameters<typeof runDatabaseMigration>[0];
export type RunDatabaseMigrationWithRegistryProps = RunDatabaseMigrationProps & {
    registry: {
        baseUrl: string;
        region: string;
    };
};
export declare function getRunDatabaseMigrationProps(options: DatabaseMigrationRunExecutorSchema, context: ExecutorContext, direction: 'up' | 'down'): Promise<RunDatabaseMigrationWithRegistryProps>;
export {};
