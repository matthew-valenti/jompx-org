import { PromiseExecutor } from '@nx/devkit';
import { OrgFormationExecutor } from './schema';
declare const runExecutor: PromiseExecutor<OrgFormationExecutor>;
export default runExecutor;
