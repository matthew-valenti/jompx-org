export interface CreateRoute53SubdomainsExecutorSchema {
  file: string;
  stackName?: string;
  domainName: string;
  ttl?: number;
  profile: string;
  dryRun?: boolean;
}
