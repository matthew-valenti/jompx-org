import { PromiseExecutor } from '@nx/devkit';
import { CreateRoute53SubdomainsExecutorSchema } from './schema';
declare const runExecutor: PromiseExecutor<CreateRoute53SubdomainsExecutorSchema>;
export default runExecutor;
