import { PromiseExecutor } from '@nx/devkit';
import { CreateChangeSetExecutorSchema } from './schema';
declare const runExecutor: PromiseExecutor<CreateChangeSetExecutorSchema>;
export default runExecutor;
