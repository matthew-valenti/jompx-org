export interface UpdateExecutorSchema {
  file: string;
  profile: string;
}
