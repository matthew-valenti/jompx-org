import { PromiseExecutor } from '@nx/devkit';
import { UpdateExecutorSchema } from './schema';
declare const runExecutor: PromiseExecutor<UpdateExecutorSchema>;
export default runExecutor;
