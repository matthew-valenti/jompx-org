import { PromiseExecutor } from '@nx/devkit';
import { CreateAcmCertificatesExecutorSchema } from './schema';
declare const runExecutor: PromiseExecutor<CreateAcmCertificatesExecutorSchema>;
export default runExecutor;
