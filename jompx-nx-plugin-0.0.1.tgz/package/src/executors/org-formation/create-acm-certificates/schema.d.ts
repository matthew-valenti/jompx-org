export interface CreateAcmCertificatesExecutorSchema {
  file: string;
  stackName?: string;
  domainName: string;
  profile: string;
  dryRun?: boolean;
}
