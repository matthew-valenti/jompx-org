export interface UpdateStacksExecutorSchema {
  file: string;
  stackName: string;
  domainName: string;
  profile: string;
}
