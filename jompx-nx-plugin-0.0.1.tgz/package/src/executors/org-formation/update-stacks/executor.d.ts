import { PromiseExecutor } from '@nx/devkit';
import { UpdateStacksExecutorSchema } from './schema';
declare const runExecutor: PromiseExecutor<UpdateStacksExecutorSchema>;
export default runExecutor;
