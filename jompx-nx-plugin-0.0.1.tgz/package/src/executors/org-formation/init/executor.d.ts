import { PromiseExecutor } from '@nx/devkit';
import { OrgFormationExecutorSchema } from './schema';
declare const runExecutor: PromiseExecutor<OrgFormationExecutorSchema>;
export default runExecutor;
