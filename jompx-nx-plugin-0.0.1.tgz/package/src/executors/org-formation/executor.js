"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tslib_1 = require("tslib");
const runExecutor = (options) => tslib_1.__awaiter(void 0, void 0, void 0, function* () {
    console.log(`
    Org Formation Nx Plugin

    Available commands:
    nx run org-formation:init [--file=organization.yml]
  `);
    return {
        success: true,
    };
});
exports.default = runExecutor;
//# sourceMappingURL=executor.js.map