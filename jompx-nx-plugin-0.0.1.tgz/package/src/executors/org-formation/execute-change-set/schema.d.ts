export interface ExecuteChangeSetExecutorSchema {
  changeSetName: string;
  profile: string;
}
