import { PromiseExecutor } from '@nx/devkit';
import { ExecuteChangeSetExecutorSchema } from './schema';
declare const runExecutor: PromiseExecutor<ExecuteChangeSetExecutorSchema>;
export default runExecutor;
