import { PromiseExecutor } from '@nx/devkit';
import { CatalogExecutorSchema } from './schema';
declare const runExecutor: PromiseExecutor<CatalogExecutorSchema>;
export default runExecutor;
