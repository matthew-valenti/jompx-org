export interface CatalogExecutorSchema {} // eslint-disable-line
