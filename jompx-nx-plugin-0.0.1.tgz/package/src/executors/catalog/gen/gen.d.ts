import * as jompx from '@jompx/constructs';
import { PromiseExecutor } from '@nx/devkit';
import { GenExecutorSchema } from './schema';
/**
 * Dynamically compiles a TypeScript file (and its imports) to JS,
 * loads the module, and returns it. Cleans up the emitted output.
 */
export declare function compileAndLoad(tsFile: string): Promise<any>;
declare const runExecutor: PromiseExecutor<GenExecutorSchema>;
export default runExecutor;
export declare function validateEntityCommonAttributes(catalog: jompx.Catalog, validationMessages: string[]): void;
/**
 * Ensure named complex attributes on entity APIs share exposure with their parent entity.
 * Inline definitions (both new and legacy) are ignored.
 */
export declare function validateEntityComplexAttributes(catalog: jompx.Catalog, validationMessages: string[]): void;
export declare function validateEntityEnumAttributes(catalog: jompx.Catalog, validationMessages: string[]): void;
export declare function validateEntityRelationshipRelatedEntity(catalog: jompx.Catalog, validationMessages: string[]): void;
/**
 * Validates that every API name referenced in any "includeInApis" (or "defaultIncludeInApis")
 * in the catalog exists as a key in the root catalog.apis.
 *
 * @param catalog - The complete catalog object.
 * @param validationMessages - An array to which any validation errors will be appended.
 */
export declare function validateApis(catalog: jompx.Catalog, validationMessages: string[]): void;
export declare function validateEntityNameWithSuffixInApiIsUnique(catalog: jompx.Catalog, validationMessages: string[]): void;
