export interface GenExecutorSchema {
  catalogFile: string;
  outputCatalogFile: string;
}
