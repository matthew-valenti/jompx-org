"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.compileAndLoad = compileAndLoad;
exports.validateEntityCommonAttributes = validateEntityCommonAttributes;
exports.validateEntityComplexAttributes = validateEntityComplexAttributes;
exports.validateEntityEnumAttributes = validateEntityEnumAttributes;
exports.validateEntityRelationshipRelatedEntity = validateEntityRelationshipRelatedEntity;
exports.validateApis = validateApis;
exports.validateEntityNameWithSuffixInApiIsUnique = validateEntityNameWithSuffixInApiIsUnique;
const tslib_1 = require("tslib");
const changeCase = require("change-case");
const promises_1 = require("node:fs/promises");
const path = require("path");
const os = require("os");
const ts = require("typescript");
/**
 * Dynamically compiles a TypeScript file (and its imports) to JS,
 * loads the module, and returns it. Cleans up the emitted output.
 */
function compileAndLoad(tsFile) {
    return tslib_1.__awaiter(this, void 0, void 0, function* () {
        // Create an isolated temp directory under the OS temp folder.
        // Keeps compiled output transient and avoids polluting Nx `dist/`.
        const tmpDir = yield (0, promises_1.mkdtemp)(path.join(os.tmpdir(), 'nx-tmp-'));
        try {
            // Create a TypeScript Program for the entry file.
            // This sets up the full dependency graph and compiler context.
            const program = ts.createProgram([tsFile], {
                outDir: tmpDir, // emit all JS files here
                module: ts.ModuleKind.CommonJS, // ensures Node can `require()` them
                target: ts.ScriptTarget.ES2022, // modern output
                esModuleInterop: true, // allows mixed import/export styles
                skipLibCheck: true, // speeds up compile (no lib type-check)
            });
            // Actually perform the compilation and write JS files to temp dir.
            program.emit();
            // Compute path to the emitted main JS file.
            // TypeScript mirrors structure under outDir, so basename works here.
            const emittedJs = path.join(tmpDir, path.basename(tsFile).replace(/\.ts$/, '.js'));
            // Clear any cached version, then load the freshly emitted module.
            delete require.cache[require.resolve(emittedJs)];
            const module = require(emittedJs);
            // Return the loaded module to the caller.
            return module;
        }
        finally {
            // Clean up the temporary output directory to keep workspace clean,
            // even if compilation or loading fails.
            yield (0, promises_1.rm)(tmpDir, { recursive: true, force: true });
        }
    });
}
const runExecutor = (options, context) => tslib_1.__awaiter(void 0, void 0, void 0, function* () {
    const projectRoot = path.join(context.root, context.projectsConfigurations.projects[context.projectName].root);
    const catalogFile = path.resolve(projectRoot, options.catalogFile);
    const outputCatalogFileName = path.resolve(projectRoot, options.outputCatalogFile);
    const module = yield compileAndLoad(catalogFile);
    const catalog = module.catalog;
    if (!validateCatalogExport(catalog)) {
        throw new Error(`Invalid catalog export. Expected a named export "catalog" (for example: export const catalog = { ... }).`);
    }
    const isCatalogValid = validateCatalog(catalog);
    if (isCatalogValid) {
        yield outputCatalog(catalog, outputCatalogFileName);
    }
    return {
        success: true,
    };
});
exports.default = runExecutor;
function outputCatalog(catalog, outputCatalogFileName) {
    return tslib_1.__awaiter(this, void 0, void 0, function* () {
        yield (0, promises_1.writeFile)(outputCatalogFileName, JSON.stringify(catalog, null, 2));
    });
}
function validateCatalog(catalog) {
    const validationMessages = [];
    validateApis(catalog, validationMessages);
    validateEntityCommonAttributes(catalog, validationMessages);
    validateEntityComplexAttributes(catalog, validationMessages);
    validateEntityEnumAttributes(catalog, validationMessages);
    validateEntityRelationshipRelatedEntityDatasource(catalog, validationMessages);
    validateEntityRelationshipRelatedEntity(catalog, validationMessages);
    validateAttributeAppSyncReturnType(catalog, validationMessages);
    validateAttributeIncludeInApis(catalog, validationMessages);
    validateEntityNameWithSuffixInApiIsUnique(catalog, validationMessages);
    validationMessages.forEach((message, index) => {
        console.warn(`${index + 1}. ${message}`);
    });
    return validationMessages.length === 0;
}
function validateCatalogExport(catalog) {
    return !!catalog && typeof catalog === 'object';
}
function validateEntityCommonAttributes(catalog, validationMessages) {
    Object.entries(catalog.datasources).forEach(([datasourceName, datasource]) => {
        Object.entries(datasource.entities).forEach(([entityName, entityProps]) => {
            if (!entityProps.commonAttributes) {
                return;
            }
            entityProps.commonAttributes.forEach((commonAttributeName) => {
                var _a, _b, _c, _d, _e;
                // Check that the common attribute exists.
                const commonAttr = (_a = catalog.commonAttributes) === null || _a === void 0 ? void 0 : _a[commonAttributeName];
                if (!commonAttr) {
                    validationMessages.push(`Entity [${datasourceName} > ${entityName}] references missing common attribute "${commonAttributeName}".`);
                    return;
                }
                // Compute the entity's API exposure from its defaultIncludeInApis and its attributes.
                const entityApis = new Set();
                (_c = (_b = entityProps.api) === null || _b === void 0 ? void 0 : _b.defaultIncludeInApis) === null || _c === void 0 ? void 0 : _c.forEach((api) => entityApis.add(api));
                if (entityProps.attributes) {
                    Object.values(entityProps.attributes).forEach((attribute) => {
                        var _a, _b;
                        (_b = (_a = attribute.api) === null || _a === void 0 ? void 0 : _a.includeInApis) === null || _b === void 0 ? void 0 : _b.forEach((api) => entityApis.add(api));
                    });
                }
                // If the entity isn't exposed on any API, skip API overlap validation.
                if (entityApis.size === 0) {
                    return;
                }
                // Compute the common attribute's API exposure.
                const commonAttrApis = new Set();
                (_e = (_d = commonAttr.api) === null || _d === void 0 ? void 0 : _d.includeInApis) === null || _e === void 0 ? void 0 : _e.forEach((api) => commonAttrApis.add(api));
                // Validate: if the common attribute doesn't declare any APIs, report an error.
                if (commonAttrApis.size === 0) {
                    validationMessages.push(`Entity [${datasourceName} > ${entityName}] references common attribute "${commonAttributeName}" which does not specify any API exposure. Entity APIs: [${[
                        ...entityApis,
                    ].join(', ')}].`);
                }
                else {
                    // Ensure there is at least one API in common between the entity and the common attribute.
                    const commonApis = [...entityApis].filter((api) => commonAttrApis.has(api));
                    if (commonApis.length === 0) {
                        validationMessages.push(`Entity [${datasourceName} > ${entityName}] references common attribute "${commonAttributeName}" which does not share any common API exposure. Entity APIs: [${[
                            ...entityApis,
                        ].join(', ')}], common attribute APIs: [${[...commonAttrApis].join(', ')}].`);
                    }
                }
            });
        });
    });
}
/**
 * Ensure named complex attributes on entity APIs share exposure with their parent entity.
 * Inline definitions (both new and legacy) are ignored.
 */
function validateEntityComplexAttributes(catalog, validationMessages) {
    var _a, _b, _c, _d, _e, _f;
    for (const [dsName, ds] of Object.entries(catalog.datasources)) {
        for (const [entName, ent] of Object.entries(ds.entities)) {
            for (const [attrName, attr] of Object.entries(ent.attributes || {})) {
                const api = attr.api;
                if (!api)
                    continue;
                const rt = api.returnType;
                if (!rt || typeof rt !== 'object' || rt.type !== 'complexAttribute') {
                    continue; // not a complexAttribute return type
                }
                // Skip inline definitions (new style: rt.definition, legacy: attr.complexAttribute)
                if ('definition' in rt || attr.complexAttribute) {
                    continue;
                }
                // Named complex attribute lookup
                const name = rt.name;
                const complex = (_a = catalog.complexAttributes) === null || _a === void 0 ? void 0 : _a[name];
                if (!complex) {
                    continue; // undefined complex attribute handled elsewhere
                }
                // Collect APIs this entity/attribute appears in
                const entityApis = new Set([...((_c = (_b = ent.api) === null || _b === void 0 ? void 0 : _b.defaultIncludeInApis) !== null && _c !== void 0 ? _c : []), ...((_d = api.includeInApis) !== null && _d !== void 0 ? _d : [])]);
                if (entityApis.size === 0) {
                    continue; // entity not exposed in any API
                }
                // Collect APIs the complex attribute exposes
                const complexApis = new Set((_f = (_e = complex.api) === null || _e === void 0 ? void 0 : _e.defaultIncludeInApis) !== null && _f !== void 0 ? _f : []);
                // Error: no APIs declared on the complex attribute
                if (complexApis.size === 0) {
                    validationMessages.push(`Entity [${dsName} > ${entName}] attribute "${attrName}" ` +
                        `references complex attribute "${name}" with no API exposure. ` +
                        `Entity APIs: [${[...entityApis].join(', ')}].`);
                    continue;
                }
                // Error: no shared APIs between entity and complex attribute
                const shared = [...entityApis].filter((a) => complexApis.has(a));
                if (shared.length === 0) {
                    validationMessages.push(`Entity [${dsName} > ${entName}] attribute "${attrName}" ` +
                        `references complex attribute "${name}" with no common APIs. ` +
                        `Entity APIs: [${[...entityApis].join(', ')}], ` +
                        `Complex APIs: [${[...complexApis].join(', ')}].`);
                }
            }
        }
    }
}
function validateEntityEnumAttributes(catalog, validationMessages) {
    var _a, _b, _c, _d, _e, _f;
    for (const [datasourceName, datasource] of Object.entries(catalog.datasources)) {
        for (const [entityName, entityProps] of Object.entries(datasource.entities)) {
            for (const [attributeName, attributeProps] of Object.entries(entityProps.attributes || {})) {
                // Proceed only if the attribute has an API definition.
                if (!attributeProps.api)
                    continue;
                const returnType = attributeProps.api.returnType;
                // Only proceed if returnType is an object and is an enum.
                if (!(returnType && typeof returnType === 'object' && returnType.type === 'enum'))
                    continue;
                // Determine whether this enum is a named reference or an inline definition.
                let enumProps;
                let enumLabel;
                if ('name' in returnType) {
                    enumLabel = returnType.name;
                    enumProps = (_a = catalog.enums) === null || _a === void 0 ? void 0 : _a[returnType.name];
                }
                if ('definition' in returnType) {
                    enumLabel = '(inline)';
                    // First cast to unknown then to CatalogEnumProps to override the type error.
                    enumProps = returnType.definition;
                }
                else {
                    // Should not occur.
                    continue;
                }
                if (!enumProps)
                    continue;
                // Compute the attribute's API exposure.
                const attributeApis = new Set();
                (_c = (_b = entityProps.api) === null || _b === void 0 ? void 0 : _b.defaultIncludeInApis) === null || _c === void 0 ? void 0 : _c.forEach((api) => attributeApis.add(api));
                (_d = attributeProps.api.includeInApis) === null || _d === void 0 ? void 0 : _d.forEach((api) => attributeApis.add(api));
                // Compute the enum's API exposure.
                const enumApis = new Set();
                (_f = (_e = enumProps.api) === null || _e === void 0 ? void 0 : _e.includeInApis) === null || _f === void 0 ? void 0 : _f.forEach((api) => enumApis.add(api));
                // If the attribute is exposed on some APIs...
                if (attributeApis.size > 0) {
                    // ...but the enum does not specify any API exposure, report an error.
                    if (enumApis.size === 0) {
                        validationMessages.push(`Entity [${datasourceName} > ${entityName}] attribute "${attributeName}" references enum "${enumLabel}" which does not specify any API exposure. Attribute APIs: [${[
                            ...attributeApis,
                        ].join(', ')}].`);
                    }
                    else {
                        // Otherwise, validate that there is at least one common API.
                        const commonApis = [...attributeApis].filter((api) => enumApis.has(api));
                        if (commonApis.length === 0) {
                            validationMessages.push(`Entity [${datasourceName} > ${entityName}] attribute "${attributeName}" references enum "${enumLabel}" which does not share any common API exposure. Attribute APIs: [${[
                                ...attributeApis,
                            ].join(', ')}], enum APIs: [${[...enumApis].join(', ')}].`);
                        }
                    }
                }
            }
        }
    }
}
function validateEntityRelationshipRelatedEntityDatasource(catalog, validationMessages) {
    Object.entries(catalog.datasources).forEach(([datasourceName, datasource]) => {
        Object.entries(datasource.entities).forEach(([entityName, entityProps]) => {
            if (entityProps.relationships) {
                Object.entries(entityProps.relationships).forEach(([relationshipName, relationship]) => {
                    const relatedDatasource = relationship.relatedEntityDatasource || datasourceName;
                    // Check if the related datasource exists in the catalog
                    const datasourceExists = !!catalog.datasources[relatedDatasource];
                    if (!datasourceExists) {
                        validationMessages.push(`Entity [${datasourceName} > ${entityName}] relationship "${relationshipName}" references missing datasource [${relatedDatasource}].`);
                    }
                });
            }
        });
    });
}
function validateEntityRelationshipRelatedEntity(catalog, validationMessages) {
    Object.entries(catalog.datasources).forEach(([datasourceName, datasource]) => {
        Object.entries(datasource.entities).forEach(([entityName, entityProps]) => {
            if (!entityProps.relationships)
                return;
            Object.entries(entityProps.relationships).forEach(([relationshipName, relationship]) => {
                var _a, _b, _c, _d, _e, _f;
                const relatedEntityName = relationship.relatedEntity;
                // Use the same datasource if none is specified.
                const relatedDatasourceName = relationship.relatedEntityDatasource || datasourceName;
                const relatedEntity = (_b = (_a = catalog.datasources[relatedDatasourceName]) === null || _a === void 0 ? void 0 : _a.entities) === null || _b === void 0 ? void 0 : _b[relatedEntityName];
                // Verify that the related entity exists.
                if (!relatedEntity) {
                    validationMessages.push(`Entity [${datasourceName} > ${entityName}] relationship "${relationshipName}" references missing entity [${relatedDatasourceName} > ${relatedEntityName}].`);
                    return;
                }
                // Compute API exposure for the source entity.
                const sourceEntityApis = new Set();
                (_d = (_c = entityProps.api) === null || _c === void 0 ? void 0 : _c.defaultIncludeInApis) === null || _d === void 0 ? void 0 : _d.forEach((api) => sourceEntityApis.add(api));
                if (entityProps.attributes) {
                    Object.values(entityProps.attributes).forEach((attribute) => { var _a, _b; return (_b = (_a = attribute.api) === null || _a === void 0 ? void 0 : _a.includeInApis) === null || _b === void 0 ? void 0 : _b.forEach((api) => sourceEntityApis.add(api)); });
                }
                // Compute API exposure for the related entity.
                const relatedEntityApis = new Set();
                (_f = (_e = relatedEntity.api) === null || _e === void 0 ? void 0 : _e.defaultIncludeInApis) === null || _f === void 0 ? void 0 : _f.forEach((api) => relatedEntityApis.add(api));
                if (relatedEntity.attributes) {
                    Object.values(relatedEntity.attributes).forEach((attribute) => { var _a, _b; return (_b = (_a = attribute.api) === null || _a === void 0 ? void 0 : _a.includeInApis) === null || _b === void 0 ? void 0 : _b.forEach((api) => relatedEntityApis.add(api)); });
                }
                // Report errors if either side is missing API exposure.
                if (sourceEntityApis.size === 0) {
                    validationMessages.push(`Entity [${datasourceName} > ${entityName}] relationship "${relationshipName}" has no API exposure on the source entity. Please specify defaultIncludeInApis or attribute includeInApis.`);
                }
                if (relatedEntityApis.size === 0) {
                    validationMessages.push(`Entity [${datasourceName} > ${entityName}] relationship "${relationshipName}" references entity [${relatedDatasourceName} > ${relatedEntityName}] which has no API exposure. Please specify defaultIncludeInApis or attribute includeInApis for the related entity.`);
                }
                // Only perform common API overlap check if both sides have some API exposure.
                if (sourceEntityApis.size > 0 && relatedEntityApis.size > 0) {
                    const commonApis = [...sourceEntityApis].filter((api) => relatedEntityApis.has(api));
                    if (commonApis.length === 0) {
                        validationMessages.push(`Entity [${datasourceName} > ${entityName}] relationship "${relationshipName}" references entity [${relatedDatasourceName} > ${relatedEntityName}] which is not exposed in any common API. Source entity APIs: [${[
                            ...sourceEntityApis,
                        ].join(', ')}], related entity APIs: [${[...relatedEntityApis].join(', ')}].`);
                    }
                }
            });
        });
    });
}
function validateAttributeAppSyncReturnType(catalog, validationMessages) {
    Object.entries(catalog.datasources).forEach(([datasourceName, datasource]) => {
        Object.entries(datasource.entities).forEach(([entityName, entityProps]) => {
            Object.entries(entityProps.attributes).forEach(([attributeName, attributeProps]) => {
                var _a;
                const returnType = (_a = attributeProps.api) === null || _a === void 0 ? void 0 : _a.returnType;
                if (!returnType)
                    return; // Skip if no returnType is defined
                if (typeof returnType === 'string') {
                    const standardTypes = [
                        'id',
                        'string',
                        'int',
                        'float',
                        'boolean',
                        'date',
                        'time',
                        'datetime',
                        'timestamp',
                        'email',
                        'json',
                        'url',
                        'phone',
                        'ipaddress',
                    ];
                    if (!standardTypes.includes(returnType)) {
                        validationMessages.push(`Entity [${datasourceName} > ${entityName}] attribute "${attributeName}" has appSync returnType "${returnType}" which is not a standard type.`);
                    }
                }
                else if (typeof returnType === 'object' && returnType !== null) {
                    switch (returnType.type) {
                        case 'enum': {
                            // If a named enum is referenced, validate its existence.
                            if ('name' in returnType) {
                                if (!catalog.enums || !catalog.enums[returnType.name]) {
                                    validationMessages.push(`Entity [${datasourceName} > ${entityName}] attribute "${attributeName}" has appSync returnType enum "${returnType.name}" which is not a defined enum.`);
                                }
                            }
                            break;
                        }
                        case 'complexAttribute': {
                            // Inline complex attribute definitions are valid even when a name is also provided.
                            if ('definition' in returnType) {
                                break;
                            }
                            // If a named complex attribute is referenced, validate its existence.
                            if ('name' in returnType) {
                                if (!catalog.complexAttributes || !catalog.complexAttributes[returnType.name]) {
                                    validationMessages.push(`Entity [${datasourceName} > ${entityName}] attribute "${attributeName}" has appSync returnType complexAttribute "${returnType.name}" which is not a defined complex attribute.`);
                                }
                            }
                            break;
                        }
                        default:
                            validationMessages.push(`Entity [${datasourceName} > ${entityName}] attribute "${attributeName}" has an unknown appSync returnType type "${returnType.type}".`);
                    }
                }
            });
        });
    });
}
/**
 * Validates that every API name referenced in any "includeInApis" (or "defaultIncludeInApis")
 * in the catalog exists as a key in the root catalog.apis.
 *
 * @param catalog - The complete catalog object.
 * @param validationMessages - An array to which any validation errors will be appended.
 */
function validateApis(catalog, validationMessages) {
    // Extract valid API names from the root "apis" property.
    const validApiNames = Object.keys(catalog.apis || {});
    // --- Validate APIs in Datasource Entities ---
    Object.entries(catalog.datasources).forEach(([datasourceName, datasourceProps]) => {
        Object.entries(datasourceProps.entities).forEach(([entityName, entityProps]) => {
            var _a;
            // Validate entity-level defaultIncludeInApis (if provided).
            if ((_a = entityProps.api) === null || _a === void 0 ? void 0 : _a.defaultIncludeInApis) {
                const invalidApis = entityProps.api.defaultIncludeInApis.filter((apiName) => !validApiNames.includes(apiName));
                if (invalidApis.length > 0) {
                    validationMessages.push(`Entity [${datasourceName} > ${entityName}] api.defaultIncludeInApis contains invalid APIs: ${invalidApis.join(', ')}. Valid APIs: ${validApiNames.join(', ')}.`);
                }
            }
            // Validate each attribute's includeInApis.
            if (entityProps.attributes) {
                Object.entries(entityProps.attributes).forEach(([attributeName, attributeProps]) => {
                    var _a;
                    if ((_a = attributeProps.api) === null || _a === void 0 ? void 0 : _a.includeInApis) {
                        const invalidApis = attributeProps.api.includeInApis.filter((apiName) => !validApiNames.includes(apiName));
                        if (invalidApis.length > 0) {
                            validationMessages.push(`Entity [${datasourceName} > ${entityName}] attribute "${attributeName}" api.includeInApis contains invalid APIs: ${invalidApis.join(', ')}. Valid APIs: ${validApiNames.join(', ')}.`);
                        }
                    }
                });
            }
            // Validate each relationship's includeInApis.
            if (entityProps.relationships) {
                Object.entries(entityProps.relationships).forEach(([relationshipName, relationshipProps]) => {
                    var _a;
                    if ((_a = relationshipProps.api) === null || _a === void 0 ? void 0 : _a.includeInApis) {
                        const invalidApis = relationshipProps.api.includeInApis.filter((apiName) => !validApiNames.includes(apiName));
                        if (invalidApis.length > 0) {
                            validationMessages.push(`Entity [${datasourceName} > ${entityName}] relationship "${relationshipName}" api.includeInApis contains invalid APIs: ${invalidApis.join(', ')}. Valid APIs: ${validApiNames.join(', ')}.`);
                        }
                    }
                });
            }
        });
    });
    // --- Validate APIs in Common Attributes ---
    if (catalog.commonAttributes) {
        Object.entries(catalog.commonAttributes).forEach(([commonAttrName, commonAttrProps]) => {
            var _a;
            if ((_a = commonAttrProps.api) === null || _a === void 0 ? void 0 : _a.includeInApis) {
                const invalidApis = commonAttrProps.api.includeInApis.filter((apiName) => !validApiNames.includes(apiName));
                if (invalidApis.length > 0) {
                    validationMessages.push(`Common Attribute "${commonAttrName}" api.includeInApis contains invalid APIs: ${invalidApis.join(', ')}. Valid APIs: ${validApiNames.join(', ')}.`);
                }
            }
        });
    }
    // --- Validate APIs in Enums ---
    if (catalog.enums) {
        Object.entries(catalog.enums).forEach(([enumName, enumProps]) => {
            var _a;
            if ((_a = enumProps.api) === null || _a === void 0 ? void 0 : _a.includeInApis) {
                const invalidApis = enumProps.api.includeInApis.filter((apiName) => !validApiNames.includes(apiName));
                if (invalidApis.length > 0) {
                    validationMessages.push(`Enum "${enumName}" api.includeInApis contains invalid APIs: ${invalidApis.join(', ')}. Valid APIs: ${validApiNames.join(', ')}.`);
                }
            }
        });
    }
}
function validateAttributeIncludeInApis(catalog, validationMessages) {
    // Extract valid API names from the catalog's top-level "apis" property
    const validApiNames = Object.keys(catalog.apis);
    // Iterate over each datasourceProps in the catalog
    Object.entries(catalog.datasources).forEach(([datasourceName, datasourceProps]) => {
        // Iterate over each entity within the datasourceProps
        Object.entries(datasourceProps.entities).forEach(([entityName, entityProps]) => {
            // Check if the entity has attributes defined
            if (entityProps.attributes) {
                // Iterate over each attribute
                Object.entries(entityProps.attributes).forEach(([attributeName, attributeProps]) => {
                    var _a, _b;
                    // Check if the attributeProps has the includeInApis property
                    if ((_a = attributeProps === null || attributeProps === void 0 ? void 0 : attributeProps.api) === null || _a === void 0 ? void 0 : _a.includeInApis) {
                        // Validate all API names in includeInApis
                        const invalidApis = (_b = attributeProps === null || attributeProps === void 0 ? void 0 : attributeProps.api) === null || _b === void 0 ? void 0 : _b.includeInApis.filter((apiName) => !validApiNames.includes(apiName));
                        if (invalidApis.length > 0) {
                            validationMessages.push(`Entity [${datasourceName} > ${entityName}] attribute "${attributeName}" contains invalid APIs in includeInApis: ${invalidApis.join(', ')}. Valid APIs are: ${validApiNames.join(', ')}.`);
                        }
                    }
                });
            }
        });
    });
}
function validateEntityNameWithSuffixInApiIsUnique(catalog, validationMessages) {
    var _a;
    // Create a map to track unique endpoint names within each API.
    const apiEntityNamesMap = {};
    // Iterate over each datasource in the catalog.
    Object.entries((_a = catalog.datasources) !== null && _a !== void 0 ? _a : {}).forEach(([datasourceName, datasourceProps]) => {
        var _a;
        // Iterate over each entity within the datasource.
        Object.entries((_a = datasourceProps.entities) !== null && _a !== void 0 ? _a : {}).forEach(([entityName, entityProps]) => {
            var _a, _b;
            // Proceed only if the entity has an API definition.
            if (entityProps.api) {
                const entityNameSuffix = (_a = entityProps.api.entityNamePrefix) !== null && _a !== void 0 ? _a : '';
                const includeInApis = (_b = entityProps.api.defaultIncludeInApis) !== null && _b !== void 0 ? _b : [];
                // Iterate over the APIs where this entity should be included.
                includeInApis.forEach((apiName) => {
                    var _a;
                    // Initialize the set for this API if it doesn't exist.
                    (_a = apiEntityNamesMap[apiName]) !== null && _a !== void 0 ? _a : (apiEntityNamesMap[apiName] = new Set());
                    // Create the concatenated unique entity name.
                    const uniqueEntityName = `${entityNameSuffix}${changeCase.pascalCase(entityName)}`;
                    // Check for duplicates within the API.
                    if (apiEntityNamesMap[apiName].has(uniqueEntityName)) {
                        validationMessages.push(`Entity [${datasourceName} > ${entityName}] with name "${uniqueEntityName}" is duplicated in API "${apiName}". Ensure entity names are unique within each API.`);
                    }
                    else {
                        apiEntityNamesMap[apiName].add(uniqueEntityName);
                    }
                });
            }
        });
    });
}
//# sourceMappingURL=gen.js.map