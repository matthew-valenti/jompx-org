export interface DiffExecutorSchema {
  stacks: string[];
  profile: string;
  fail?: boolean;
  context?: string[];
} // eslint-disable-line
