import { PromiseExecutor } from '@nx/devkit';
import { DiffExecutorSchema } from './schema';
declare const runExecutor: PromiseExecutor<DiffExecutorSchema>;
export default runExecutor;
