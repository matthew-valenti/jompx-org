export interface SynthExecutorSchema {
  stacks: string[];
  profile: string;
  context?: string[];
}
