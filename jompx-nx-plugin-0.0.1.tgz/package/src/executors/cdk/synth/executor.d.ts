import { PromiseExecutor } from '@nx/devkit';
import { SynthExecutorSchema } from './schema';
declare const runExecutor: PromiseExecutor<SynthExecutorSchema>;
export default runExecutor;
