export interface ListExecutorSchema {
  stacks: string[];
  profile: string;
  context?: string[];
}
