import { PromiseExecutor } from '@nx/devkit';
import { ListExecutorSchema } from './schema';
declare const runExecutor: PromiseExecutor<ListExecutorSchema>;
export default runExecutor;
