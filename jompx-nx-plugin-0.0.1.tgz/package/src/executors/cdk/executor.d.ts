import { PromiseExecutor } from '@nx/devkit';
import { CdkExecutorSchema } from './schema';
declare const runExecutor: PromiseExecutor<CdkExecutorSchema>;
export default runExecutor;
