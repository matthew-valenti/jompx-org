export interface DeployExecutorSchema {
  stacks: string[];
  profile: string;
  context?: string[];
}
