import { PromiseExecutor } from '@nx/devkit';
import { DeployExecutorSchema } from './schema';
declare const runExecutor: PromiseExecutor<DeployExecutorSchema>;
export default runExecutor;
