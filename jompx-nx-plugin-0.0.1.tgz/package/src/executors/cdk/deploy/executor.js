"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tslib_1 = require("tslib");
const child_process_1 = require("child_process");
const runExecutor = (options, context) => tslib_1.__awaiter(void 0, void 0, void 0, function* () {
    var _a, _b;
    const projectRoot = context.projectsConfigurations.projects[context.projectName].root;
    (0, child_process_1.execFileSync)('npx', [
        'aws-cdk',
        'deploy',
        ...[].concat((_a = options.stacks) !== null && _a !== void 0 ? _a : []),
        '--require-approval',
        'never',
        '--profile',
        options.profile,
        ...((_b = options.context) !== null && _b !== void 0 ? _b : []).flatMap((c) => ['--context', c]),
    ], {
        stdio: 'inherit',
        cwd: projectRoot,
        shell: true,
    });
    return {
        success: true,
    };
});
exports.default = runExecutor;
//# sourceMappingURL=executor.js.map