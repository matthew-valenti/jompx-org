import { PromiseExecutor } from '@nx/devkit';
import { PublishContractsExecutorSchema } from './schema';
declare const runExecutor: PromiseExecutor<PublishContractsExecutorSchema>;
export default runExecutor;
