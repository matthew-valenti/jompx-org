"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tslib_1 = require("tslib");
const devkit_1 = require("@nx/devkit");
const child_process_1 = require("child_process");
const contracts_client_1 = require("@jompx/contracts-client");
const credential_providers_1 = require("@aws-sdk/credential-providers");
const runExecutor = (options, context) => tslib_1.__awaiter(void 0, void 0, void 0, function* () {
    var _a, _b, _c, _d, _e;
    const projectRoot = context.projectsConfigurations.projects[context.projectName].root;
    const describeStacksJson = (0, child_process_1.execFileSync)('aws', [
        'cloudformation',
        'describe-stacks',
        '--stack-name',
        options.stackName,
        '--region',
        options.region,
        ...(options.profile ? ['--profile', options.profile] : []),
    ], {
        encoding: 'utf8',
        cwd: projectRoot,
        shell: true,
    });
    const stack = (_a = JSON.parse(describeStacksJson).Stacks) === null || _a === void 0 ? void 0 : _a[0];
    const groups = {};
    for (const output of (_b = stack === null || stack === void 0 ? void 0 : stack.Outputs) !== null && _b !== void 0 ? _b : []) {
        if (!((_c = output.OutputKey) === null || _c === void 0 ? void 0 : _c.startsWith('ServiceContract'))) {
            continue;
        }
        let description;
        try {
            description = JSON.parse((_d = output.Description) !== null && _d !== void 0 ? _d : '{}');
        }
        catch (error) {
            throw new Error(`Invalid JSON in ServiceContract output description for ${output.OutputKey}`);
        }
        if (description.jompx !== 'ServiceContract') {
            continue;
        }
        const key = JSON.stringify([description.contractName, description.schemaVersion]);
        (_e = groups[key]) !== null && _e !== void 0 ? _e : (groups[key] = {
            contractName: description.contractName,
            schemaVersion: description.schemaVersion,
            value: {},
        });
        groups[key].value[description.fieldName] = output.OutputValue;
    }
    const contracts = new contracts_client_1.ContractsClient(Object.assign({ baseUrl: options.registryBaseUrl, region: options.registryRegion }, (options.profile ? { credentialsProvider: (0, credential_providers_1.fromIni)({ profile: options.profile }) } : {})));
    let publishedContractProperties = 0;
    const publishedContractPropertyNames = [];
    for (const group of Object.values(groups)) {
        const propertyNames = Object.keys(group.value);
        yield contracts.put({
            accountId: options.accountId,
            region: options.region,
            environmentName: options.environmentName,
            contractName: options.stackName,
            schemaVersion: group.schemaVersion,
            value: group.value,
        });
        publishedContractProperties += propertyNames.length;
        publishedContractPropertyNames.push(...propertyNames);
    }
    devkit_1.logger.info(`Published ${publishedContractProperties} service contract ${publishedContractProperties === 1 ? 'property' : 'properties'}${publishedContractPropertyNames.length ? `: ${publishedContractPropertyNames.join(', ')}` : ''}.`);
    return {
        success: true,
    };
});
exports.default = runExecutor;
//# sourceMappingURL=publish-contracts.js.map