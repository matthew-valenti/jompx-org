export interface PublishContractsExecutorSchema {
  accountId: string;
  region: string;
  environmentName: string;
  stackName: string;
  registryBaseUrl: string;
  registryRegion: string;
  profile?: string;
}
