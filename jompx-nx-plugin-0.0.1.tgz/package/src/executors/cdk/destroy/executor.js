"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tslib_1 = require("tslib");
const child_process_1 = require("child_process");
const runExecutor = (options, context) => tslib_1.__awaiter(void 0, void 0, void 0, function* () {
    var _a;
    const projectRoot = context.projectsConfigurations.projects[context.projectName].root;
    const doubleDash = process.argv.indexOf('--');
    const forwardedArguments = doubleDash >= 0 ? process.argv.slice(doubleDash + 1) : [];
    (0, child_process_1.execFileSync)('npx', ['aws-cdk', 'destroy', ...[].concat((_a = options.stacks) !== null && _a !== void 0 ? _a : []), '--profile', options.profile, ...forwardedArguments], {
        stdio: 'inherit',
        cwd: projectRoot,
        shell: true,
    });
    return {
        success: true,
    };
});
exports.default = runExecutor;
//# sourceMappingURL=executor.js.map