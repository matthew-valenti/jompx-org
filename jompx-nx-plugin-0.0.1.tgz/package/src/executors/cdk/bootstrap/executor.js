"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tslib_1 = require("tslib");
const devkit_1 = require("@nx/devkit");
const child_process_1 = require("child_process");
const runExecutor = (options, context) => tslib_1.__awaiter(void 0, void 0, void 0, function* () {
    var _a, _b;
    const projectRoot = context.projectsConfigurations.projects[context.projectName].root;
    const doubleDash = process.argv.indexOf('--');
    const forwardedArguments = doubleDash >= 0 ? process.argv.slice(doubleDash + 1) : [];
    /**
     * coerceId(value)
     * Ensures AWS account IDs are safely handled on Windows/Nx CLI.
     * Fixes the classic "leading zero stripped" bug where yargs coerces
     * numeric-like strings (e.g. 055694273351 → 55694273351).
     * Always returns a 12-digit zero-padded string.
     */
    const coerceId = (v) => {
        const digits = String(v !== null && v !== void 0 ? v : '')
            .trim()
            .split(',')[0] // safe even if someone passes comma by mistake
            .replace(/\D/g, '');
        if (!/^\d{1,12}$/.test(digits))
            throw new Error(`Invalid AWS account: ${v}`);
        return digits.padStart(12, '0');
    };
    /**
     * coerceTrust(value)
     * Normalizes the `trust` option which may arrive as number, string,
     * or array due to Nx schema/yargs inconsistencies.
     * Splits comma-separated values, trims, validates, and pads each to
     * a 12-digit AWS account string.
     */
    const coerceTrust = (v) => {
        if (Array.isArray(v))
            return v.map(coerceId);
        if (v == null || v === '')
            return [];
        return String(v)
            .split(',')
            .map((s) => s.trim())
            .filter(Boolean)
            .map(coerceId);
    };
    const accountId = coerceId(options.accountId);
    const trusts = coerceTrust(options.trust);
    const cloudformationExecutionPolicies = (_b = (_a = options === null || options === void 0 ? void 0 : options.cloudformationExecutionPolicies) === null || _a === void 0 ? void 0 : _a.toString().split(',')) !== null && _b !== void 0 ? _b : [];
    console.log({
        accountId,
        trusts,
        cloudformationExecutionPolicies,
    });
    (0, child_process_1.execFileSync)('npx', [
        'aws-cdk',
        'bootstrap',
        `aws://${accountId}/${options.region}`,
        '--profile',
        options.profile,
        ...(trusts.length ? ['--trust', trusts.join(',')] : []),
        // Required when bootstrapping with --trust for cross-account access. AWS needs explicit CloudFormation execution policies to what the pipeline can deploy.
        ...(trusts.length && cloudformationExecutionPolicies.length
            ? cloudformationExecutionPolicies.flatMap((p) => ['--cloudformation-execution-policies', p])
            : []),
        ...forwardedArguments,
    ], {
        stdio: 'inherit',
        cwd: devkit_1.workspaceRoot, // Switch from projectRoot to workspaceRoot to avoid bootstrapp running a synth. The CLI doesn't run synth!
        shell: true,
        env: Object.assign(Object.assign({}, process.env), { CDK_NEW_BOOTSTRAP: '1' }), // Enable the modern bootstrap stack v2+.
    });
    return {
        success: true,
    };
});
exports.default = runExecutor;
//# sourceMappingURL=executor.js.map