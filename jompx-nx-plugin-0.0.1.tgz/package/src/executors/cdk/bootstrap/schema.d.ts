export interface BootstrapExecutorSchema {
  accountId: string; // Fix for Nx digit only parsing issue.
  region: string;
  profile: string;
  trust?: string;
  cloudformationExecutionPolicies?: string;
}
