import { PromiseExecutor } from '@nx/devkit';
import { BootstrapExecutorSchema } from './schema';
declare const runExecutor: PromiseExecutor<BootstrapExecutorSchema>;
export default runExecutor;
