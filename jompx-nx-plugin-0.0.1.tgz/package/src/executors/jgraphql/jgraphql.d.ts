import { PromiseExecutor } from '@nx/devkit';
import { JgraphqlExecutorSchema } from './schema';
declare const runExecutor: PromiseExecutor<JgraphqlExecutorSchema>;
export default runExecutor;
