export interface JgraphqlExecutorSchema {} // eslint-disable-line
