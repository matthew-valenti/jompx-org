import { PromiseExecutor } from '@nx/devkit';
import { ExtractExecutorSchema } from './schema';
declare const runExecutor: PromiseExecutor<ExtractExecutorSchema>;
export default runExecutor;
