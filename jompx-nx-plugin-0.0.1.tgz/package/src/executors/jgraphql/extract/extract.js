"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tslib_1 = require("tslib");
const fg = require("fast-glob");
const schema_1 = require("@graphql-tools/schema");
const path = require("path");
const promises_1 = require("node:fs/promises");
const constructs_1 = require("@jompx/constructs");
const runExecutor = (options, context) => tslib_1.__awaiter(void 0, void 0, void 0, function* () {
    // 0. Get executor config.
    // const executorConfig = context.workspace.projects[context.projectName]?.targets?.[
    //   context.targetName
    // ] as ExecutorContext;
    // const cwd = executorConfig.cwd ?? process.cwd() ?? './'; // This is the cwd param from the org project.json.
    var _a, _b, _c, _d;
    const projectRoot = path.join(context.root, context.projectsConfigurations.projects[context.projectName].root);
    console.log('context.root', context.root);
    console.log('projectRoot', projectRoot);
    // 1. Get the CDK out template file which contains the GraphQL schema as a string.
    // The CDK creates the GraphQL schema locally and then updates AppSync as part of a deploy.
    const entries = yield fg([options.cdkOutSchemaFilePattern]);
    // 2. If the schema glob does not match any files then error. i.e. We cannot get the schema.
    if (!entries.length) {
        throw `File pattern "${options.cdkOutSchemaFilePattern}" matched zero files. Does the CDK out file exist and is the glob file pattern correct?`;
    }
    // 3. Read the template file (that is found first) and extract the GraphQL schema defintion string.
    // The cdk-out directory may contain many old template files.
    const data = yield (0, promises_1.readFile)(entries[0], // e.g. 'apps/cdk/cdk.out/assembly-CdkPipelineStack-CdkAppStageSandbox/CdkPipelineStackCdkAppStageSandboxAppSyncStack5A6CD604.template.json',
    { encoding: 'utf8' });
    const out = JSON.parse(data);
    const key = Object.keys(out.Resources).find((key) => { var _a; return ((_a = out.Resources[key]) === null || _a === void 0 ? void 0 : _a.Type) === 'AWS::AppSync::GraphQLSchema'; });
    const definition = out.Resources[key].Properties.Definition;
    // 4. Get org custom directives (if any).
    // The org can specify a glob file pattern to match "transpiled" custom directive .js files NOT .ts files.
    const customDirectivePlugins = new constructs_1.CustomDirectivePlugins();
    yield customDirectivePlugins.init(options.customDirectiveFilePattern);
    const customDirectivePluginDefinitions = customDirectivePlugins.customDirectives
        .map((o) => o.definition())
        .join('\n');
    // 5. Full GraphQL schema = AppSync CDK definition + AWS scalar definitions + Jompx custom directive definitions + custom directive plugin defintions.
    // We need a full schema to generate typescript types (from local). Note that the AppSync schema doesn't allow scalars or directives.
    const schema = definition + '\n' + constructs_1.AwsScalars + '\n\n' + (0, constructs_1.DirectiveDefinitions)() + '\n\n' + customDirectivePluginDefinitions;
    // 6. Write GraphQL schema file (schema.graphql).
    const outputSchemaFileName = path.resolve(context.root, options.outputPath, (_a = options.outputSchemaFile) !== null && _a !== void 0 ? _a : './schema.graphql');
    yield (0, promises_1.writeFile)(outputSchemaFileName, schema);
    console.log(`Generate to ${outputSchemaFileName}`);
    // 7. Generate and write the executable schema. This is the only known schema that is iterable and preserves directives (schema.graphql.directives.json).
    const executableSchema = (0, schema_1.makeExecutableSchema)({
        typeDefs: schema,
    });
    // console.log(executableSchema.getType('MMovie')); // Keep for debug.
    const directiveJson = [];
    const typeMap = executableSchema.getTypeMap();
    for (const [key, value] of Object.entries(typeMap)) {
        directiveJson.push({
            name: key,
            directives: (_b = value.astNode) === null || _b === void 0 ? void 0 : _b.directives.map((directive) => ({
                name: directive.name.value,
                arguments: directive.arguments.map((argument) => ({
                    name: argument.name.value,
                    value: argument.value['value'],
                })),
            })),
            fields: ((_d = (_c = value.astNode) === null || _c === void 0 ? void 0 : _c['fields']) !== null && _d !== void 0 ? _d : []).map((o) => {
                var _a;
                return ({
                    name: (_a = o === null || o === void 0 ? void 0 : o.name) === null || _a === void 0 ? void 0 : _a.value,
                    // Old unparsed directive code. Put back if parsing is brittle.
                    // directives: o?.directives
                    directives: o === null || o === void 0 ? void 0 : o.directives.map((directive) => ({
                        name: directive.name.value,
                        arguments: directive.arguments.map((argument) => ({
                            name: argument.name.value,
                            value: argument.value.value,
                        })),
                    })),
                });
            }),
        });
    }
    const outputDirectiveFileName = path.resolve(context.root, options.outputPath, options.outputDirectivesJsonFile);
    yield (0, promises_1.writeFile)(outputDirectiveFileName, JSON.stringify(directiveJson, null, 4), { encoding: 'utf8' });
    return {
        success: true,
    };
});
exports.default = runExecutor;
//# sourceMappingURL=extract.js.map