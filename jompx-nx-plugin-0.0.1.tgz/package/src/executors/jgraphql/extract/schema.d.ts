export interface ExtractExecutorSchema {
  cdkOutSchemaFilePattern: string;
  customDirectiveFilePattern: string;
  outputPath: string;
  outputSchemaFile?: string;
  outputDirectivesJsonFile?: string;
}
