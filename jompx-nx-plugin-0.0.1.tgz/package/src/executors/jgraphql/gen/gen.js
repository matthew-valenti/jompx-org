"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tslib_1 = require("tslib");
const jompx = require("@jompx/constructs");
const promises_1 = require("node:fs/promises");
const path = require("path");
const runExecutor = (options, context) => tslib_1.__awaiter(void 0, void 0, void 0, function* () {
    const projectRoot = path.join(context.root, context.projectsConfigurations.projects[context.projectName].root);
    console.log('context.root', context.root);
    console.log('projectRoot', projectRoot);
    const catalogJsonFile = path.resolve(context.root, options.catalogJsonFile);
    const cedarPolicyJsonFile = path.resolve(context.root, options.cedarPolicyJsonFile);
    const principalJsonFile = path.resolve(context.root, options.principalJsonFile);
    console.log('catalogJsonFile', catalogJsonFile);
    console.log('cedarPolicyJsonFile', cedarPolicyJsonFile);
    console.log('principalJsonFile', principalJsonFile);
    // const filePath = path.join(__dirname, 'test', '__fixtures__', 'policies.json');
    // const policies: jompx.CedarPolicySet = await import(filePath);
    const catalog = JSON.parse(yield (0, promises_1.readFile)(catalogJsonFile, 'utf8'));
    const policies = JSON.parse(yield (0, promises_1.readFile)(cedarPolicyJsonFile, 'utf8'));
    const principal = JSON.parse(yield (0, promises_1.readFile)(principalJsonFile, 'utf8'));
    // 1. Provide a dummy token for each placeholder.
    const tokens = jompx.Authorization.requiredPlaceholders(policies);
    console.log('JGraphQLGen: Required authorization placeholders', tokens);
    // TODO: Can we do better than stuffing auth variables into parameter store? Remember variables are per account/region. We also have to do this in the AppSync construct.
    // for (const key of Object.keys(tokens)) {
    //   tokens[key] = ssm.StringParameter.valueFromLookup(undefined as never, `/authorization/token/userPoolId/${key}`);
    // }
    // 2. Create class.
    const authorization = jompx.Authorization.create(policies, tokens);
    const builder = new jompx.GraphqlSchemaBuilder()
        .add(new jompx.CommonSchemaBuilder())
        .add(new jompx.CatalogSchemaBuilder(options.apiName, catalog))
        .add(new jompx.AuthSchemaBuilder(options.apiName, {
        instance: authorization,
        principalTypes: principal[options.apiName].allowedPrincipalTypes,
        groupNames: principal[options.apiName].groupNames,
    }));
    const sdl = builder.build().trim();
    const configOutPath = path.resolve(projectRoot, options.outputSchemaFile);
    yield (0, promises_1.writeFile)(configOutPath, sdl, 'utf-8');
    return {
        success: true,
    };
});
exports.default = runExecutor;
//# sourceMappingURL=gen.js.map