export interface GenExecutorSchema {
  apiName: string;
  catalogJsonFile: string;
  cedarPolicyJsonFile: string;
  principalJsonFile: string;
  outputSchemaFile?: string;
}
